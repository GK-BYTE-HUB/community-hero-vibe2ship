import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Sparkles,
  ArrowRight,
  Smartphone,
  Lock
} from 'lucide-react';
import AuthorityView from './components/AuthorityView';
import CitizenView from './components/CitizenView';
import { Issue } from './types';


const UNIFIED_TICKETS = [
  {
    id: 'CIV-303',
    title: 'Contaminated Water Supply',
    location: 'Sector 15, Block C',
    status: 'pending',
    department: 'Water Supply',
    category: 'Water Supply',
    severity: 'medium',
    urgency: 'Medium',
    upvotes: 4,
    verifiedCount: 2,
    hasUpvoted: false,
    verification: 'None',
    description: 'Drinking water in Block C has a yellow-brown tint and a slight metallic smell. Multiple residents reported the same issue this morning.',
    coordinates: { x: 20, y: 75 },
    photoUrl: 'https://www.hindustantimes.com/ht-img/img/2026/01/18/400x225/The-picture-of-the-contaminated-water-supply-that-_1768760749014.jpeg',
    reporterName: 'Neha Sharma',
    reportedTime: '1 hour ago',
    assignedTo: '',
    assignedCrew: '',
    mockImages: [
      'https://www.hindustantimes.com/ht-img/img/2026/01/18/400x225/The-picture-of-the-contaminated-water-supply-that-_1768760749014.jpeg',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRszz5dVx46kvA2m4Rt7Z_DUAe-qu2pZ7DwHA&s'
    ],
    locality: 'Sector 15',
    tags: ['Water Supply', 'Public Health'],
    tracked: true,
    iconType: 'water',
    verifications: 2,
    comments: [
      { id: 'c5', author: 'Priya Sen', role: 'Resident', avatarColor: 'bg-emerald-500', text: 'Hardly any water flowing from the kitchen taps since this morning.', timestamp: '55 mins ago' },
      { id: 'c6', author: 'Rohit Jha', role: 'Resident', avatarColor: 'bg-indigo-500', text: 'Same here in building F. Please look into it.', timestamp: '50 mins ago' }
    ]
  },
  {
    id: 'CIV-302',
    title: 'Drainage Overflow on Station Road',
    location: 'Station Road',
    status: 'assigned',
    department: 'Water Supply',
    category: 'Water Supply',
    severity: 'high',
    urgency: 'High',
    assignedCrew: 'Crew Alpha',
    assignedTo: 'Crew Alpha',
    upvotes: 9,
    verifiedCount: 8,
    hasUpvoted: false,
    verification: 'Quick',
    description: 'Raw sewage and dirty water overflowing from multiple manholes near the railway station entrance, creating a terrible smell and traffic gridlock.',
    coordinates: { x: 65, y: 45 },
    photoUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScdxVNGQT4nFL76NugXOaNlz5ZAl14rvwmgw&s',
    reporterName: 'Siddharth Shah',
    reportedTime: '42 mins ago',
    mockImages: [
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScdxVNGQT4nFL76NugXOaNlz5ZAl14rvwmgw&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxyJXhVe_TkVgW-1IfpGQcPiVI22pQhIoifw&s'
    ],
    locality: 'Old Panvel',
    tags: ['Water Supply', 'Infrastructure'],
    tracked: true,
    iconType: 'water',
    verifications: 8,
    comments: [
      { id: 'c3', author: 'Sonal Mehta', role: 'Resident', avatarColor: 'bg-emerald-500', text: 'The manhole is completely overflowing and causing terrible traffic.', timestamp: '35 mins ago' },
      { id: 'c4', author: 'Vikram Singh', role: 'Resident', avatarColor: 'bg-indigo-500', text: 'The municipal team was notified 3 hours ago but no action yet.', timestamp: '30 mins ago' }
    ]
  },
  {
    id: 'CIV-301',
    title: 'Major Pipe Burst in Sector 15',
    location: 'Sector 15, Central Park',
    status: 'in_progress',
    department: 'Water Supply',
    category: 'Water Supply',
    severity: 'high',
    urgency: 'High',
    assignedCrew: 'Crew Bravo',
    assignedTo: 'Crew Bravo',
    upvotes: 18,
    verifiedCount: 12,
    hasUpvoted: false,
    verification: 'None',
    description: 'A large high-pressure water transmission pipeline has ruptured, sending a massive geyser of water into the air and flooding the roadway and nearby footpaths.',
    coordinates: { x: 35, y: 30 },
    photoUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0WqqyZ0D7aA7bRH_scsm7aYJC--DPGBH4nQ&s',
    reporterName: 'Ganesh Gorad',
    reportedTime: '15 mins ago',
    mockImages: [
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0WqqyZ0D7aA7bRH_scsm7aYJC--DPGBH4nQ&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTaeoQQSgj2skg0stxRVN3MCxwm-VMr3HbrLQ&s'
    ],
    locality: 'Sector 15',
    tags: ['Water Supply', 'Infrastructure'],
    tracked: true,
    iconType: 'water',
    verifications: 12,
    comments: [
      { id: 'c1', author: 'Rajesh Kumar', role: 'Resident', avatarColor: 'bg-emerald-500', text: 'Water has flooded the entire lane near Central Park. Please send help immediately!', timestamp: '22 mins ago' },
      { id: 'c2', author: 'Amit Patel', role: 'Resident', avatarColor: 'bg-indigo-500', text: 'Yes, water pressure has dropped completely in the nearby buildings.', timestamp: '18 mins ago' }
    ]
  }
];

export default function App() {
  const [activeAppView, setActiveAppView] = useState<'login' | 'citizen' | 'authority'>('login');
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [mobileNumber, setMobileNumber] = useState<string>('');
  const [otp, setOtp] = useState<string>('1234');
  const [role, setRole] = useState<'citizen' | 'authority'>('citizen');
  const [municipality, setMunicipality] = useState<string>('Panvel Municipal Corporation');
  const [department, setDepartment] = useState<string>('Water Supply & Drainage');
  const [adminPassword, setAdminPassword] = useState<string>('••••••••');

  const [globalTickets, setGlobalTickets] = useState<any[]>(UNIFIED_TICKETS);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [isLoadingIssues, setIsLoadingIssues] = useState<boolean>(false);

  // Fetch issues from Backend Node server
  const fetchIssues = async () => {
    setIsLoadingIssues(true);
    try {
      const response = await fetch('/api/issues');
      const data = await response.json();
      setIssues(data);
    } catch (error) {
      console.error("Error fetching issues from backend:", error);
    } finally {
      setIsLoadingIssues(false);
    }
  };

  // Update status modifier handler
  const handleUpdateIssueStatus = async (id: string, status: Issue['status'], comment: string) => {
    try {
      const response = await fetch(`/api/issues/${id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, comment })
      });
      if (response.ok) {
        await fetchIssues();
      } else {
        console.error("Failed to update status on server");
      }
    } catch (error) {
      console.error("Error updating status on server:", error);
    }
  };

  // Fetch on mount or when login status changes
  useEffect(() => {
    if (isLoggedIn) {
      fetchIssues();
    }
  }, [isLoggedIn]);

  // Handle fake/illusion auth form submission
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (role === 'citizen') {
      setActiveAppView('citizen');
    } else {
      setActiveAppView('authority');
    }
    setIsLoggedIn(true);
  };

  if (activeAppView === 'login') {
    /* --- 1. "ILLUSION AUTH" LOGIN SCREEN --- */
    return (
      <div id="login-container" className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8">
        {/* Decorative ambient gradients */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-sky-500 to-indigo-600"></div>
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="w-full max-w-md space-y-8 relative z-10">
          {/* Logo & Slogan Header */}
          <div className="text-center space-y-3">
            <div className="inline-flex h-14 w-14 bg-indigo-600 text-white rounded-2xl items-center justify-center shadow-lg shadow-indigo-600/20 border border-indigo-500 mx-auto">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 font-display">
                Community Hero
              </h1>
              <p className="text-xs text-slate-500 font-medium max-w-xs mx-auto leading-relaxed">
                Empowering localized civic reporting and neighborhood transparency
              </p>
            </div>
          </div>

          {/* Login Form Card */}
          <div className="bg-white border border-slate-200 rounded-[28px] p-6 sm:p-8 shadow-sm">
            <form onSubmit={handleLogin} className="space-y-5">
              
              {/* ROLE TOGGLE SWITCH (Top Level) */}
              <div className="space-y-1.5">
                <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono text-left">
                  Login Role
                </label>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200/50">
                  <button
                    type="button"
                    onClick={() => setRole('citizen')}
                    className={`py-2 px-3 text-[11px] font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      role === 'citizen'
                        ? 'bg-white text-indigo-600 shadow-xs font-extrabold'
                        : 'text-slate-600 hover:text-slate-900 font-medium'
                    }`}
                  >
                    <span>👤 Citizen</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('authority')}
                    className={`py-2 px-3 text-[11px] font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      role === 'authority'
                        ? 'bg-white text-indigo-600 shadow-xs font-extrabold'
                        : 'text-slate-600 hover:text-slate-900 font-medium'
                    }`}
                  >
                    <span>🏛️ Authority</span>
                  </button>
                </div>
              </div>

              {/* Conditional Rendering based on Role */}
              {role === 'citizen' ? (
                <>
                  {/* Mobile Input Field */}
                  <div className="space-y-1.5">
                    <label htmlFor="mobile" className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono text-left">
                      Mobile Number
                    </label>
                    <div className="relative text-left">
                      <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                        <Smartphone className="w-4 h-4" />
                      </div>
                      <input
                        id="mobile"
                        type="tel"
                        required
                        value={mobileNumber}
                        onChange={(e) => setMobileNumber(e.target.value)}
                        placeholder="+91 99999 00000"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-medium placeholder-slate-400"
                      />
                    </div>
                  </div>

                  {/* OTP Input Field */}
                  <div className="space-y-1.5">
                    <label htmlFor="otp" className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono text-left">
                      Enter One-Time Password (OTP)
                    </label>
                    <div className="relative text-left">
                      <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                        <Lock className="w-4 h-4" />
                      </div>
                      <input
                        id="otp"
                        type="password"
                        required
                        maxLength={4}
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-bold tracking-widest text-slate-800"
                      />
                    </div>
                    {/* Pre-fill Hackathon helper text */}
                    <p className="text-[10px] text-slate-400 font-medium pt-0.5 text-left">
                      (Mock OTP auto-filled for hackathon evaluation)
                    </p>
                  </div>

                  {/* Login Button */}
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-3 px-4 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-indigo-600/10 hover:scale-[1.01] active:scale-[0.99]"
                  >
                    <span>Verify & Login ➔</span>
                  </button>
                </>
              ) : (
                <>
                  {/* Municipality/City Dropdown */}
                  <div className="space-y-1.5 text-left">
                    <label htmlFor="municipality" className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                      Municipality / City
                    </label>
                    <select
                      id="municipality"
                      value={municipality}
                      onChange={(e) => setMunicipality(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-semibold text-slate-800 cursor-pointer"
                    >
                      <option value="Panvel Municipal Corporation">Panvel Municipal Corporation</option>
                      <option value="Navi Mumbai Municipal Corporation">Navi Mumbai Municipal Corporation</option>
                      <option value="Thane Municipal Corporation">Thane Municipal Corporation</option>
                      <option value="Brihanmumbai Municipal Corporation (BMC)">Brihanmumbai Municipal Corporation (BMC)</option>
                    </select>
                  </div>

                  {/* Department Dropdown */}
                  <div className="space-y-1.5 text-left">
                    <label htmlFor="department" className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                      Department
                    </label>
                    <select
                      id="department"
                      value={department}
                      onChange={(e) => setDepartment(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-semibold text-slate-800 cursor-pointer"
                    >
                      <option value="Water Supply & Drainage">Water Supply & Drainage</option>
                      <option value="Public Works Department (PWD)">Public Works Department (PWD)</option>
                      <option value="Roads & Traffic Engineering">Roads & Traffic Engineering</option>
                      <option value="Solid Waste Management (SWM)">Solid Waste Management (SWM)</option>
                      <option value="Electricity & Street Lighting">Electricity & Street Lighting</option>
                      <option value="Disaster Management Cell">Disaster Management Cell</option>
                      <option value="Environment & Pollution Control">Environment & Pollution Control</option>
                    </select>
                  </div>

                  {/* Admin Password */}
                  <div className="space-y-1.5 text-left">
                    <label htmlFor="admin-password" className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                      Admin Password
                    </label>
                    <div className="relative">
                      <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                        <Lock className="w-4 h-4" />
                      </div>
                      <input
                        id="admin-password"
                        type="password"
                        required
                        value={adminPassword}
                        onChange={(e) => setAdminPassword(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-bold tracking-widest text-slate-800"
                      />
                    </div>
                  </div>

                  {/* Access Button */}
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-3 px-4 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-indigo-600/10 hover:scale-[1.01] active:scale-[0.99]"
                  >
                    <span>Access Authority Portal ➔</span>
                  </button>
                </>
              )}

            </form>
          </div>

          {/* Hackathon Evaluation Badge footer */}
          <div className="text-center">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 border border-indigo-100/80 rounded-full text-[10px] text-indigo-700 font-bold font-mono">
              <Sparkles className="w-3 h-3 text-indigo-500 animate-pulse" />
              <span>Hackathon Evaluation Sandbox</span>
            </span>
          </div>

        </div>
      </div>
    );
  }

  /* --- 3. RE-ROUTE IF AUTHORITY COMPONENT CHOSEN --- */
  if (activeAppView === 'authority') {
    return (
      <AuthorityView 
        globalTickets={globalTickets}
        setGlobalTickets={setGlobalTickets}
        municipality={municipality}
        department={department}
        onLogout={() => {
          setActiveAppView('login');
          setIsLoggedIn(false);
        }}
      />
    );
  }

  /* --- AUTHENTICATED STATE LAYOUT --- */
  if (activeAppView === 'citizen') {
    return (
      <CitizenView
        globalTickets={globalTickets}
        setGlobalTickets={setGlobalTickets}
        setActiveAppView={setActiveAppView}
        setIsLoggedIn={setIsLoggedIn}
      />
    );
  }

  return null;
}
