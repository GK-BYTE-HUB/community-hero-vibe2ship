export interface TimelineUpdate {
  status: 'Received' | 'Site Inspection' | 'Team Assigned' | 'In Progress' | 'Resolved';
  date: string;
  comment: string;
}

export interface Issue {
  id: string;
  title: string;
  category: 'Pothole' | 'Garbage' | 'Water Leakage' | 'Streetlight' | 'Graffiti' | 'Other';
  location: string;
  description: string;
  urgency: 'Low' | 'Medium' | 'High';
  upvotes: number;
  status: 'Received' | 'Site Inspection' | 'Team Assigned' | 'In Progress' | 'Resolved';
  date: string;
  imageUrl?: string;
  isAnonymous: boolean;
  reporterName?: string;
  timelineUpdates: TimelineUpdate[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  isDraftIssue?: boolean;
  draftIssueData?: Partial<Issue>;
}
