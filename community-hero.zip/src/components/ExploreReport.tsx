import React, { useState, useRef, useEffect } from 'react';
import IssueCard from './IssueCard';
import { 
  Search, 
  MapPin, 
  Plus, 
  SlidersHorizontal, 
  ListFilter, 
  AlertCircle, 
  ThumbsUp, 
  CheckCircle, 
  Upload, 
  X, 
  Sparkles, 
  Camera, 
  Check, 
  HelpCircle,
  EyeOff,
  Eye,
  Info,
  Bell,
  MessageSquare,
  ZoomIn,
  ZoomOut,
  Compass
} from 'lucide-react';

// Type declarations
interface Issue {
  id: string;
  title: string;
  category: string;
  urgency: 'High' | 'Medium' | 'Low';
  status: 'In Progress' | 'Received' | 'Resolved' | 'Team Assigned';
  location: string;
  upvotes: number;
  hasUpvoted: boolean;
  verification: 'None' | 'Quick' | 'Photo';
  description: string;
  coordinates: { x: number; y: number }; // relative % for mock map
  photoUrl?: string;
  department?: string;
}

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'info' | 'warning';
}

interface ExploreReportProps {
  globalTickets: any[];
  setGlobalTickets: React.Dispatch<React.SetStateAction<any[]>>;
}

export default function ExploreReport({ globalTickets, setGlobalTickets }: ExploreReportProps) {
  // Toast notifications state
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toastIdCounter = useRef(0);
  const activeMessages = useRef<Set<string>>(new Set());
  const activeTimeouts = useRef<NodeJS.Timeout[]>([]);

  useEffect(() => {
    return () => {
      activeTimeouts.current.forEach(clearTimeout);
    };
  }, []);

  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    if (activeMessages.current.has(message)) {
      return;
    }
    activeMessages.current.add(message);

    const id = ++toastIdCounter.current;
    setToasts(prev => [...prev, { id, message, type }]);

    const timer = setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
      activeMessages.current.delete(message);
      activeTimeouts.current = activeTimeouts.current.filter(t => t !== timer);
    }, 4500);
    activeTimeouts.current.push(timer);
  };

  const issues = globalTickets;
  const setIssues = setGlobalTickets;

  const getDisplayStatus = (status: string) => {
    const s = (status || '').toLowerCase();
    if (s === 'pending') return 'Received';
    if (s === 'assigned') return 'Team Assigned';
    if (s === 'inprogress' || s === 'in_progress') return 'In Progress';
    if (s === 'resolved') return 'Resolved';
    return status;
  };

  // Selected issue state (for map highlight / scroll targeting)
  const [selectedIssueId, setSelectedIssueId] = useState<string | null>(null);
  
  // Modal visibility
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  // Form Fields states
  const [formTitle, setFormTitle] = useState<string>('');
  const [formLocationType, setFormLocationType] = useState<'current' | 'home' | 'work'>('current');
  const [formCustomLocation, setFormCustomLocation] = useState<string>('');
  const [formCategories, setFormCategories] = useState<string[]>(['Infrastructure']);
  const [disputedTag, setDisputedTag] = useState<string | null>(null);
  const [disputeMessage, setDisputeMessage] = useState<string>('');
  const [disputePhase, setDisputePhase] = useState<'input' | 'evaluating' | 'rejected' | 'accepted'>('input');
  const [aiSelectedCategories, setAiSelectedCategories] = useState<string[]>(['Infrastructure']);
  const [isLocationConfirmed, setIsLocationConfirmed] = useState<boolean>(false);
  const [formSendEmail, setFormSendEmail] = useState<boolean>(false);
  const [formIsAnonymous, setFormIsAnonymous] = useState<boolean>(false);
  const [formCannotPhotograph, setFormCannotPhotograph] = useState<boolean>(false);
  const [formFileUploaded, setFormFileUploaded] = useState<boolean>(false);
  const [formFileName, setFormFileName] = useState<string>('');
  const [formImagePreview, setFormImagePreview] = useState<string | null>(null);
  const [isVisionAnalyzing, setIsVisionAnalyzing] = useState<boolean>(false);
  const [trackedIssueIds, setTrackedIssueIds] = useState<string[]>([]);
  const [viewingZone, setViewingZone] = useState<'current' | 'home' | 'work'>('current');
  const [zoom, setZoom] = useState<number>(1);
  const [zoomLevel, setZoomLevel] = useState<number>(14);

  const [popoverStep, setPopoverStep] = useState<'options' | 'photoUpload'>('options');
  const [popoverFileSelected, setPopoverFileSelected] = useState<boolean>(false);
  const [popoverFileName, setPopoverFileName] = useState<string>('');
  const [popoverImagePreview, setPopoverImagePreview] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Search state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('Newest');
  // Expanded Verification Selectors inside Cards
  const [openVerifyId, setOpenVerifyId] = useState<string | null>(null);

  useEffect(() => {
    setPopoverStep('options');
    setPopoverFileSelected(false);
    setPopoverFileName('');
    setPopoverImagePreview(null);
  }, [openVerifyId]);

  // Handle upvoting
  const handleUpvote = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setIssues(prevIssues => prevIssues.map(issue => {
      if (issue.id === id) {
        const upvoted = !issue.hasUpvoted;
        showToast(
          upvoted ? `Upvoted issue ${issue.id}!` : `Removed upvote from ${issue.id}`, 
          upvoted ? 'success' : 'info'
        );
        return {
          ...issue,
          hasUpvoted: upvoted,
          upvotes: upvoted ? issue.upvotes + 1 : issue.upvotes - 1
        };
      }
      return issue;
    }));
  };

  // Toggle Verification status for an issue
  const handleSetVerification = (id: string, type: 'Quick' | 'Photo', e: React.MouseEvent) => {
    e.stopPropagation();
    setIssues(prevIssues => prevIssues.map(issue => {
      if (issue.id === id) {
        let msg = '';
        if (type === 'Quick') {
          msg = `Quick-verified issue ${issue.id}. Thank you for confirming!`;
        } else {
          msg = `Photo verification submitted for ${issue.id}. +20 Hero points pending!`;
        }
        showToast(msg, 'success');
        return {
          ...issue,
          verification: issue.verification === type ? 'None' : type
        };
      }
      return issue;
    }));
    setOpenVerifyId(null);
  };

  // Get dynamic verification options based on status
  const getVerificationOptions = (status: string) => {
    const s = status || '';
    if (s === 'Received') {
      return {
        quick: {
          title: "⚡ Verify New Report",
          helper: "I confirm this new issue is real and needs attention."
        },
        photo: {
          title: "📸 Add Verification Photo",
          helper: "Upload your own photo to help this issue get verified faster."
        }
      };
    } else if (s === 'In Progress') {
      return {
        quick: {
          title: "⚡ Confirm Activity",
          helper: "I see workers or equipment on site."
        },
        photo: {
          title: "📸 Photo Progress",
          helper: "Upload a photo of the ongoing repair work."
        }
      };
    } else if (s === 'Resolved') {
      return {
        quick: {
          title: "✅ Confirm Fixed (Quick)",
          helper: "I confirm the issue is completely resolved."
        },
        photo: {
          title: "📸 Confirm Fixed (Photo)",
          helper: "Upload a photo of the completed fix."
        }
      };
    }
    // Fallback
    return {
      quick: {
        title: "⚡ Quick Verify",
        helper: "I confirm this issue is still here."
      },
      photo: {
        title: "📸 Photo Verify",
        helper: "Upload a new photo to earn higher trust points."
      }
    };
  };

  // Real Drag & Drop and File Selection Handlers
  const handleDashedAreaClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileSelected = (file: File) => {
    const previewUrl = URL.createObjectURL(file);
    setFormImagePreview(previewUrl);
    setFormFileUploaded(true);
    setFormFileName(file.name);

    // Trigger Gemini Vision AI Simulation
    setIsVisionAnalyzing(true);
    showToast("✨ Gemini Vision analyzing hazard...", "info");

    setTimeout(() => {
      setIsVisionAnalyzing(false);
      
      const nameLower = file.name.toLowerCase();
      let finalTitle = "Major Road Pothole and Asphalt Breakdown";
      
      // Update the file upload simulation to push multiple tags based on keywords.
      // Initialize an empty array: let detectedTags = [];
      let detectedTags: string[] = [];
      
      // Check keywords independently (do not use if/else chains):
      if (nameLower.includes('water') || nameLower.includes('flood') || nameLower.includes('pipe')) {
        detectedTags.push('Water Hazard');
      }
      if (nameLower.includes('traffic') || nameLower.includes('road') || nameLower.includes('sign')) {
        detectedTags.push('Traffic & Roads');
      }
      if (nameLower.includes('wire') || nameLower.includes('light')) {
        detectedTags.push('Power/Lighting');
      }
      if (nameLower.includes('trash') || nameLower.includes('garbage')) {
        detectedTags.push('Sanitation');
      }
      if (nameLower.includes('signature') || nameLower.includes('selfie') || nameLower.includes('invalid')) {
        detectedTags = ['Non-Civic Issue'];
      }
      
      // If the array is still empty after checks, push "Infrastructure".
      if (detectedTags.length === 0) {
        detectedTags.push('Infrastructure');
      }

      // Determine a polished mock title based on what was detected
      if (detectedTags.includes('Non-Civic Issue')) {
        finalTitle = "Non-Civic Upload";
      } else if (detectedTags.includes('Water Hazard')) {
        finalTitle = "Flooded Intersection with Clogged Drainage Inlet";
      } else if (detectedTags.includes('Sanitation')) {
        finalTitle = "Overfilled Sanitation Bin Spilling onto Footpath";
      } else if (detectedTags.includes('Power/Lighting')) {
        finalTitle = "Exposed High-Voltage Hanging Line";
      } else if (detectedTags.includes('Traffic & Roads')) {
        finalTitle = "Damaged Warning Post and Traffic Hazard";
      }

      setFormTitle(finalTitle);
      setFormCategories(detectedTags);
      setAiSelectedCategories(detectedTags);

      if (detectedTags.includes('Non-Civic Issue')) {
        showToast("✨ Gemini Vision completed! Non-Civic upload detected.", "warning");
      } else if (detectedTags.length > 0 && !(detectedTags.length === 1 && detectedTags[0] === 'Infrastructure')) {
        showToast("✨ Gemini Vision completed! Title & tags auto-populated.", "success");
      } else {
        showToast("✨ Gemini Vision complete. Defaulted to Infrastructure.", "info");
      }
    }, 2000);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (formCannotPhotograph) return;
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelected(e.target.files[0]);
    }
  };

  // Toggle tracking of issues
  const handleToggleTrack = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const isTracked = trackedIssueIds.includes(id);
    if (isTracked) {
      setTrackedIssueIds(prev => prev.filter(item => item !== id));
      showToast(`🔔 Unfollowed issue ${id}.`, 'info');
    } else {
      setTrackedIssueIds(prev => [...prev, id]);
      showToast(`🔔 You are now tracking ${id}. You will be notified of municipal actions!`, 'success');
    }
  };

  // Auto-fill category simulation when title changes
  useEffect(() => {
    if (formFileUploaded) return; // Prevent overwriting Gemini Vision categorization
    if (!formTitle) return;
    const lower = formTitle.toLowerCase();
    
    let detected = 'Infrastructure'; // Safe, generic fallback

    if (lower.includes('water') || lower.includes('leak') || lower.includes('pipe') || lower.includes('drain') || lower.includes('flood') || lower.includes('sewage') || lower.includes('overflow') || lower.includes('clog')) {
      detected = 'Water Hazard';
    } else if (lower.includes('light') || lower.includes('dark') || lower.includes('electricity') || lower.includes('power') || lower.includes('lamp') || lower.includes('wire') || lower.includes('hanging line') || lower.includes('voltage')) {
      detected = 'Power/Lighting';
    } else if (lower.includes('garbage') || lower.includes('waste') || lower.includes('dump') || lower.includes('trash') || lower.includes('spill') || lower.includes('bin') || lower.includes('litter') || lower.includes('debris') || lower.includes('refuse') || lower.includes('sanitation')) {
      detected = 'Sanitation';
    } else if (lower.includes('safety') || lower.includes('crime') || lower.includes('suspicious') || lower.includes('fire') || lower.includes('emergency') || lower.includes('accident') || lower.includes('hazard') || lower.includes('exposed')) {
      detected = 'Public Safety';
    } else if (lower.includes('noise') || lower.includes('loud') || lower.includes('music') || lower.includes('smoke') || lower.includes('pollution') || lower.includes('air') || lower.includes('smell') || lower.includes('odor') || lower.includes('environmental')) {
      detected = 'Environmental';
    } else if (lower.includes('traffic') || lower.includes('road') || lower.includes('street') || lower.includes('asphalt') || lower.includes('lane') || lower.includes('signal') || lower.includes('crossing') || lower.includes('blockage') || lower.includes('congestion')) {
      detected = 'Traffic & Roads';
    } else if (lower.includes('pothole') || lower.includes('building') || lower.includes('bridge') || lower.includes('sidewalk') || lower.includes('pavement') || lower.includes('construction') || lower.includes('structure') || lower.includes('barrier') || lower.includes('damaged') || lower.includes('breakdown')) {
      detected = 'Infrastructure';
    }
    
    setFormCategories([detected]);
  }, [formTitle, formFileUploaded]);

  // Form Submission
  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      showToast('Please specify a title or description', 'warning');
      return;
    }

    // Determine final location text
    const finalLocation = formLocationType === 'current' 
      ? 'Sector 15, GPS: (18.995, 73.118)' 
      : formLocationType === 'home'
      ? 'Home - Sector 15'
      : 'Work - Kamothe';

    // Create custom mock coordinate near the map center
    const mockCoord = {
      x: 30 + Math.floor(Math.random() * 45),
      y: 25 + Math.floor(Math.random() * 45)
    };

    const newIssue: Issue = {
      id: `CIV-${Math.floor(Math.random() * 900) + 400}`,
      title: formTitle,
      category: formCategories[0] || 'Infrastructure',
      department: formCategories[0] || 'Infrastructure',
      urgency: 'Medium',
      status: 'Received',
      location: finalLocation,
      upvotes: 1,
      hasUpvoted: true,
      verification: 'None',
      description: 'Newly reported citizen request pending municipal categorization.',
      coordinates: mockCoord
    };

    setIssues(prev => [newIssue, ...prev]);
    setIsModalOpen(false);

    // Reset Form fields
    setFormTitle('');
    setFormLocationType('current');
    setFormCustomLocation('');
    setFormCategories(['Infrastructure']);
    setDisputedTag(null);
    setDisputeMessage('');
    setDisputePhase('input');
    setAiSelectedCategories(['Infrastructure']);
    setIsLocationConfirmed(false);
    setFormSendEmail(false);
    setFormIsAnonymous(false);
    setFormCannotPhotograph(false);
    setFormFileUploaded(false);
    setFormFileName('');
    setFormImagePreview(null);
    setIsVisionAnalyzing(false);

    // Trigger specified toast message exactly
    showToast("Report Received! AI is verifying if this is a new issue.", "success");
    if (formSendEmail) {
      setTimeout(() => {
        showToast("Official email drafted & scheduled for local ward officer!", "success");
      }, 1000);
    }
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setDisputedTag(null);
    setDisputeMessage('');
    setDisputePhase('input');
  };

  const getDepartmentBadge = (tag: string) => {
    switch (tag) {
      case 'Water Hazard':
        return { name: 'Water Supply Department', color: 'bg-sky-50 text-sky-700 border-sky-200' };
      case 'Traffic & Roads':
        return { name: 'Traffic Police', color: 'bg-slate-100 text-slate-700 border-slate-200' };
      case 'Infrastructure':
        return { name: 'Public Works Department (PWD)', color: 'bg-amber-50 text-amber-700 border-amber-200' };
      case 'Power/Lighting':
        return { name: 'Electricity Distribution Board', color: 'bg-yellow-50 text-yellow-700 border-yellow-200' };
      case 'Sanitation':
        return { name: 'Sanitation & Solid Waste Dept', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
      case 'Public Safety':
        return { name: 'Emergency Services Council', color: 'bg-rose-50 text-rose-700 border-rose-200' };
      case 'Environmental':
      case 'Environmental (Noise/Waste)':
        return { name: 'Environmental Protection Council', color: 'bg-teal-50 text-teal-700 border-teal-200' };
      default:
        return { name: 'General Municipal Ward Commission', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
    }
  };

  // Filter issues based on search
  const filteredIssues = issues.filter(issue => 
    issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (issue.location && issue.location.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (issue.category && issue.category.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Apply category filter and sorting
  const displayTickets = filteredIssues
    .filter(issue => {
      if (filterCategory === 'All') return true;
      const catLower = filterCategory.toLowerCase();
      
      const categoryMatches = (issue.category || '').toLowerCase().includes(catLower);
      const departmentMatches = (issue.department || '').toLowerCase().includes(catLower);
      const tagMatches = issue.tags && issue.tags.some((tag: string) => tag.toLowerCase().includes(catLower));
      
      if (catLower === 'water supply' || catLower === 'water hazard' || catLower === 'water') {
        return (
          categoryMatches ||
          departmentMatches ||
          tagMatches ||
          (issue.category || '').toLowerCase().includes('water') ||
          (issue.department || '').toLowerCase().includes('water')
        );
      }
      
      return categoryMatches || departmentMatches || tagMatches;
    })
    .sort((a, b) => {
      if (sortBy === 'Most Upvotes') {
        return (b.upvotes || 0) - (a.upvotes || 0);
      }
      // 'Newest' sort: sort descending by numeric ID or by localeCompare of id
      const idA = parseInt(a.id?.replace(/\D/g, '') || '0', 10);
      const idB = parseInt(b.id?.replace(/\D/g, '') || '0', 10);
      if (idA && idB) {
        return idB - idA;
      }
      return b.id?.localeCompare(a.id || '') || 0;
    });

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] md:h-[calc(100vh-80px)] w-full overflow-hidden relative">
      
      {/* Toast notifications display */}
      <div className="fixed top-20 right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
        {toasts.map(toast => (
          <div 
            key={toast.id}
            className={`p-4 rounded-xl shadow-lg border text-xs font-bold pointer-events-auto flex items-start gap-2.5 animate-slide-in transition-all duration-300 ${
              toast.type === 'success' 
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                : toast.type === 'warning'
                ? 'bg-amber-50 border-amber-200 text-amber-800'
                : 'bg-indigo-50 border-indigo-200 text-indigo-800'
            }`}
          >
            <div className={`p-1 rounded-md shrink-0 ${
              toast.type === 'success' ? 'bg-emerald-100' : toast.type === 'warning' ? 'bg-amber-100' : 'bg-indigo-100'
            }`}>
              <CheckCircle className="w-3.5 h-3.5" />
            </div>
            <div className="flex-1">{toast.message}</div>
          </div>
        ))}
      </div>

      {/* --- 1. VERTICAL SPLIT: TOP 40% MAP VIEW --- */}
      <section className="h-[40%] min-h-[180px] bg-sky-50 border-b border-slate-200 relative shrink-0 overflow-hidden select-none z-0">
        
        {/* Mock Map Layout */}
        <div className="absolute inset-0 bg-slate-100 p-2 flex flex-col justify-between overflow-hidden">
          
          {/* Zoomable Map Grid Wrapper */}
          <div 
            className="absolute inset-0 transition-transform duration-200 origin-center"
            style={{ transform: `scale(${zoom})` }}
          >
            {/* Grid Background roads using styled borders */}
            <div className="absolute inset-0 grid grid-cols-6 grid-rows-6 opacity-35 pointer-events-none">
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-b-2 border-white"></div>
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-r-2 border-b-2 border-white animate-pulse bg-indigo-50/10"></div>
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-r-2 border-b-2 border-white"></div>
              <div className="border-b-2 border-white"></div>
            </div>

            {/* Stylized road stripes representing Sector maps */}
            <div className="absolute inset-x-0 top-1/3 h-8 bg-slate-200/85 -rotate-2 border-y border-white flex items-center justify-center">
              <span className="text-[9px] font-mono font-bold tracking-widest text-slate-400">HIGH SCHOOL ROAD</span>
            </div>
            <div className="absolute inset-y-0 left-1/4 w-8 bg-slate-200/85 rotate-12 border-x border-white flex items-center justify-center">
              <span className="text-[9px] font-mono font-bold tracking-widest text-slate-400 [writing-mode:vertical-lr]">SECTOR 15 LINK</span>
            </div>
            <div className="absolute inset-x-0 bottom-1/4 h-10 bg-slate-200/85 rotate-1 border-y border-white flex items-center justify-center">
              <span className="text-[9px] font-mono font-bold tracking-widest text-slate-400">MAIN PANVEL HIGHWAY</span>
            </div>

            {/* Active GPS Locator Bubble */}
            <div className="absolute left-[30%] top-[65%] -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
              <div className="w-5 h-5 bg-indigo-600 rounded-full border-2 border-white flex items-center justify-center shadow-md shadow-indigo-600/30 animate-pulse">
                <span className="w-2 h-2 bg-white rounded-full"></span>
              </div>
              <span className="mt-1 bg-slate-900/90 text-white text-[7px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider font-mono">My GPS</span>
            </div>

            {/* Plotting interactive pins for all active issues */}
            {filteredIssues.map((issue) => {
              const isSelected = selectedIssueId === issue.id;
              return (
                <button
                  key={issue.id}
                  onClick={() => {
                    setSelectedIssueId(issue.id);
                    showToast(`Centered on ${issue.id} in Sector 15`, 'info');
                    const cardElement = document.getElementById(`card-${issue.id}`);
                    if (cardElement) {
                      cardElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }
                  }}
                  className="absolute transition-all duration-300 hover:scale-125 z-20 cursor-pointer flex flex-col items-center group"
                  style={{ left: `${issue.coordinates.x}%`, top: `${issue.coordinates.y}%` }}
                >
                  {/* Visual Pin Icon */}
                  <div className={`p-1.5 rounded-full border-2 shadow-md transition-all duration-300 ${
                    isSelected 
                      ? 'bg-indigo-600 text-white border-white scale-110 z-30 ring-4 ring-indigo-500/20' 
                      : issue.urgency === 'High'
                      ? 'bg-rose-500 text-white border-white'
                      : issue.urgency === 'Medium'
                      ? 'bg-amber-500 text-white border-white'
                      : 'bg-emerald-500 text-white border-white'
                  }`}>
                    <MapPin className="w-3.5 h-3.5" />
                  </div>
                  
                  {/* Popover label visible on hover/selection */}
                  <span className={`mt-0.5 whitespace-nowrap text-[8px] font-bold px-1.5 py-0.5 rounded border shadow-sm transition-all duration-200 pointer-events-none ${
                    isSelected 
                      ? 'bg-indigo-950 text-white border-indigo-900 scale-100 opacity-100' 
                      : 'bg-white text-slate-700 border-slate-200 opacity-0 group-hover:opacity-100 group-hover:scale-100'
                  }`}>
                    {issue.id} • {issue.category.split(' ')[0]}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Top Floating Map Controls */}
          <div className="absolute top-2.5 left-2.5 z-30 flex items-center gap-2">
            <span className="inline-flex items-center gap-1 bg-white/95 backdrop-blur-xs px-2.5 py-1.5 rounded-lg shadow-sm border border-slate-200 text-[10px] font-bold text-slate-800 uppercase font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Map View • Active GPS</span>
            </span>
            <select
              value={viewingZone}
              onChange={(e) => {
                const zone = e.target.value as 'current' | 'home' | 'work';
                setViewingZone(zone);
                showToast(`Viewing Zone switched to: ${zone === 'current' ? 'Current Location' : zone === 'home' ? 'Home' : 'Work'}`, 'info');
              }}
              className="bg-white/95 backdrop-blur-xs text-[10px] font-bold text-slate-800 border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-hidden cursor-pointer shadow-sm"
            >
              <option value="current">Current Location</option>
              <option value="home">Home</option>
              <option value="work">Work</option>
            </select>
          </div>

          <div className="absolute top-2.5 right-2.5 z-30">
            <button 
              onClick={() => setIsModalOpen(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[10px] px-3 py-1.5 rounded-xl shadow-md shadow-indigo-600/10 flex items-center gap-1 cursor-pointer transition active:scale-95 border border-indigo-500"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Report Issue</span>
            </button>
          </div>

          {/* Bottom Right Zoom/Crosshair Map Controls */}
          <div className="absolute bottom-12 right-2.5 z-30 flex flex-col items-center gap-2">
            {/* Zoom controls vertical pill */}
            <div className="flex flex-col bg-white/95 backdrop-blur-xs border border-slate-200 rounded-xl shadow-md overflow-hidden">
              <button
                type="button"
                onClick={() => {
                  setZoom(prev => {
                    const next = Math.min(prev + 0.1, 1.5);
                    showToast(`Zoomed In: ${Math.round(next * 100)}%`, 'info');
                    return parseFloat(next.toFixed(2));
                  });
                }}
                className="p-1.5 text-slate-700 hover:bg-slate-100 border-b border-slate-100 transition flex items-center justify-center cursor-pointer font-bold text-xs"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setZoom(prev => {
                    const next = Math.max(prev - 0.1, 0.8);
                    showToast(`Zoomed Out: ${Math.round(next * 100)}%`, 'info');
                    return parseFloat(next.toFixed(2));
                  });
                }}
                className="p-1.5 text-slate-700 hover:bg-slate-100 transition flex items-center justify-center cursor-pointer font-bold text-xs"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Circular crosshair button */}
            <button
              type="button"
              onClick={() => {
                setViewingZone('current');
                setZoom(1);
                showToast('Centered on Live GPS Coordinates.', 'success');
              }}
              className="p-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-full shadow-md text-indigo-600 transition flex items-center justify-center cursor-pointer hover:scale-105 active:scale-95"
              title="Live Location"
            >
              <Compass className="w-4 h-4 animate-pulse-once" />
            </button>
          </div>

          {/* Bottom indicator strip */}
          <div className="z-10 text-right pr-2">
            <span className="text-[9px] text-slate-400 font-bold font-mono">PANVEL SECTOR 15 • HYPERLOCAL HERO REGISTRY</span>
          </div>
        </div>
      </section>

      {/* --- 2. BOTTOM 60% LOCAL ISSUE FEED --- */}
      <section className="h-[60%] flex flex-col bg-white overflow-hidden shrink-0 z-10 relative">
        
        {/* Search & Header Control Area */}
        <div className="px-4 py-3 border-b border-slate-150 bg-slate-50 flex items-center justify-between gap-3 shrink-0">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search local reports..." 
              className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500"
            />
          </div>

          <div className="flex gap-1.5 shrink-0">
            <div className="relative flex items-center bg-white border border-slate-200 hover:border-slate-300 transition px-2 py-1 rounded-lg">
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500 mr-1.5 shrink-0" />
              <select
                value={filterCategory}
                onChange={(e) => {
                  setFilterCategory(e.target.value);
                  showToast(`Filtering by: ${e.target.value}`, 'info');
                }}
                className="bg-transparent text-[10px] font-bold text-slate-700 focus:outline-hidden cursor-pointer"
                title="Filters"
              >
                <option value="All">All Categories</option>
                <option value="Water Supply">Water Supply</option>
                <option value="Infrastructure">Infrastructure</option>
                <option value="Power/Lighting">Power & Lighting</option>
                <option value="Sanitation">Sanitation</option>
                <option value="Public Safety">Public Safety</option>
                <option value="Traffic & Roads">Traffic & Roads</option>
              </select>
            </div>

            <div className="relative flex items-center bg-white border border-slate-200 hover:border-slate-300 transition px-2 py-1 rounded-lg">
              <ListFilter className="w-3.5 h-3.5 text-slate-500 mr-1.5 shrink-0" />
              <select
                value={sortBy}
                onChange={(e) => {
                  setSortBy(e.target.value);
                  showToast(`Sorting by: ${e.target.value}`, 'info');
                }}
                className="bg-transparent text-[10px] font-bold text-slate-700 focus:outline-hidden cursor-pointer"
                title="Sort Order"
              >
                <option value="Newest">Newest First</option>
                <option value="Most Upvotes">Most Upvotes</option>
              </select>
            </div>
          </div>
        </div>

        {/* Scrollable List container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          <div className="flex items-center justify-between">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
              Live Feed ({displayTickets.length} issues in area)
            </h4>
            <span className="text-[10px] font-bold text-indigo-600 hover:underline cursor-pointer flex items-center gap-0.5">
              <span>View All</span>
            </span>
          </div>

          {displayTickets.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-xs font-bold font-display">No matching issues found</p>
              <p className="text-[10px] text-slate-400 max-w-xs mx-auto leading-relaxed">Try adjusting your search criteria or report a new issue to alert community leaders.</p>
            </div>
          ) : (
            displayTickets.map((issue) => {
              const isSelected = selectedIssueId === issue.id;
              return (
                <IssueCard
                  key={issue.id}
                  ticket={issue}
                  setGlobalTickets={setGlobalTickets}
                  triggerToast={showToast}
                  isSelected={isSelected}
                  onSelect={() => setSelectedIssueId(issue.id)}
                />
              );
            })
          )}
        </div>
      </section>

      {/* --- 3. THE "REPORT NEW ISSUE" MODAL --- */}
      {isModalOpen && (
        <div id="report-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-[24px] w-full max-w-lg border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
                  <Plus className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm font-display text-slate-800">Report Local Civic Issue</h3>
                  <p className="text-[10px] text-slate-500 font-medium">Alert repair crews & coordinate community fixes</p>
                </div>
              </div>
              <button 
                onClick={handleCloseModal}
                className="text-slate-400 hover:text-slate-700 p-1 hover:bg-slate-100 rounded-lg transition cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Body / Scrollable Form */}
            <form onSubmit={handleSubmitReport} className="p-6 overflow-y-auto space-y-5">
              
              {/* 1. LOCATION SELECTION */}
              <div className="space-y-1.5">
                <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                  1. Location Selection
                </label>
                <div className="flex flex-col gap-2">
                  <select
                    value={formLocationType}
                    onChange={(e) => {
                      setFormLocationType(e.target.value as 'current' | 'home' | 'work');
                      setIsLocationConfirmed(false);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-semibold text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 shrink-0 cursor-pointer"
                  >
                    <option value="current">📍 Current GPS Location</option>
                    <option value="home">🏠 Home - Sector 15</option>
                    <option value="work">💼 Work - Kamothe</option>
                  </select>

                  {/* Confirm Location button row */}
                  <div className="flex items-center justify-between gap-2 bg-slate-50 border border-slate-200/60 p-2.5 rounded-xl">
                    <span className="text-[10px] text-slate-500 font-medium">
                      {isLocationConfirmed ? (
                        <span className="text-emerald-700 font-bold flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" /> Address validated & locked
                        </span>
                      ) : (
                        <span className="flex items-center gap-1.5 text-indigo-600 font-bold">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                          <span>
                            {formLocationType === 'current' && 'Sector 15, New Panvel (Verified coordinate)'}
                            {formLocationType === 'home' && 'Sector 15 Resident Area'}
                            {formLocationType === 'work' && 'Kamothe Corporate Sector'}
                          </span>
                        </span>
                      )}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsLocationConfirmed(true);
                        showToast("Location Verified & Confirmed!", "success");
                      }}
                      className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                        isLocationConfirmed 
                          ? 'bg-emerald-600 text-white hover:bg-emerald-700' 
                          : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700'
                      }`}
                    >
                      {isLocationConfirmed ? "Confirmed ✓" : "Confirm Location"}
                    </button>
                  </div>
                </div>
              </div>

              {/* 2. EVIDENCE PHOTOS */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                  2. Evidence Photos
                </label>
                
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleFileChange} 
                />

                <div 
                  onClick={formCannotPhotograph ? undefined : handleDashedAreaClick}
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2 relative overflow-hidden ${
                    formCannotPhotograph 
                      ? 'bg-slate-100 border-slate-200 cursor-not-allowed opacity-50' 
                      : formFileUploaded
                      ? 'bg-indigo-50/40 border-indigo-300'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100/50'
                  }`}
                >
                  {formImagePreview ? (
                    <div className="flex flex-col items-center gap-2">
                      <img 
                        src={formImagePreview} 
                        alt="Evidence preview" 
                        className="w-24 h-24 object-cover rounded-lg border border-indigo-200 shadow-xs"
                        referrerPolicy="no-referrer"
                      />
                      <p className="text-xs font-bold text-slate-800 flex items-center gap-1 justify-center">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{formFileName}</span>
                      </p>
                      <p className="text-[10px] text-indigo-600 font-medium">Click or Drag & Drop to replace</p>
                    </div>
                  ) : (
                    <>
                      <div className="p-2 rounded-lg bg-white border border-slate-200 text-slate-400">
                        <Camera className="w-5 h-5" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-slate-700 font-display">Drag & Drop photo here, or click to browse</p>
                        <p className="text-[10px] text-slate-400 font-medium">Supports JPG, PNG (Max 5MB) • Required for full reputation rewards</p>
                      </div>
                    </>
                  )}
                </div>

                {/* Checkbox for Non-photographable issues */}
                <label className="flex items-start gap-2.5 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formCannotPhotograph}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setFormCannotPhotograph(checked);
                      if (checked) {
                        setFormFileUploaded(false);
                        setFormFileName('');
                        setFormImagePreview(null);
                      }
                    }}
                    className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-slate-700">This issue cannot be photographed</span>
                    <p className="text-[10px] text-slate-500">e.g., Power Outage, Noise Complaint</p>
                  </div>
                </label>
              </div>

              {/* 3. AI ANALYSIS: TITLE & TAGS */}
              <div className="space-y-3.5 border-t border-slate-100 pt-4">
                {isVisionAnalyzing ? (
                  <div className="flex flex-col items-center justify-center py-8 px-4 bg-indigo-50/30 border border-indigo-100 rounded-2xl space-y-3 animate-pulse">
                    <Sparkles className="w-6 h-6 text-indigo-600 animate-spin" />
                    <p className="text-xs font-bold text-indigo-800 font-mono text-center">
                      ✨ Gemini Vision analyzing hazard...
                    </p>
                    <p className="text-[10px] text-indigo-600 font-medium text-center">
                      Inspecting pixel clusters for water, blockages, potholes, & debris tags.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                          3. Issue Title / Core Complaint
                        </label>
                        {formFileUploaded && (
                          <span className="inline-flex items-center gap-1 text-[9px] font-bold text-indigo-600 font-mono bg-indigo-50 px-1.5 py-0.5 rounded-md">
                            <Sparkles className="w-2.5 h-2.5" /> AI Generated
                          </span>
                        )}
                      </div>
                      <input
                        type="text"
                        required
                        value={formTitle}
                        onChange={(e) => setFormTitle(e.target.value)}
                        placeholder="e.g. Major water leak spraying on street, dangling wire"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 placeholder-slate-400"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                          AI CATEGORY DETECTION (MULTI-SELECT)
                        </label>
                        <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-indigo-600 font-mono">
                          <Sparkles className="w-2.5 h-2.5" /> AI Suggested
                        </span>
                      </div>

                      {/* Multi-Tag UI pills */}
                      <div className="flex flex-wrap gap-1.5 p-2 bg-indigo-50/20 border border-indigo-100/50 rounded-xl">
                        {['Infrastructure', 'Water Hazard', 'Power/Lighting', 'Sanitation', 'Public Safety', 'Traffic & Roads', 'Environmental'].map(tag => {
                          const isSelected = formCategories.includes(tag);
                          return (
                            <button
                              key={tag}
                              type="button"
                              onClick={() => {
                                if (isSelected) {
                                  setFormCategories(formCategories.filter(t => t !== tag));
                                  if (disputedTag === tag) {
                                    setDisputedTag(null);
                                    setDisputeMessage('');
                                    setDisputePhase('input');
                                  }
                                } else {
                                  if (formFileUploaded && !aiSelectedCategories.includes(tag)) {
                                    setDisputedTag(tag);
                                    setDisputeMessage('');
                                    setDisputePhase('input');
                                    showToast(`🤖 AI Verification needed for tag: ${tag}`, "info");
                                  } else {
                                    setFormCategories([...formCategories, tag]);
                                  }
                                }
                              }}
                              className={`px-2.5 py-1.5 rounded-lg text-[10px] font-bold tracking-tight cursor-pointer transition-all duration-150 ${
                                isSelected 
                                  ? 'bg-indigo-600 text-white shadow-sm' 
                                  : 'bg-white hover:bg-slate-50 border border-slate-200 text-slate-600'
                              }`}
                            >
                              {tag}
                            </button>
                          );
                        })}
                      </div>
                      <p className="text-[10px] text-slate-400 font-medium leading-relaxed">
                        Select multiple overlapping tags that capture this hazard to prompt fast departmental handoffs.
                      </p>

                      {/* Human-in-the-Loop Inline AI Dispute Box */}
                      {disputedTag && (
                        <div className="p-3.5 bg-indigo-50/80 border border-indigo-100 rounded-xl space-y-2.5 animate-fade-in text-left">
                          
                          {disputePhase === 'input' && (
                            <>
                              <div className="flex items-start gap-2">
                                <span className="text-sm shrink-0">🤖</span>
                                <div className="space-y-0.5">
                                  <p className="text-[10px] font-bold text-indigo-950">AI Assistant Verification</p>
                                  <p className="text-[10px] text-slate-600 leading-normal">
                                    I didn't initially detect <strong className="text-indigo-900 font-bold">'{disputedTag}'</strong> in the photo. Could you briefly explain why this tag applies so I can learn?
                                  </p>
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <input 
                                  type="text"
                                  value={disputeMessage}
                                  onChange={(e) => setDisputeMessage(e.target.value)}
                                  placeholder={`Explain why ${disputedTag} is relevant... (min. 15 chars)`}
                                  className="flex-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-[10px] font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 placeholder-slate-400"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (!disputeMessage.trim()) {
                                      showToast("Please provide a brief reason", "warning");
                                      return;
                                    }
                                    setDisputePhase('evaluating');
                                    setTimeout(() => {
                                      if (disputeMessage.trim().length < 15) {
                                        setDisputePhase('rejected');
                                        showToast("🤖 AI: Request Rejected. Explanation is too short.", "warning");
                                      } else {
                                        setDisputePhase('accepted');
                                        setFormCategories(prev => [...prev, disputedTag]);
                                        setAiSelectedCategories(prev => [...prev, disputedTag]);
                                        showToast(`Tag '${disputedTag}' validated and added!`, "success");
                                      }
                                    }, 2000);
                                  }}
                                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[10px] px-3 py-1.5 rounded-lg shadow-sm transition active:scale-95 cursor-pointer shrink-0"
                                >
                                  Confirm Tag
                                </button>
                              </div>
                            </>
                          )}

                          {disputePhase === 'evaluating' && (
                            <div className="flex items-center justify-center py-4 gap-2 text-indigo-600">
                              <span className="animate-spin text-sm">⏳</span>
                              <span className="text-[11px] font-bold">🤖 AI is evaluating...</span>
                            </div>
                          )}

                          {disputePhase === 'rejected' && (
                            <div className="space-y-3">
                              <div className="p-2.5 bg-rose-50 border border-rose-100 rounded-lg text-rose-800 text-[10px] font-medium leading-normal">
                                ❌ AI: This explanation lacks detail or doesn't match the visual context. Tag not added.
                              </div>
                              <div className="flex gap-2 justify-end">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setDisputedTag(null);
                                    setDisputeMessage('');
                                    setDisputePhase('input');
                                  }}
                                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-[10px] px-3 py-1.5 rounded-lg transition"
                                >
                                  Cancel
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setDisputePhase('input');
                                  }}
                                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] px-3 py-1.5 rounded-lg shadow-sm transition active:scale-95 cursor-pointer"
                                >
                                  Try Again
                                </button>
                              </div>
                            </div>
                          )}

                          {disputePhase === 'accepted' && (
                            <div className="space-y-3">
                              <div className="p-2.5 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-800 text-[10px] font-medium leading-normal">
                                ✅ AI: Valid context provided. Tag added.
                              </div>
                              <div className="flex justify-end">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setDisputedTag(null);
                                    setDisputeMessage('');
                                    setDisputePhase('input');
                                  }}
                                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] px-3 py-1.5 rounded-lg shadow-sm transition active:scale-95 cursor-pointer"
                                >
                                  Done
                                </button>
                              </div>
                            </div>
                          )}

                        </div>
                      )}

                      {/* AI Department Routing Section */}
                      {formFileUploaded && !isVisionAnalyzing && (
                        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 animate-fade-in text-left">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px]">🏢</span>
                              <span className="text-[10px] font-bold text-slate-700 font-mono uppercase tracking-wider">Automated Routing</span>
                            </div>
                            <span className="text-[8px] bg-indigo-100 text-indigo-800 font-extrabold px-1.5 py-0.5 rounded-full uppercase tracking-wider font-mono">
                              Dispatch Locked
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {formCategories.map(cat => {
                              const dept = getDepartmentBadge(cat);
                              return (
                                <span 
                                  key={cat}
                                  className={`px-2 py-1 text-[9px] font-bold rounded-lg border flex items-center gap-1 ${dept.color}`}
                                >
                                  <span className="w-1 h-1 rounded-full bg-indigo-500 animate-pulse"></span>
                                  {dept.name}
                                </span>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>

              {/* 4. ESCALATION & ACTIONS */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                  4. Escalation Checklist
                </label>
                <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 space-y-2.5">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formSendEmail}
                      onChange={(e) => setFormSendEmail(e.target.checked)}
                      className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-700">Draft & send official email to local authority</span>
                      <p className="text-[9.5px] text-slate-400 font-medium">Generates and queues a formal draft containing your verified location and uploaded evidence.</p>
                    </div>
                  </label>

                  <label className="flex items-start gap-2.5 opacity-50 cursor-not-allowed">
                    <input
                      type="checkbox"
                      disabled
                      className="mt-0.5 rounded border-slate-300 text-indigo-600"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-bold text-slate-700">Alert Local Media (AI-lock)</span>
                      <p className="text-[9.5px] text-slate-400 font-medium">Unlocked automatically for high-severity public hazards with photo evidence.</p>
                    </div>
                  </label>
                </div>
              </div>

              {/* 5. PRIVACY */}
              <div className="bg-slate-50 border border-slate-200/80 rounded-[20px] p-4.5 space-y-2 border-t border-slate-100 pt-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                      <span>5. Report Anonymously</span>
                    </span>
                    
                  </div>

                  {/* Toggle Button */}
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={formIsAnonymous}
                      onChange={(e) => setFormIsAnonymous(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                {/* Dynamic Anonymity Warning */}
                {formIsAnonymous && (
                  <div className="flex items-start gap-1.5 p-2 bg-amber-50 text-amber-800 rounded-lg text-[9.5px] font-bold border border-amber-100/60 animate-fade-in leading-relaxed">
                    <Info className="w-3.5 h-3.5 shrink-0 text-amber-600" />
                    <span>Note:To protect your privacy, this report will not appear in your personal profile. You must manually find and upvote it in the public feed to track its status.
                    <p className="text-[10px] text-slate-500 leading-relaxed">Also Anonymity disables community points for this report. You will not earn reputation scores for this submission.</p></span>
                  </div>
                )}
              </div>

              {/* Submission Button */}
              <button
                type="submit"
                className="w-full font-bold text-xs py-3 px-4 rounded-xl transition flex items-center justify-center gap-1.5 shadow-sm active:scale-[0.99] bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/10 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Submit Civic Report</span>
              </button>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
