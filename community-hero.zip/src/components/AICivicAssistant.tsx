import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Sparkles, 
  Send, 
  Paperclip, 
  X, 
  Trash2, 
  Check, 
  AlertTriangle, 
  Loader2, 
  FileText, 
  CheckCircle, 
  ArrowRight, 
  User,
  Info,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DraftIssueData {
  title: string;
  category: string;
  location: string;
  description: string;
  urgency: 'Low' | 'Medium' | 'High';
}

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
  isDraft?: boolean;
  draftData?: DraftIssueData;
  isFiled?: boolean;
  filedId?: string;
  attachedFile?: { name: string; size: string };
}

export default function AICivicAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-1',
      sender: 'ai',
      text: "Hello! I am your AI Civic Assistant. I can help you understand municipal rules, summarize neighborhood issues, or guide you on how to report a hazard. How can I help today?",
      timestamp: "10:50 AM"
    }
  ]);

  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ name: string; size: string } | null>(null);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Quick Action Pills
  const quickActions = [
    { label: "🚨 Guide: Report Hazard", text: "How do I report a water leakage or broken streetlight near Panvel station?" },
    { label: "📊 Summarize this week's issues", text: "Give me a summary of the reported issues in my ward this week." },
    { label: "❓ Who is my local ward officer?", text: "Who is the designated ward officer for New Panvel and what are their contact details?" }
  ];

  // Auto scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Utility to show temporary toast inside the assistant panel
  const triggerToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Trigger file click
  const handlePaperclipClick = () => {
    fileInputRef.current?.click();
  };

  // Handle selected file attachment
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAttachedFile({
        name: file.name,
        size: (file.size / 1024).toFixed(1) + ' KB'
      });
      triggerToast(`Attached ${file.name} successfully.`, 'info');
    }
  };

  // Remove attachment
  const handleRemoveAttachment = () => {
    setAttachedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Handle Starting a New Chat Session
  const handleNewChat = () => {
    const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages([
      {
        id: `initial-${Date.now()}`,
        sender: 'ai',
        text: "Hello! I am your AI Civic Assistant. I can help you understand municipal rules, summarize neighborhood issues, or guide you on how to report a hazard. How can I help today?",
        timestamp: currentTime
      }
    ]);
    setInput('');
    setAttachedFile(null);
    setIsTyping(false);
    triggerToast("New chat session started", "info");
  };

  // Send message
  const handleSend = (messageText: string) => {
    const trimmed = messageText.trim();
    if (!trimmed && !attachedFile) return;

    const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMsgId = `user-${Date.now()}`;
    
    const userMessage: Message = {
      id: userMsgId,
      sender: 'user',
      text: trimmed || `Sent uploaded document: ${attachedFile?.name}`,
      timestamp: currentTime,
      attachedFile: attachedFile ? attachedFile : undefined
    };

    // Update messages with user query
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setAttachedFile(null);
    setIsTyping(true);

    // Determine simulated response based on user input
    let responseText = "I am currently in prototype mode. Please use the quick action buttons for standard municipal queries!";
    const queryLower = trimmed.toLowerCase();

    if (queryLower.includes("how do i report") || queryLower.includes("water leakage") || queryLower.includes("report hazard")) {
      responseText = "To report a hazard, navigate to the 'Explore & Report' tab and click the '+ Report Issue' button. Upload a clear photo of the issue. My vision systems will automatically detect the hazard type (like Potholes or Water Leaks) and route it to the correct department.";
    } else if (queryLower.includes("summary of the reported") || queryLower.includes("summarize") || queryLower.includes("reported issues")) {
      responseText = "This week in Panvel: 12 new issues were reported. 8 were related to Water Supply, and 4 were Infrastructure. The community verified 10 of these, and the municipality has already resolved 3.";
    } else if (queryLower.includes("ward officer") || queryLower.includes("who is the designated") || queryLower.includes("who is my local")) {
      responseText = "Based on your saved zone (Sector 15), your local Ward Officer is Mr. Rajesh Patil (Ward A). For emergency escalations, his public municipal contact is 022-2745-XXXX.";
    }

    setTimeout(() => {
      const aiMessage: Message = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 600);
  };

  // Submit report to server
  const handleAutoFileTicket = async (messageId: string, draft: DraftIssueData) => {
    try {
      const response = await fetch('/api/issues', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: draft.title,
          category: draft.category,
          location: draft.location,
          description: draft.description,
          urgency: draft.urgency,
          isAnonymous: false,
          reporterName: "Resident (AI-Drafted)"
        })
      });

      if (!response.ok) {
        throw new Error("Failed to register issue on the server");
      }

      const registeredIssue = await response.json();

      setMessages(prev => prev.map(msg => {
        if (msg.id === messageId) {
          return {
            ...msg,
            isFiled: true,
            filedId: registeredIssue.id
          };
        }
        return msg;
      }));

      triggerToast(`Ticket ${registeredIssue.id} filed! Earned +50 Reputation points.`, 'success');
    } catch (err) {
      console.error(err);
      triggerToast("Failed to file ticket automatically. Please try manually.", "error");
    }
  };

  return (
    <div id="ai-civic-assistant-tab" className="flex flex-col h-full bg-slate-100 relative max-w-none w-full overflow-hidden">
      
      {/* 1. THE STICKY HEADER */}
      <header className="bg-white border-b border-slate-200/80 px-4 py-3 shrink-0 flex items-center justify-between sticky top-0 z-10 shadow-3xs">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center border border-emerald-100 shadow-3xs shrink-0">
            <Bot className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-xs font-extrabold text-slate-800 tracking-tight font-display">AI Civic Assistant</h2>
              <span className="flex h-1.5 w-1.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
              </span>
            </div>
            <div className="flex items-center gap-1 text-[10px] text-slate-400 font-semibold">
              <span>Powered by Gemini</span>
              <span className="text-[8px] bg-slate-100 text-slate-500 border border-slate-200 px-1 rounded-sm uppercase tracking-wider font-mono">1.5 Flash</span>
            </div>
          </div>
        </div>
        
        {/* Help indicators & New Chat */}
        <div className="flex items-center gap-2">
          <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-50 border border-indigo-100 rounded-md text-[9px] font-bold text-indigo-600 uppercase font-mono tracking-wider">
            <Sparkles className="w-2.5 h-2.5" /> Interactive Agent
          </span>
          <button
            type="button"
            onClick={handleNewChat}
            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 font-extrabold rounded-lg shadow-3xs transition cursor-pointer text-[10px] flex items-center gap-1 border border-slate-250 shrink-0"
          >
            <span>🔄 New Chat</span>
          </button>
        </div>
      </header>

      {/* Internal Panel Toast Notifications */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="absolute top-16 left-1/2 -translate-x-1/2 z-50 w-full max-w-xs px-3"
          >
            <div className={`p-3 rounded-xl shadow-lg border text-[10.5px] font-bold flex items-center gap-2 ${
              toastMessage.type === 'success' 
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                : toastMessage.type === 'error'
                ? 'bg-rose-50 border-rose-200 text-rose-800'
                : 'bg-indigo-50 border-indigo-200 text-indigo-800'
            }`}>
              {toastMessage.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />}
              {toastMessage.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />}
              {toastMessage.type === 'info' && <Info className="w-4 h-4 text-indigo-600 shrink-0" />}
              <span className="flex-1 leading-snug">{toastMessage.text}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MUNICIPAL CO-PILOT BANNER (Just above the chat history) */}
      <div className="bg-indigo-50/40 border-b border-slate-200/60 px-4 py-2.5 text-left shrink-0">
        <div className="max-w-4xl mx-auto flex items-start gap-2">
          <Sparkles className="w-3.5 h-3.5 text-indigo-600 mt-0.5 shrink-0" />
          <div>
            <h4 className="text-[10px] font-bold text-indigo-950 uppercase font-mono tracking-wider leading-none">
              MUNICIPAL CO-PILOT
            </h4>
            <p className="text-[10.5px] text-slate-600 font-medium leading-normal mt-1">
              This chatbot connects directly to Panvel Municipal guidelines. Describe any hazard you encounter, and it will help categorize the issue and draft a formal dispatch ticket.
            </p>
          </div>
        </div>
      </div>

      {/* 2. THE CHAT HISTORY AREA (Scrollable, gray/off-white background) */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
        
        {/* Message Stream */}
        {messages.map((msg) => {
          const isAI = msg.sender === 'ai';
          return (
            <div 
              key={msg.id}
              className={`flex gap-3 max-w-4xl mx-auto ${isAI ? 'justify-start' : 'justify-end'}`}
            >
              {/* Bot Avatar */}
              {isAI && (
                <div className="w-7 h-7 bg-white border border-slate-200 rounded-lg flex items-center justify-center text-slate-500 shadow-2xs shrink-0 self-start">
                  <Bot className="w-4 h-4 text-indigo-600" />
                </div>
              )}

              <div className="space-y-1.5 text-left max-w-[85%] sm:max-w-[70%]">
                {/* Bubble Container */}
                <div className={`p-3.5 rounded-2xl shadow-3xs text-xs leading-relaxed font-medium ${
                  isAI 
                    ? 'bg-white border border-slate-200/80 text-slate-800 rounded-tl-none' 
                    : 'bg-indigo-600 text-white rounded-tr-none'
                }`}>
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* Attached Document indicator inside bubble */}
                  {msg.attachedFile && (
                    <div className="mt-2.5 p-2 bg-indigo-700/50 rounded-xl flex items-center justify-between gap-3 text-[10px] text-indigo-100 font-semibold border border-indigo-500/20">
                      <div className="flex items-center gap-1.5 truncate">
                        <Paperclip className="w-3.5 h-3.5 text-indigo-300" />
                        <span className="truncate">{msg.attachedFile.name}</span>
                      </div>
                      <span className="font-mono text-[9px] text-indigo-200">{msg.attachedFile.size}</span>
                    </div>
                  )}
                </div>

                {/* AI Draft Issue Ticket Box */}
                {isAI && msg.isDraft && msg.draftData && (
                  <div className="bg-white border border-indigo-100 rounded-2xl p-4 shadow-sm space-y-3 mt-2 text-left animate-fade-in border-t-4 border-t-indigo-600">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="p-1 bg-indigo-50 text-indigo-600 rounded-md">
                          <FileText className="w-3.5 h-3.5" />
                        </span>
                        <h4 className="text-[11px] font-extrabold text-slate-800 tracking-tight font-display">Auto-Drafted Incident Ticket</h4>
                      </div>
                      
                      {/* Urgency Badge */}
                      <span className={`px-2 py-0.5 border text-[8.5px] font-extrabold rounded-md font-mono uppercase tracking-wider ${
                        msg.draftData.urgency === 'High' 
                          ? 'bg-rose-50 text-rose-700 border-rose-200' 
                          : msg.draftData.urgency === 'Medium'
                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                          : 'bg-blue-50 text-blue-700 border-blue-200'
                      }`}>
                        {msg.draftData.urgency} Priority
                      </span>
                    </div>

                    <div className="space-y-2 border-y border-slate-100 py-3 text-[11px]">
                      <div>
                        <span className="font-bold text-slate-400 uppercase tracking-wider font-mono text-[9px]">Title:</span>
                        <p className="font-semibold text-slate-800 mt-0.5">{msg.draftData.title}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div>
                          <span className="font-bold text-slate-400 uppercase tracking-wider font-mono text-[9px]">Category:</span>
                          <p className="font-bold text-slate-700 mt-0.5 text-[10px]">{msg.draftData.category}</p>
                        </div>
                        <div>
                          <span className="font-bold text-slate-400 uppercase tracking-wider font-mono text-[9px]">Location:</span>
                          <p className="font-bold text-slate-700 mt-0.5 text-[10px] truncate" title={msg.draftData.location}>{msg.draftData.location}</p>
                        </div>
                      </div>
                      <div className="pt-1">
                        <span className="font-bold text-slate-400 uppercase tracking-wider font-mono text-[9px]">AI Summary:</span>
                        <p className="text-slate-600 mt-0.5 leading-relaxed">{msg.draftData.description}</p>
                      </div>
                    </div>

                    {/* Action button inside ticket draft */}
                    <div>
                      {msg.isFiled ? (
                        <div className="flex items-center justify-center gap-1.5 p-2 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-200 text-[10.5px] font-bold">
                          <Check className="w-4 h-4 text-emerald-600" />
                          <span>Filed Successfully! (ID: {msg.filedId})</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleAutoFileTicket(msg.id, msg.draftData!)}
                          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[10.5px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-98"
                        >
                          <span>🚀 Auto-File Municipal Ticket</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* Message Timestamp */}
                <span className={`block text-[9px] text-slate-400 font-bold font-mono tracking-wider px-1 ${
                  isAI ? 'text-left' : 'text-right'
                }`}>
                  {msg.timestamp}
                </span>
              </div>

              {/* User Avatar Placeholder */}
              {!isAI && (
                <div className="w-7 h-7 bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg flex items-center justify-center font-bold text-[10px] shadow-2xs shrink-0 self-start">
                  <User className="w-4 h-4 text-indigo-600" />
                </div>
              )}
            </div>
          );
        })}

        {/* Typing State Indicator */}
        {isTyping && (
          <div className="flex gap-3 max-w-4xl mx-auto justify-start">
            <div className="w-7 h-7 bg-white border border-slate-200 rounded-lg flex items-center justify-center text-slate-500 shadow-2xs shrink-0 self-start">
              <Bot className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="space-y-1.5 text-left">
              <div className="bg-white border border-slate-200/80 text-slate-800 p-4 rounded-2xl rounded-tl-none shadow-3xs flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 text-indigo-600 animate-spin" />
                <span className="text-xs text-slate-500 font-bold font-mono tracking-wider animate-pulse">AI Civic Assistant is thinking...</span>
              </div>
            </div>
          </div>
        )}

        {/* Reference element for scroll anchoring */}
        <div ref={messagesEndRef} />
      </div>

      {/* 3. QUICK ACTION ROW + ATTACHMENT STATUS + INPUT BAR CONTAINER */}
      <div className="bg-white border-t border-slate-200 p-3 shrink-0 flex flex-col gap-2.5 pb-[72px] md:pb-3 shadow-md z-10">
        
        {/* Quick Action Pills (Horizontally scrollable, 3-4 tiny chips) */}
        <div className="flex gap-2 overflow-x-auto py-1 px-1 scrollbar-none shrink-0 text-left -mx-3 px-4">
          {quickActions.map((act, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSend(act.text)}
              className="bg-slate-50 hover:bg-indigo-50/60 text-slate-700 hover:text-indigo-800 border border-slate-200 hover:border-indigo-200/50 rounded-full px-3 py-1.5 text-[10px] font-bold tracking-tight shrink-0 transition flex items-center gap-1.5 cursor-pointer shadow-3xs hover:scale-[1.01]"
            >
              <span>{act.label}</span>
              <ArrowRight className="w-3 h-3 text-slate-400 group-hover:text-indigo-600" />
            </button>
          ))}
        </div>

        {/* File Attachment status notification banner */}
        {attachedFile && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center justify-between gap-3 p-2 bg-indigo-50 border border-indigo-100 rounded-xl text-[10.5px] font-bold text-indigo-900 mx-1"
          >
            <div className="flex items-center gap-2 truncate">
              <span className="p-1.5 bg-indigo-600 text-white rounded-lg">
                <Paperclip className="w-3.5 h-3.5" />
              </span>
              <span className="truncate" title={attachedFile.name}>{attachedFile.name}</span>
              <span className="text-[9px] text-indigo-400 font-mono">({attachedFile.size})</span>
            </div>
            <button
              type="button"
              onClick={handleRemoveAttachment}
              className="p-1 hover:bg-indigo-100 text-indigo-500 hover:text-indigo-700 rounded-lg transition shrink-0"
              title="Remove file"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}

        {/* 4. THE INPUT BAR */}
        <div className="flex items-center gap-2 w-full max-w-4xl mx-auto relative">
          {/* File Input handler */}
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileChange}
            accept=".png,.jpg,.jpeg,.pdf,.doc,.docx"
            className="hidden"
          />

          {/* Attachment Paperclip Icon Button */}
          <button
            type="button"
            onClick={handlePaperclipClick}
            className={`p-3 border rounded-xl flex items-center justify-center transition shrink-0 cursor-pointer ${
              attachedFile 
                ? 'bg-indigo-50 border-indigo-200 text-indigo-600 hover:bg-indigo-100' 
                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600'
            }`}
            title="Attach Municipal Bill/Notice or Photo Proof"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          {/* Text Input Field */}
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleSend(input);
              }
            }}
            placeholder="Ask about local rules, issues, or guidelines..."
            className="flex-1 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200/80 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 rounded-xl px-4 py-3 text-xs focus:outline-hidden font-semibold placeholder-slate-400 shadow-2xs transition"
          />

          {/* Send Icon Button */}
          <button
            type="button"
            onClick={() => handleSend(input)}
            disabled={!input.trim() && !attachedFile}
            className="p-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-100 text-white disabled:text-slate-400 border border-transparent rounded-xl flex items-center justify-center transition shrink-0 cursor-pointer shadow-sm hover:scale-[1.02] active:scale-[0.98] disabled:scale-100 disabled:pointer-events-none"
            title="Send Message"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

      </div>

    </div>
  );
}
