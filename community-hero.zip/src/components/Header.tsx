import React from 'react';
import { ShieldCheck, UserCheck, Radio, Sparkles } from 'lucide-react';

interface HeaderProps {
  currentView: 'citizen' | 'authority';
  onSwitchView: (view: 'citizen' | 'authority') => void;
  pendingCount: number;
}

export default function Header({ currentView, onSwitchView, pendingCount }: HeaderProps) {
  return (
    <header className="h-14 border-b bg-white flex items-center justify-between px-6 shrink-0 z-20 shadow-xs select-none">
      {/* Left Side: App branding */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-lg font-display shadow-xs shadow-indigo-500/20">
          C
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-sm sm:text-base tracking-tight text-slate-900 font-display">
              Community Hero <span className="text-indigo-600">AI</span>
            </span>
            <span className="bg-indigo-50 text-[9px] text-indigo-600 border border-indigo-100 font-bold px-1.5 py-0.2 rounded-full font-mono uppercase tracking-wider">
              Live
            </span>
          </div>
        </div>
      </div>

      {/* Center Side: Demo Mode Switcher (Tab switchers) */}
      <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 shrink-0">
        <button
          onClick={() => onSwitchView('citizen')}
          className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
            currentView === 'citizen'
              ? 'bg-white text-indigo-600 shadow-xs'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <UserCheck className="h-3.5 w-3.5" />
          <span>Citizen View</span>
        </button>
        
        <button
          onClick={() => onSwitchView('authority')}
          className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
            currentView === 'authority'
              ? 'bg-white text-indigo-600 shadow-xs'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <ShieldCheck className="h-3.5 w-3.5" />
          <span>Authority View</span>
          {pendingCount > 0 && (
            <span className="bg-indigo-600 text-white text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
              {pendingCount}
            </span>
          )}
        </button>
      </div>

      {/* Right Side: Pulse Status */}
      <div className="hidden sm:flex items-center gap-4">
        <div className="flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-100">
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
          <span className="text-[9px] font-bold uppercase tracking-wider">System Active</span>
        </div>
      </div>
    </header>
  );
}

