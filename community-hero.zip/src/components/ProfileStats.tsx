import React, { useState, useRef } from 'react';
import { 
  User, 
  Award, 
  Shield, 
  CheckCircle, 
  Plus, 
  MapPin, 
  X, 
  Smartphone, 
  Check, 
  Compass,
  Edit2,
  Lock,
  Search,
  Map,
  BadgeAlert,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CivicZone {
  id: string;
  name: string;
  location: string;
  isDefault: boolean;
}

export default function ProfileStats() {
  // 1. User Info State
  const [displayName, setDisplayName] = useState('Aarav Sharma');
  const [isEditingName, setIsEditingName] = useState(false);
  const avatars = ['🛡️', '🌳', '👷‍♂️', '🦉', '🏛️', '🔍'];
  const [avatarIndex, setAvatarIndex] = useState(0);
  const [isAvatarOpen, setIsAvatarOpen] = useState(false);
  
  // 2. Mobile Verification State
  const [mobileNumber, setMobileNumber] = useState('+91 99999 54321');
  const [isMobileModalOpen, setIsMobileModalOpen] = useState(false);
  const [newMobileInput, setNewMobileInput] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [otpInput, setOtpInput] = useState('');

  // Toast notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // 3. Civic Zones State
  const [zones, setZones] = useState<CivicZone[]>([
    { id: '1', name: 'Home', location: 'Sector 15, New Panvel', isDefault: true },
    { id: '2', name: 'Work', location: 'Kamothe, Sector 6', isDefault: false }
  ]);

  // 4. Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [newZoneName, setNewZoneName] = useState('');
  const [newZoneLocation, setNewZoneLocation] = useState('');
  const [setAsDefault, setSetAsDefault] = useState(false);
  const [isSimulatingLocation, setIsSimulatingLocation] = useState(false);

  // Interactive Map State
  const sectors = [
    { id: 'sec-15', name: "Sector 15", desc: "Sector 15, New Panvel" },
    { id: 'kamothe', name: "Kamothe Market", desc: "Kamothe, Sector 6" },
    { id: 'highway', name: "Panvel Highway", desc: "National Highway 48, Panvel" },
    { id: 'station', name: "Panvel Station", desc: "Panvel Junction Area" },
    { id: 'sec-19', name: "Sector 19", desc: "Sector 19, New Panvel East" },
    { id: 'khandeshwar', name: "Khandeshwar", desc: "Khandeshwar, Sector 8" }
  ];
  const [selectedSectorId, setSelectedSectorId] = useState<string | null>(null);

  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Helper for quick alerts/toasts inside Profile tab
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    if (toastTimeoutRef.current) {
      clearTimeout(toastTimeoutRef.current);
    }
    toastTimeoutRef.current = setTimeout(() => {
      setToastMessage(null);
      toastTimeoutRef.current = null;
    }, 3500);
  };

  // Delete a zone
  const handleDeleteZone = (id: string) => {
    setZones(prev => {
      const filtered = prev.filter(z => z.id !== id);
      // Ensure at least one default remains if available
      if (filtered.length > 0 && !filtered.some(z => z.isDefault)) {
        filtered[0].isDefault = true;
      }
      return filtered;
    });
    triggerToast('Civic Zone removed.');
  };

  // Set Default Zone
  const handleSetDefault = (id: string) => {
    setZones(prev => prev.map(z => ({
      ...z,
      isDefault: z.id === id
    })));
    triggerToast('Default Civic Zone updated.');
  };

  // Handle live location simulation
  const handleUseCurrentLocation = () => {
    setIsSimulatingLocation(true);
    setTimeout(() => {
      setSelectedSectorId('sec-15');
      setNewZoneLocation('Selected: Sector 15, New Panvel');
      setSearchQuery('Selected: Sector 15, New Panvel');
      if (!newZoneName) {
        setNewZoneName('Sector 15');
      }
      setIsSimulatingLocation(false);
      triggerToast('GPS location snapped to Sector 15 successfully!');
    }, 1200);
  };

  // Save new Civic Zone
  const handleSaveZone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newZoneName.trim() || !newZoneLocation.trim()) {
      triggerToast('Please provide both a name and location.');
      return;
    }

    const newZone: CivicZone = {
      id: Date.now().toString(),
      name: newZoneName,
      location: newZoneLocation,
      isDefault: setAsDefault || zones.length === 0
    };

    setZones(prev => {
      let updated = [...prev];
      if (newZone.isDefault) {
        updated = updated.map(z => ({ ...z, isDefault: false }));
      }
      return [...updated, newZone];
    });

    // Reset fields
    setNewZoneName('');
    setNewZoneLocation('');
    setSearchQuery('');
    setSelectedSectorId(null);
    setSetAsDefault(false);
    setIsModalOpen(false);
    triggerToast(`Added Civic Zone "${newZone.name}" successfully!`);
  };

  return (
    <div id="profile-stats-tab" className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-6 relative text-left">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] w-full max-w-md px-4"
          >
            <div className="bg-slate-900 text-white p-3.5 rounded-2xl shadow-2xl border border-slate-800 text-xs font-bold flex items-center gap-2.5">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="flex-1 leading-snug">{toastMessage}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 1. USER INFO CARD (Top Section) */}
      <div className="bg-white border border-slate-200 rounded-[28px] p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          
          {/* Avatar Area */}
          <div className="flex flex-col items-center gap-2 shrink-0 relative">
            <div 
              onClick={() => setIsAvatarOpen(!isAvatarOpen)}
              className="w-24 h-24 bg-gradient-to-br from-indigo-50 to-slate-100 border-2 border-indigo-100 rounded-3xl flex items-center justify-center text-4xl shadow-xs relative select-none cursor-pointer hover:scale-105 active:scale-95 transition group"
              title="Click to Choose Avatar"
            >
              <span>{avatars[avatarIndex]}</span>
              <div className="absolute -bottom-1.5 -right-1.5 bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-xl shadow-md border border-white transition">
                <Edit2 className="w-3.5 h-3.5" />
              </div>
            </div>
            
            <button
              type="button"
              onClick={() => setIsAvatarOpen(!isAvatarOpen)}
              className="text-[10px] text-indigo-600 hover:text-indigo-700 font-extrabold uppercase tracking-wider font-mono cursor-pointer"
            >
              Choose Avatar
            </button>

            {/* Avatar Selection Grid Popup (3x2 Grid) */}
            <AnimatePresence>
              {isAvatarOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute top-28 left-1/2 -translate-x-1/2 z-20 bg-white border border-slate-200 shadow-xl rounded-2xl p-3 w-48 space-y-2"
                >
                  <p className="text-[9px] font-extrabold text-slate-400 uppercase tracking-wider font-mono text-center">Select Avatar</p>
                  <div className="grid grid-cols-3 gap-2">
                    {avatars.map((emoji, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setAvatarIndex(idx);
                          setIsAvatarOpen(false);
                          triggerToast('Avatar updated successfully!');
                        }}
                        className={`text-2xl p-2 rounded-xl hover:bg-slate-50 transition border flex items-center justify-center cursor-pointer ${
                          avatarIndex === idx ? 'border-indigo-500 bg-indigo-50/50' : 'border-slate-100'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Core Info & Profile Editing */}
          <div className="flex-1 text-center sm:text-left space-y-3 w-full">
            <div className="space-y-1">
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 justify-center sm:justify-start">
                {isEditingName ? (
                  <div className="flex items-center gap-2 w-full max-w-sm justify-center sm:justify-start mt-1">
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="bg-slate-50 border border-slate-300 focus:border-indigo-500 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800 outline-hidden focus:ring-2 focus:ring-indigo-100 transition w-full"
                      placeholder="Enter Display Name"
                      maxLength={24}
                    />
                    <button
                      type="button"
                      onClick={() => setIsEditingName(false)}
                      className="bg-indigo-600 text-white px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-indigo-700 cursor-pointer shadow-xs shrink-0"
                    >
                      Save
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 justify-center sm:justify-start">
                    <h2 className="text-xl font-extrabold tracking-tight text-slate-900 font-display">
                      {displayName || 'Anonymous Resident'}
                    </h2>
                    <button
                      type="button"
                      onClick={() => setIsEditingName(true)}
                      className="text-slate-400 hover:text-indigo-600 transition p-1 rounded-lg"
                      title="Edit Display Name"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
                
                <span className="self-center sm:self-start px-2.5 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-100 text-[9.5px] font-extrabold uppercase tracking-wider rounded-md font-mono mt-0.5">
                  🛡️ Active Hero
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                Citizen of New Panvel since 2024 • Verified Resident
              </p>
            </div>

            {/* Helper notice */}
            <p className="text-[10px] text-slate-500 leading-normal bg-slate-50 border border-slate-100 rounded-xl p-2.5 max-w-lg">
              <span className="font-bold text-slate-700">🔒 Privacy:</span> Your display name is always hidden when you use the <span className="font-bold text-indigo-600">"Report Anonymously"</span> feature on issues.
            </p>

            {/* Reputation Info with Progress Bar */}
            <div className="pt-2 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                <span className="flex items-center gap-1">
                  <Award className="w-4 h-4 text-amber-500" />
                  <span>450 Reputation Points</span>
                </span>
                <span className="text-[10px] font-extrabold uppercase font-mono text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                  Level 3: Warden
                </span>
              </div>

              {/* Progress Bar */}
              <div className="space-y-1">
                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden border border-slate-200/50">
                  <div className="bg-gradient-to-r from-indigo-500 to-indigo-600 h-full rounded-full" style={{ width: '90%' }} />
                </div>
                <p className="text-[10px] text-slate-400 font-bold font-mono tracking-wide text-right">
                  50 Rep until Civic Warden (500 pts)
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* 2. ACCOUNT SETTINGS & SECURITY */}
      <div className="bg-white border border-slate-200 rounded-[24px] p-6 shadow-sm space-y-4">
        <h3 className="text-xs font-extrabold text-slate-800 tracking-wider uppercase font-mono flex items-center gap-2">
          <Lock className="w-4 h-4 text-slate-400" /> Account Settings
        </h3>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 bg-slate-50 border border-slate-200/60 rounded-2xl">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-slate-700 font-bold text-xs">
              <Smartphone className="w-4 h-4 text-slate-400 shrink-0" />
              <span>Linked Mobile Number</span>
            </div>
            <p className="text-xs text-slate-500 font-bold font-mono pl-6">
              Linked Mobile: {mobileNumber}
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setNewMobileInput(mobileNumber);
              setIsMobileModalOpen(true);
            }}
            className="px-3 py-1.5 bg-white border border-slate-200 hover:border-slate-300 rounded-xl text-[10.5px] font-extrabold text-slate-700 hover:bg-slate-50 transition cursor-pointer shadow-3xs"
          >
            [ Update ]
          </button>
        </div>
      </div>

      {/* 3. STATS CARDS (Middle Section) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* Reports Filed Card */}
        <div className="bg-white border border-slate-200 p-5 rounded-[24px] shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">Reports Filed</span>
            <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <Shield className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-extrabold text-slate-900 font-display">12</p>
          <p className="text-[10px] font-semibold text-slate-500">10 resolved in the community</p>
        </div>

        {/* Upvotes Received Card */}
        <div className="bg-white border border-slate-200 p-5 rounded-[24px] shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">Upvotes Received</span>
            <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-extrabold text-slate-900 font-display">243</p>
          <p className="text-[10px] font-semibold text-slate-500">Ranked top 10% in New Panvel</p>
        </div>

        {/* Verification Rate Card */}
        <div className="bg-white border border-slate-200 p-5 rounded-[24px] shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">Verification Rate</span>
            <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-extrabold text-slate-900 font-display">100%</p>
          <p className="text-[10px] font-semibold text-slate-500">All filed reports verified by admins</p>
        </div>

      </div>

      {/* 4. MY CIVIC ZONES (Bottom Section) */}
      <div className="bg-white border border-slate-200 rounded-[28px] p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-xs font-extrabold text-slate-800 tracking-wider uppercase font-mono flex items-center gap-2">
              <Compass className="w-4 h-4 text-slate-400" /> My Civic Zones
            </h3>
            <p className="text-[10px] text-slate-500 font-semibold mt-0.5">Saved locations for localized municipal alert feeds</p>
          </div>
          
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[10.5px] font-extrabold transition flex items-center gap-1 cursor-pointer shadow-xs shrink-0 active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Zone</span>
          </button>
        </div>

        {/* Zones List Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <AnimatePresence>
            {zones.map((zone) => (
              <motion.div
                key={zone.id}
                layoutId={`zone-card-${zone.id}`}
                className={`p-4 rounded-2xl border transition relative flex items-start justify-between gap-3 ${
                  zone.isDefault
                    ? 'bg-indigo-50/40 border-indigo-200 shadow-3xs'
                    : 'bg-slate-50/50 border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="space-y-1.5 text-left">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-slate-800 font-display">{zone.name}</span>
                    {zone.isDefault ? (
                      <span className="px-2 py-0.5 bg-indigo-600 text-white text-[8px] font-extrabold uppercase font-mono tracking-wider rounded-md">
                        Default
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleSetDefault(zone.id)}
                        className="text-[9px] text-slate-400 hover:text-indigo-600 font-extrabold uppercase font-mono tracking-wider cursor-pointer"
                        title="Set as Default Feed"
                      >
                        Set Default
                      </button>
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-[11px] text-slate-500 font-medium">
                    <MapPin className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                    <span className="truncate" title={zone.location}>{zone.location}</span>
                  </div>
                </div>

                {/* Remove button */}
                <button
                  type="button"
                  onClick={() => handleDeleteZone(zone.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition shrink-0 cursor-pointer"
                  title="Remove Zone"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {zones.length === 0 && (
            <div className="col-span-full py-8 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50">
              <Compass className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-700">No Custom Civic Zones Saved</p>
              <p className="text-[10px] text-slate-400 mt-1">Add zones to quickly filter issues in your community.</p>
            </div>
          )}
        </div>
      </div>

      {/* 5. ADD LOCATION MODAL (Google Maps Flow Simulation) */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white rounded-[28px] border border-slate-100 shadow-2xl max-w-md w-full overflow-hidden text-left"
              onClick={(e) => e.stopPropagation()}
            >
              
              {/* Header */}
              <div className="bg-slate-50 border-b border-slate-200 px-5 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                    <Map className="w-4 h-4" />
                  </div>
                  <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider font-mono">Add Civic Zone</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Form/Simulation Body */}
              <form onSubmit={handleSaveZone} className="p-5 space-y-4">
                
                {/* Search Bar */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">Locate building or street</label>
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        setNewZoneLocation(e.target.value);
                      }}
                      placeholder="Search building, street, or area..."
                      className="bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl pl-9 pr-3 py-2 text-xs w-full outline-hidden font-semibold placeholder-slate-400 focus:bg-white focus:ring-2 focus:ring-indigo-500/10 transition"
                    />
                  </div>
                </div>

                {/* Interactive Map Grid Component */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">1. Tap Map Zone to Pinpoint</label>
                  
                  <div className="border border-slate-200 rounded-2xl bg-slate-950 p-3.5 relative overflow-hidden flex flex-col gap-2.5 shadow-inner">
                    {/* Futuristic map grid lines in background */}
                    <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px]" />
                    <div className="absolute top-2 right-2 flex items-center gap-1 text-[8px] font-mono text-emerald-400 font-bold bg-emerald-950/80 border border-emerald-800/40 px-1.5 py-0.5 rounded-sm uppercase tracking-wider">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                      GPS Connected
                    </div>

                    {/* Sector Map Grid */}
                    <div className="grid grid-cols-3 gap-2 z-10 relative">
                      {sectors.map((sec) => {
                        const isSelected = selectedSectorId === sec.id;
                        return (
                          <button
                            type="button"
                            key={sec.id}
                            onClick={() => {
                              setSelectedSectorId(sec.id);
                              setNewZoneLocation(`Selected: ${sec.desc}`);
                              setSearchQuery(`Selected: ${sec.desc}`);
                              if (!newZoneName) {
                                setNewZoneName(sec.name);
                              }
                            }}
                            className={`h-16 rounded-xl border p-2 flex flex-col justify-between text-left transition relative cursor-pointer group ${
                              isSelected
                                ? 'bg-indigo-600/20 border-indigo-500 shadow-xs'
                                : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                            }`}
                          >
                            <span className={`text-[9px] font-extrabold uppercase font-mono tracking-wide ${
                              isSelected ? 'text-indigo-300' : 'text-slate-500 group-hover:text-slate-400'
                            }`}>
                              {sec.id.toUpperCase()}
                            </span>
                            <span className={`text-[10px] font-bold tracking-tight truncate w-full ${
                              isSelected ? 'text-white font-extrabold' : 'text-slate-300'
                            }`}>
                              {sec.name}
                            </span>

                            {/* Marker badge inside cell */}
                            {isSelected && (
                              <div className="absolute -top-1 -right-1 bg-indigo-600 text-white p-1 rounded-full shadow-md animate-bounce">
                                <span className="text-xs">📍</span>
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {isSimulatingLocation && (
                      <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-3xs flex flex-col items-center justify-center p-3 z-20">
                        <Loader2 className="w-6 h-6 text-indigo-400 animate-spin mb-2" />
                        <p className="text-[10.5px] font-bold text-slate-300 font-mono">Calibrating active coordinates...</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Live GPS Trigger Button */}
                <button
                  type="button"
                  onClick={handleUseCurrentLocation}
                  className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-[10.5px] font-extrabold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-3xs"
                >
                  <Compass className="w-4 h-4" />
                  <span>📍 Use Current Live Location</span>
                </button>

                {/* Location Display Input */}
                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">Pinpointed Address</label>
                  <input
                    type="text"
                    value={newZoneLocation}
                    onChange={(e) => setNewZoneLocation(e.target.value)}
                    placeholder="Sector 19, New Panvel East..."
                    className="bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs w-full outline-hidden font-semibold placeholder-slate-400 focus:bg-white transition font-medium"
                    required
                  />
                </div>

                {/* Zone Label/Name Input */}
                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">2. Label this Zone</label>
                  <input
                    type="text"
                    value={newZoneName}
                    onChange={(e) => setNewZoneName(e.target.value)}
                    placeholder="e.g., Parents' House, Playground"
                    className="bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs w-full outline-hidden font-semibold placeholder-slate-400 focus:bg-white transition font-medium"
                    required
                  />
                </div>

                {/* Checkbox Default option */}
                <label className="flex items-center gap-2 pt-1 text-slate-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={setAsDefault}
                    onChange={(e) => setSetAsDefault(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 border-slate-300 rounded-md focus:ring-indigo-500 cursor-pointer"
                  />
                  <span className="text-[11px] font-bold text-slate-600">Set as Default Feed Location</span>
                </label>

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 py-2.5 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer text-center"
                  >
                    Save Zone
                  </button>
                </div>

              </form>

            </motion.div>

          </div>
        )}
      </AnimatePresence>

      {/* Mobile Verification Modal */}
      <AnimatePresence>
        {isMobileModalOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white rounded-[28px] border border-slate-100 shadow-2xl max-w-sm w-full overflow-hidden text-left"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-slate-50 border-b border-slate-200 px-5 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider font-mono">Verify New Mobile Number</h3>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setIsMobileModalOpen(false);
                    setIsOtpSent(false);
                    setOtpInput('');
                  }}
                  className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-5 space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">New Mobile Number</label>
                  <input
                    type="tel"
                    value={newMobileInput}
                    onChange={(e) => setNewMobileInput(e.target.value)}
                    placeholder="e.g., +91 98765 43210"
                    disabled={isOtpSent}
                    className="bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs w-full outline-hidden font-semibold placeholder-slate-400 focus:bg-white focus:ring-2 focus:ring-indigo-500/10 transition disabled:opacity-60 font-medium"
                  />
                </div>

                {!isOtpSent ? (
                  <button
                    type="button"
                    onClick={() => {
                      if (!newMobileInput.trim()) {
                        triggerToast("Please enter a valid mobile number.");
                        return;
                      }
                      setIsOtpSent(true);
                      setOtpInput('5678'); // pre-filled with '5678'
                      triggerToast("Mock OTP sent to new number: 5678");
                    }}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    Send OTP
                  </button>
                ) : (
                  <div className="space-y-3 animate-fade-in">
                    <div className="p-2.5 bg-emerald-50 border border-emerald-100 text-[10px] font-bold text-emerald-800 rounded-xl flex items-center gap-1.5">
                      <span className="flex h-1.5 w-1.5 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                      </span>
                      <span>Mock OTP sent to new number!</span>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider font-mono">Enter 4-Digit OTP</label>
                      <input
                        type="text"
                        value={otpInput}
                        onChange={(e) => setOtpInput(e.target.value)}
                        placeholder="Enter 5678"
                        maxLength={4}
                        className="bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs w-full outline-hidden font-mono tracking-widest text-center font-bold placeholder-slate-400 focus:bg-white focus:ring-2 focus:ring-indigo-500/10 transition"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (otpInput === '5678') {
                          setMobileNumber(newMobileInput);
                          setIsMobileModalOpen(false);
                          setIsOtpSent(false);
                          setOtpInput('');
                          triggerToast("Mobile number updated and verified!");
                        } else {
                          triggerToast("Incorrect OTP! Use the mock OTP: 5678");
                        }
                      }}
                      className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      Confirm Change
                    </button>
                  </div>
                )}

                <div className="flex gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setIsMobileModalOpen(false);
                      setIsOtpSent(false);
                      setOtpInput('');
                    }}
                    className="w-full py-2 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition cursor-pointer text-center"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
