import React, { useState } from 'react';
import { 
  Users, 
  MessageSquare, 
  MapPin, 
  Sparkles, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  Send, 
  ShieldAlert, 
  Droplet, 
  Zap, 
  Trash2, 
  HardHat, 
  Bell, 
  ThumbsUp, 
  Check, 
  UploadCloud, 
  X, 
  Camera
} from 'lucide-react';

interface Comment {
  id: string;
  author: string;
  role: 'Resident' | 'Local Hero' | 'Inspector' | 'Ward Officer' | 'You';
  avatarColor: string;
  text: string;
  timestamp: string;
}

interface IssueCardProps {
  key?: any;
  ticket: {
    id: string;
    title: string;
    location?: string;
    locality?: string;
    tags?: string[];
    category?: string;
    status: string;
    tracked?: boolean;
    comments?: Comment[];
    iconType?: 'water' | 'road' | 'power' | 'sanitation' | 'safety';
    upvotes: number;
    verifications?: number;
    verifiedCount?: number;
    hasUpvoted?: boolean;
    verificationState?: 'unverified' | 'quick' | 'photo';
    description?: string;
    mockImages?: string[];
    photoUrl?: string;
  };
  setGlobalTickets: React.Dispatch<React.SetStateAction<any[]>>;
  triggerToast?: (message: string, type?: 'success' | 'info' | 'warning') => void;
  isSelected?: boolean;
  onSelect?: () => void;
}

export default function IssueCard({ ticket, setGlobalTickets, triggerToast, isSelected, onSelect }: IssueCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [openGallery, setOpenGallery] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const [uploadedFile, setUploadedFile] = useState<{ name: string; url: string } | null>(null);
  
  // Popover States
  const [activePopover, setActivePopover] = useState(false);
  const [popoverMode, setPopoverMode] = useState<'options' | 'photo_upload'>('options');
  const [isDispute, setIsDispute] = useState(false);

  // Fallbacks
  const tags = ticket.tags || (ticket.category ? [ticket.category] : []);
  const locality = ticket.locality || ticket.location?.split(',')[0] || 'Sector 15';
  const comments = ticket.comments || [];
  const iconType = ticket.iconType || 'water';
  const hasUpvoted = !!ticket.hasUpvoted;
  const tracked = !!ticket.tracked;
  const description = ticket.description || '';
  const verificationState = ticket.verificationState || 'unverified';
  const verifications = ticket.verifications !== undefined 
    ? ticket.verifications 
    : (ticket.verifiedCount !== undefined ? ticket.verifiedCount : 0);

  const getDisplayStatus = (status: string) => {
    const s = (status || '').toLowerCase();
    if (s === 'pending') return 'Received';
    if (s === 'assigned') return 'Team Assigned';
    if (s === 'inprogress' || s === 'in_progress') return 'In Progress';
    if (s === 'resolved') return 'Resolved';
    return status;
  };

  const displayStatus = getDisplayStatus(ticket.status);

  // Helper for status badge style
  const renderStatusBadge = (status: string) => {
    switch (status) {
      case 'Verified':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold rounded-md font-mono uppercase tracking-wider">
            <Check className="w-3 h-3" /> Verified
          </span>
        );
      case 'Resolved':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold rounded-md font-mono uppercase tracking-wider animate-pulse">
            Resolved
          </span>
        );
      case 'Needs Verification':
      case 'Newly Reported':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold rounded-md font-mono uppercase tracking-wider animate-pulse">
            Needs Verification
          </span>
        );
      case 'Team Assigned':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold rounded-md font-mono uppercase tracking-wider">
            Team Assigned
          </span>
        );
      case 'In Progress':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold rounded-md font-mono uppercase tracking-wider">
            In Progress
          </span>
        );
      case 'Received':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-700 border border-slate-200 text-[10px] font-bold rounded-md font-mono uppercase tracking-wider">
            Received
          </span>
        );
    }
  };

  const renderThumbnail = (type: string) => {
    switch (type) {
      case 'water':
        return (
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-sky-600 flex items-center justify-center text-white shrink-0 shadow-xs">
            <Droplet className="w-5 h-5 text-white" />
          </div>
        );
      case 'power':
        return (
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center text-white shrink-0 shadow-xs">
            <Zap className="w-5 h-5 text-white" />
          </div>
        );
      case 'sanitation':
        return (
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shrink-0 shadow-xs">
            <Trash2 className="w-5 h-5 text-white" />
          </div>
        );
      case 'road':
        return (
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-600 to-slate-800 flex items-center justify-center text-white shrink-0 shadow-xs">
            <HardHat className="w-5 h-5 text-white" />
          </div>
        );
      case 'safety':
      default:
        return (
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white shrink-0 shadow-xs">
            <ShieldAlert className="w-5 h-5 text-white" />
          </div>
        );
    }
  };

  const getVerificationOptions = (status: string) => {
    const s = status || '';
    if (s === 'Newly Reported' || s === 'Needs Verification' || s === 'Received') {
      return {
        quick: {
          title: "⚡ Verify New Report",
          helper: "I confirm this new issue is real and needs attention."
        },
        photo: {
          title: "📸 Add Verification Photo",
          helper: "Upload your own photo to help this issue get verified faster."
        }
      };
    } else if (s === 'Verified' || s === 'Assigned' || s === 'Team Assigned') {
      return {
        quick: {
          title: "⚡ Confirm Still Pending",
          helper: "The issue is still here waiting for the city."
        },
        photo: {
          title: "📸 Photo Update",
          helper: "Upload a photo if the hazard has worsened."
        }
      };
    } else if (s === 'In Progress') {
      return {
        quick: {
          title: "⚡ Confirm Activity",
          helper: "I see workers or equipment on site."
        },
        photo: {
          title: "📸 Photo Progress",
          helper: "Upload a photo of the ongoing repair work."
        }
      };
    } else if (s === 'Resolved') {
      return {
        quick: {
          title: "✅ Confirm Fixed (Quick)",
          helper: "I confirm the issue is completely resolved."
        },
        photo: {
          title: "📸 Confirm Fixed (Photo)",
          helper: "Upload a photo of the completed fix."
        },
        dispute: {
          title: "🚨 Reopen Issue",
          helper: "Not fixed? Upload a photo to dispute and reopen."
        }
      };
    }
    return {
      quick: {
        title: "⚡ Quick Verify",
        helper: "I confirm this issue is still here."
      },
      photo: {
        title: "📸 Photo Verify",
        helper: "Upload a new photo to earn higher trust points."
      }
    };
  };

  const handleToggleTrack = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextTracked = !tracked;
    if (triggerToast) {
      triggerToast(nextTracked ? "Issue is now added to your personal tracked feed." : "Removed from tracked issues.", "info");
    }
    setGlobalTickets(prev => 
      prev.map(t => {
        if (t.id === ticket.id) {
          return { ...t, tracked: nextTracked };
        }
        return t;
      })
    );
  };

  const handleToggleUpvote = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextUpvoted = !hasUpvoted;
    const delta = nextUpvoted ? 1 : -1;
    if (triggerToast) {
      triggerToast(nextUpvoted ? "Upvoted! Thank you for prioritizing this issue." : "Removed upvote.", "info");
    }
    setGlobalTickets(prev =>
      prev.map(t => {
        if (t.id === ticket.id) {
          return { 
            ...t, 
            upvotes: t.upvotes + delta,
            hasUpvoted: nextUpvoted
          };
        }
        return t;
      })
    );
  };

  const handleVerifyClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activePopover) {
      setActivePopover(false);
      setIsDispute(false);
    } else {
      setActivePopover(true);
      setPopoverMode('options');
      setIsDispute(false);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelected(e.target.files[0]);
    }
  };

  const handleFileSelected = (file: File) => {
    const fileUrl = URL.createObjectURL(file);
    setUploadedFile({ name: file.name, url: fileUrl });
    if (triggerToast) {
      triggerToast("Photo loaded successfully! Click Submit to complete.", "info");
    }
  };

  const handleQuickVerify = () => {
    setGlobalTickets(prev => 
      prev.map(t => {
        if (t.id === ticket.id) {
          const currentType = t.verificationState || 'unverified';
          const increment = currentType === 'unverified' ? 1 : 0;
          return {
            ...t,
            verificationState: 'quick',
            verifications: (t.verifications || 0) + increment,
            verifiedCount: (t.verifiedCount || 0) + increment
          };
        }
        return t;
      })
    );
    setActivePopover(false);
    if (triggerToast) {
      triggerToast("Quick Verification saved! Earned +5 reputation points.", "success");
    }
  };

  const handleSubmitPhotoProof = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadedFile) return;

    setGlobalTickets(prev => 
      prev.map(t => {
        if (t.id === ticket.id) {
          const currentType = t.verificationState || 'unverified';
          const increment = currentType === 'unverified' ? 1 : 0;
          
          if (isDispute) {
            return {
              ...t,
              status: 'pending', // Reopen as pending
              verificationState: 'photo',
              verifications: (t.verifications || 0) + increment,
              verifiedCount: (t.verifiedCount || 0) + increment
            };
          }
          return {
            ...t,
            verificationState: 'photo',
            verifications: (t.verifications || 0) + increment,
            verifiedCount: (t.verifiedCount || 0) + increment
          };
        }
        return t;
      })
    );

    setActivePopover(false);
    if (isDispute) {
      if (triggerToast) {
        triggerToast("Issue disputed and reopened! Your photo proof has been submitted.", "success");
      }
      setIsDispute(false);
    } else {
      if (triggerToast) {
        triggerToast("Verified with photo proof! Earned +25 reputation points.", "success");
      }
    }
  };

  const handleClearVerification = () => {
    setGlobalTickets(prev => 
      prev.map(t => {
        if (t.id === ticket.id) {
          const currentType = t.verificationState || 'unverified';
          const decrement = currentType !== 'unverified' ? 1 : 0;
          return {
            ...t,
            verificationState: 'unverified',
            verifications: Math.max(0, (t.verifications || 0) - decrement),
            verifiedCount: Math.max(0, (t.verifiedCount || 0) - decrement)
          };
        }
        return t;
      })
    );
    setUploadedFile(null);
    setActivePopover(false);
    setIsDispute(false);
    if (triggerToast) {
      triggerToast("Your verification for this issue has been removed.", "info");
    }
  };

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    const commentText = commentInput.trim();
    if (!commentText) return;

    setGlobalTickets(prev => 
      prev.map(t => {
        if (t.id === ticket.id) {
          const newComment: Comment = {
            id: `c-new-${Date.now()}`,
            author: 'You (Civic Hero)',
            role: 'You',
            avatarColor: 'bg-indigo-600 ring-2 ring-indigo-100',
            text: commentText,
            timestamp: 'Just now'
          };
          return {
            ...t,
            comments: [...(t.comments || []), newComment]
          };
        }
        return t;
      })
    );

    setCommentInput('');
    if (triggerToast) {
      triggerToast("Comment posted in neighborhood hub!", "success");
    }
  };

  const handleVerifyResolution = () => {
    setGlobalTickets(prev =>
      prev.map(t => {
        if (t.id === ticket.id) {
          return {
            ...t,
            status: 'verified' // Marks resolution as Verified in database format
          };
        }
        return t;
      })
    );
    if (triggerToast) {
      triggerToast("Thank you! Civic Resolution verified and logged.", "success");
    }
  };

  const latestComment = comments[comments.length - 1];
  const options = getVerificationOptions(displayStatus);

  const handleCardClick = () => {
    setIsExpanded(!isExpanded);
    if (onSelect) {
      onSelect();
    }
  };

  return (
    <div 
      id={`card-${ticket.id}`}
      className={`bg-white border rounded-[22px] relative transition-all duration-200 shadow-2xs ${
        isExpanded || isSelected ? 'ring-2 ring-indigo-500/20 border-indigo-400/80' : 'border-slate-200 hover:border-slate-300'
      }`}
    >
      {/* Card Header & core row clickable */}
      <div 
        onClick={handleCardClick}
        className="p-5 flex items-start gap-4 cursor-pointer select-none"
      >
        {renderThumbnail(iconType)}

        {/* Right content */}
        <div className="flex-1 min-w-0 space-y-3">
          <div className="space-y-1.5">
            {/* Tags, Locality & Status */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap gap-1">
                {tags.map(t => (
                  <span key={t} className="px-1.5 py-0.5 bg-slate-100 text-slate-700 text-[9px] font-bold uppercase tracking-wider rounded-sm font-mono">
                    {t}
                  </span>
                ))}
                <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-indigo-600 bg-indigo-50/50 px-1 py-0.5 rounded-sm font-mono">
                  📍 {locality}
                </span>
              </div>
              
              {renderStatusBadge(displayStatus)}
            </div>

            {/* Title & Description preview */}
            <div className="space-y-1">
              <h3 className="text-xs sm:text-sm font-bold text-slate-800 leading-snug hover:text-indigo-600 transition font-display">
                {ticket.title}
              </h3>
              {description && (
                <p className="text-[11px] text-slate-500 leading-relaxed font-medium line-clamp-2">
                  {description}
                </p>
              )}
            </div>
          </div>

          {/* Latest Comment preview if exists */}
          {latestComment && (
            <div className="bg-slate-50 border border-slate-100 rounded-xl p-2.5 flex items-start gap-2">
              <MessageSquare className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
              <p className="text-[10px] text-slate-600 font-medium leading-relaxed truncate flex-1">
                <span className="font-bold text-slate-700">{latestComment.author}:</span> {latestComment.text}
              </p>
            </div>
          )}

          {/* Toggle Button for Attached Evidence */}
          <div className="pt-0.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setOpenGallery(!openGallery);
              }}
              className="inline-flex items-center gap-1.5 text-[10px] font-extrabold text-slate-500 hover:text-indigo-600 transition cursor-pointer"
            >
              <span>🖼️</span>
              <span>{openGallery ? "Hide Attached Evidence" : "View Attached Evidence (2)"}</span>
              {openGallery ? (
                <ChevronUp className="w-3 h-3 shrink-0" />
              ) : (
                <ChevronDown className="w-3 h-3 shrink-0" />
              )}
            </button>
          </div>

          {/* Expandable Gallery */}
          {openGallery && (
            <div 
              onClick={(e) => e.stopPropagation()} 
              className="p-3 bg-slate-50 border border-slate-150 rounded-xl space-y-2 animate-fade-in text-left"
            >
              <div className="flex gap-2.5 overflow-x-auto py-1">
                <div className="w-28 h-24 bg-slate-200/70 border border-slate-300 rounded-lg flex flex-col items-center justify-center relative overflow-hidden group hover:border-slate-400 transition shrink-0">
                  <img 
                    src={ticket.mockImages?.[0] || ticket.photoUrl || "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?auto=format&fit=crop&w=400&q=80"}
                    alt="Evidence"
                    className="absolute inset-0 w-full h-full object-cover rounded-lg"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent z-10" />
                  <span className="text-[8px] text-white font-extrabold tracking-wide z-20 absolute bottom-1.5 left-2">Original Report</span>
                </div>

                <div className="w-28 h-24 bg-slate-200/70 border border-slate-300 rounded-lg flex flex-col items-center justify-center relative overflow-hidden group hover:border-slate-400 transition shrink-0">
                  <img 
                    src={ticket.mockImages?.[1] || "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=400&q=80"}
                    alt="Evidence"
                    className="absolute inset-0 w-full h-full object-cover rounded-lg"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent z-10" />
                  <span className="text-[8px] text-white font-extrabold tracking-wide z-20 absolute bottom-1.5 left-2">Verification Proof</span>
                </div>
              </div>
              <p className="text-[9.5px] text-slate-500 font-bold italic leading-none">
                Original Report + 1 Verification Photo
              </p>
            </div>
          )}

          {/* Card Footer with actions */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2.5">
              {/* Upvote button */}
              <button
                type="button"
                onClick={handleToggleUpvote}
                className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition duration-150 cursor-pointer border ${
                  hasUpvoted 
                    ? 'bg-rose-50 border-rose-200 text-rose-700 font-extrabold scale-[1.02]' 
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-600'
                }`}
                title="Upvote this issue"
              >
                <span>👍</span>
                <span>{ticket.upvotes} Upvotes</span>
              </button>

              {/* Verifications and Popover */}
              <div className="relative">
                <button
                  type="button"
                  onClick={handleVerifyClick}
                  className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition duration-150 cursor-pointer border ${
                    verificationState === 'quick'
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-700 font-extrabold'
                      : verificationState === 'photo'
                      ? 'bg-amber-50 border-amber-200 text-amber-700 font-extrabold'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-600'
                  }`}
                  title="Verify presence of this issue"
                >
                  {verificationState === 'quick' ? (
                    <>
                      <span>✅</span>
                      <span>Verified (Quick)</span>
                    </>
                  ) : verificationState === 'photo' ? (
                    <>
                      <span>🌟</span>
                      <span>Verified (Photo)</span>
                    </>
                  ) : (
                    <>
                      <span>✅</span>
                      <span>{verifications} Verifications</span>
                    </>
                  )}
                </button>

                {/* Popover Verification Menu */}
                {activePopover && (
                  <div 
                    onClick={(e) => e.stopPropagation()} 
                    className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl border border-slate-200 shadow-2xl p-4 z-[50] text-left animate-fade-in space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-800 font-display">
                        {popoverMode === 'options' ? 'Verify This Issue' : isDispute ? '🚨 Dispute & Reopen' : 'Upload Photo Proof'}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setActivePopover(false);
                          setIsDispute(false);
                        }}
                        className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {popoverMode === 'options' ? (
                      <div className="space-y-2">
                        {/* Option 1: Quick Verify */}
                        <button
                          type="button"
                          onClick={handleQuickVerify}
                          className="w-full flex items-start gap-2.5 p-2.5 rounded-xl border border-slate-100 hover:bg-emerald-50/40 hover:border-emerald-200 text-left transition group cursor-pointer"
                        >
                          <span className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg group-hover:scale-110 transition">
                            {displayStatus === 'Resolved' ? '✅' : '⚡'}
                          </span>
                          <div>
                            <h5 className="text-[10.5px] font-bold text-slate-800">{options.quick.title}</h5>
                            <p className="text-[9.5px] text-slate-500 leading-normal">{options.quick.helper}</p>
                          </div>
                        </button>

                        {/* Option 2: Photo Verify */}
                        <button
                          type="button"
                          onClick={() => {
                            setPopoverMode('photo_upload');
                            setIsDispute(false);
                          }}
                          className="w-full flex items-start gap-2.5 p-2.5 rounded-xl border border-slate-100 hover:bg-amber-50/40 hover:border-amber-200 text-left transition group cursor-pointer"
                        >
                          <span className="p-1.5 bg-amber-50 text-amber-600 rounded-lg group-hover:scale-110 transition">📸</span>
                          <div>
                            <h5 className="text-[10.5px] font-bold text-slate-800">{options.photo.title}</h5>
                            <p className="text-[9.5px] text-slate-500 leading-normal">{options.photo.helper}</p>
                          </div>
                        </button>

                        {/* Option 3: Dispute - only for Resolved */}
                        {displayStatus === 'Resolved' && (
                          <button
                            type="button"
                            onClick={() => {
                              setPopoverMode('photo_upload');
                              setIsDispute(true);
                            }}
                            className="w-full flex items-start gap-2.5 p-2.5 rounded-xl border border-rose-100 bg-rose-50/10 hover:bg-rose-50/50 hover:border-rose-200 text-left transition group cursor-pointer animate-pulse"
                          >
                            <span className="p-1.5 bg-rose-50 text-rose-600 rounded-lg group-hover:scale-110 transition">🚨</span>
                            <div>
                              <h5 className="text-[10.5px] font-bold text-rose-700">Reopen Issue</h5>
                              <p className="text-[9.5px] text-rose-500 leading-normal">Not fixed? Upload a photo to dispute and reopen.</p>
                            </div>
                          </button>
                        )}

                        {/* Clear Verification Option */}
                        {verificationState && verificationState !== 'unverified' && (
                          <button
                            type="button"
                            onClick={handleClearVerification}
                            className="w-full flex items-center justify-center gap-1.5 p-2 rounded-xl text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-100 text-[10px] font-bold transition cursor-pointer"
                          >
                            Remove My Verification
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {/* Photo Zone */}
                        <div
                          onDragOver={onDragOver}
                          onDrop={onDrop}
                          className="border-2 border-dashed border-slate-200 hover:border-indigo-400 rounded-xl p-4 flex flex-col items-center justify-center text-center transition bg-slate-50/50 relative cursor-pointer group"
                        >
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleFileChange}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                          />
                          {uploadedFile ? (
                            <div className="space-y-2">
                              <img 
                                src={uploadedFile.url} 
                                alt="Preview" 
                                className="w-16 h-16 object-cover rounded-lg mx-auto border border-slate-200 shadow-3xs" 
                              />
                              <div>
                                <p className="text-[9.5px] font-bold text-slate-700 truncate max-w-[200px]">
                                  {uploadedFile.name}
                                </p>
                                <p className="text-[8.5px] text-emerald-600 font-semibold">Ready for upload!</p>
                              </div>
                            </div>
                          ) : (
                            <div className="space-y-1">
                              <UploadCloud className="w-6 h-6 text-slate-400 group-hover:text-indigo-500 transition mx-auto" />
                              <p className="text-[9.5px] font-bold text-slate-600">
                                {isDispute ? 'Drag & drop active hazard proof' : 'Drag & drop photo proof'}
                              </p>
                              <p className="text-[8.5px] text-slate-400 font-medium">or click to browse library</p>
                            </div>
                          )}
                        </div>

                        {/* Popover Actions */}
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setPopoverMode('options');
                              setIsDispute(false);
                            }}
                            className="flex-1 py-2 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-600 hover:bg-slate-50 transition cursor-pointer"
                          >
                            Back
                          </button>
                          <button
                            type="button"
                            onClick={handleSubmitPhotoProof}
                            disabled={!uploadedFile}
                            className="flex-1 py-2 bg-indigo-600 disabled:bg-slate-200 disabled:text-slate-400 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-bold transition shadow-xs cursor-pointer"
                          >
                            {isDispute ? 'Submit Dispute Proof' : 'Submit Proof'}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Track Toggle */}
              <button
                type="button"
                onClick={handleToggleTrack}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold transition cursor-pointer border ${
                  tracked
                    ? 'bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100'
                    : 'bg-slate-900 border-slate-900 text-white hover:bg-slate-800 shadow-2xs'
                }`}
                title={tracked ? "Stop tracking updates" : "Track updates for this issue"}
              >
                {tracked ? (
                  <>
                    <span>🔕</span>
                    <span>Untrack</span>
                  </>
                ) : (
                  <>
                    <span>🔔</span>
                    <span>Track Issue</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Expand Indicator Icon */}
        <div className="shrink-0 p-1 text-slate-400">
          {isExpanded || isSelected ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </div>
      </div>

      {/* Expanded Discussion / Thread area */}
      {(isExpanded || isSelected) && (
        <div className="border-t border-slate-100 bg-slate-50/40 p-5 space-y-4">
          <div className="space-y-3">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
              Neighborhood Updates ({comments.length})
            </h4>

            <div className="space-y-2.5 max-h-[250px] overflow-y-auto pr-1">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-2.5 items-start bg-white p-3 rounded-xl border border-slate-200/60 shadow-3xs">
                  <div className={`w-6 h-6 rounded-lg ${comment.avatarColor} text-[10px] font-bold text-white flex items-center justify-center shrink-0`}>
                    {comment.author.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0 space-y-0.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] font-bold text-slate-700 truncate">{comment.author}</span>
                        <span className={`px-1 text-[8px] font-extrabold uppercase rounded-xs font-mono tracking-tight ${
                          comment.role === 'Inspector' || comment.role === 'Ward Officer'
                            ? 'bg-purple-100 text-purple-700'
                            : comment.role === 'You'
                            ? 'bg-indigo-100 text-indigo-700'
                            : 'bg-slate-100 text-slate-500'
                        }`}>
                          {comment.role}
                        </span>
                      </div>
                      <span className="text-[9px] text-slate-400 shrink-0">{comment.timestamp}</span>
                    </div>
                    <p className="text-[10.5px] text-slate-600 leading-relaxed font-medium">
                      {comment.text}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Verify Resolution message/button */}
          {displayStatus === 'Resolved' && (
            <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl flex items-center justify-between gap-3 animate-fade-in">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" /> Verify Local Resolution
                </span>
                <p className="text-[10px] text-indigo-700 leading-relaxed">
                  Has this been fixed correctly? Tap to release community bounties and reward reporting neighbors.
                </p>
              </div>
              <button
                type="button"
                onClick={handleVerifyResolution}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[10px] px-3.5 py-2 rounded-lg transition whitespace-nowrap cursor-pointer shadow-xs"
              >
                Verify Resolution ✓
              </button>
            </div>
          )}

          {ticket.status === 'verified' && (
            <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center gap-2 text-emerald-800 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="text-[11px] font-bold">This resolution is completely verified by you and has been archived!</span>
            </div>
          )}

          {/* Comment Form */}
          <form 
            onSubmit={handlePostComment}
            className="flex items-center gap-2 pt-2 border-t border-slate-150"
          >
            <input
              type="text"
              value={commentInput}
              onChange={(e) => setCommentInput(e.target.value)}
              placeholder="Add an update or comment..."
              className="flex-1 bg-white border border-slate-200 rounded-xl px-3.5 py-2 text-[11px] font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-400 placeholder-slate-400"
            />
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-xl transition cursor-pointer shadow-2xs"
              title="Post update"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
