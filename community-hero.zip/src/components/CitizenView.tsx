import React, { useState } from 'react';
import { 
  User, 
  Compass, 
  Users, 
  Bot, 
  LogOut,
  Bell,
  ShieldCheck
} from 'lucide-react';
import ProfileStats from './ProfileStats';
import ExploreReport from './ExploreReport';
import CommunityHub from './CommunityHub';
import AICivicAssistant from './AICivicAssistant';

interface CitizenViewProps {
  globalTickets: any[];
  setGlobalTickets: React.Dispatch<React.SetStateAction<any[]>>;
  setActiveAppView: (view: 'login' | 'citizen' | 'authority') => void;
  setIsLoggedIn: (loggedIn: boolean) => void;
}

const TABS = [
  { id: 'profile', name: 'Profile & Stats', icon: User, component: ProfileStats },
  { id: 'explore', name: 'Explore & Report', icon: Compass, component: ExploreReport },
  { id: 'hub', name: 'Community Hub', icon: Users, component: CommunityHub },
  { id: 'assistant', name: 'AI Civic Assistant', icon: Bot, component: AICivicAssistant },
];

export default function CitizenView({ 
  globalTickets, 
  setGlobalTickets, 
  setActiveAppView, 
  setIsLoggedIn 
}: CitizenViewProps) {
  const [activeTab, setActiveTab] = useState<string>('explore');
  const [showNotifications, setShowNotifications] = useState<boolean>(false);
  const [notifications, setNotifications] = useState([
    { id: 1, text: "✅ Success: Your report 'Water Leakage' is verified and assigned.", unread: true },
    { id: 2, text: "🔔 Update: The 'Sector 15 Pothole' you are tracking is now In Progress.", unread: true },
    { id: 3, text: "🏆 Earned: You received 10 Rep points for verifying an issue!", unread: true }
  ]);

  return (
    <div id="authenticated-app-shell" className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* --- 2. GLOBAL HEADER --- */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-xs border-b border-slate-200 px-4 sm:px-6 py-3.5 flex items-center justify-between shrink-0">
        {/* Left Side: Brand Logo and Location Pill */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center border border-indigo-500 shadow-sm shadow-indigo-600/15">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <span className="font-extrabold text-sm sm:text-base tracking-tight text-slate-900 font-display">
              Community Hero
            </span>
          </div>
          
          {/* Location Pill */}
          <div className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 rounded-full border border-slate-200/50">
            <span className="text-[10px] font-bold text-slate-600 flex items-center gap-0.5">
              <span>📍</span> New Panvel
            </span>
          </div>
        </div>

        {/* Right Side: Reputation and Admin Switcher */}
        <div className="flex items-center gap-2.5 relative">
          {/* User Reputation Badge */}
          <div className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-50 border border-indigo-100 rounded-lg text-indigo-700 font-bold text-xs">
            <span className="text-amber-500">⭐</span>
            <span className="font-mono">450 Rep</span>
          </div>

          {/* Notification Bell Icon */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className={`p-1.5 rounded-lg border transition relative cursor-pointer flex items-center justify-center ${
                showNotifications 
                  ? 'bg-indigo-50 border-indigo-200 text-indigo-600' 
                  : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-slate-700'
              }`}
              title="Recent Notifications"
            >
              <Bell className="w-4 h-4" />
              {notifications.some(n => n.unread) && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-extrabold text-white animate-pulse ring-2 ring-white">
                  {notifications.filter(n => n.unread).length}
                </span>
              )}
            </button>

            {/* Notification Dropdown */}
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden z-50 animate-fade-in">
                {/* Header */}
                <div className="px-4 py-3 bg-slate-50/80 border-b border-slate-150 flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-700 font-display">Recent Notifications</span>
                  {notifications.some(n => n.unread) && (
                    <span className="text-[9px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded-md font-mono">
                      {notifications.filter(n => n.unread).length} Unread
                    </span>
                  )}
                </div>

                {/* Items */}
                <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="p-4 text-center text-[10px] text-slate-400 font-medium">
                      No notifications yet
                    </div>
                  ) : (
                    notifications.map(n => (
                      <div 
                        key={n.id} 
                        className={`p-3 text-[10.5px] leading-relaxed transition text-left ${
                          n.unread ? 'bg-indigo-50/20 font-semibold text-slate-800 border-l-2 border-indigo-500' : 'text-slate-500 font-medium'
                        }`}
                      >
                        {n.text}
                      </div>
                    ))
                  )}
                </div>

                {/* Mark all as read Button */}
                {notifications.some(n => n.unread) && (
                  <div className="p-2 border-t border-slate-100 bg-slate-50/50 text-center">
                    <button
                      type="button"
                      onClick={() => {
                        setNotifications(notifications.map(n => ({ ...n, unread: false })));
                      }}
                      className="w-full py-1.5 text-[10px] font-bold text-indigo-600 hover:text-indigo-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition cursor-pointer"
                    >
                      Mark all as read
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Logout Button */}
          <button
            onClick={() => {
              setActiveAppView('login');
              setIsLoggedIn(false);
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition cursor-pointer"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Core Layout: Sidebar for Desktop, Main Content Area */}
      <div className="flex-1 flex min-h-0 relative">
        
        {/* --- 3. SIDEBAR FOR DESKTOP --- */}
        <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 py-6 px-4 shrink-0 justify-between">
          <div className="space-y-6">
            <div className="px-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                Citizen Portal
              </span>
            </div>
            
            {/* Nav Menu */}
            <nav className="space-y-1">
              {TABS.map((tab) => {
                const TabIcon = tab.icon;
                const isSelected = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <TabIcon className="w-4 h-4 shrink-0" />
                    <span>{tab.name}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Mini Sidebar Footer/Rep summary */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/60 text-center space-y-1.5">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Your Rank</p>
            <p className="text-xs font-extrabold text-slate-800 font-display">Panvel Civic Warden</p>
            <div className="w-full bg-slate-200 rounded-full h-1">
              <div className="bg-indigo-600 h-1 rounded-full" style={{ width: '75%' }}></div>
            </div>
            <p className="text-[9px] text-slate-500 font-medium">50 Rep to next level</p>
          </div>
        </aside>

        {/* Content Panel Area */}
        <main className={`flex-1 ${activeTab === 'assistant' ? 'overflow-hidden flex flex-col h-[calc(100vh-64px)] md:h-[calc(100vh-73px)]' : 'overflow-y-auto pb-20 md:pb-6'} bg-slate-50`}>
          {activeTab === 'profile' && <ProfileStats />}
          {activeTab === 'explore' && <ExploreReport globalTickets={globalTickets} setGlobalTickets={setGlobalTickets} />}
          {activeTab === 'hub' && <CommunityHub globalTickets={globalTickets} setGlobalTickets={setGlobalTickets} />}
          {activeTab === 'assistant' && <AICivicAssistant />}
        </main>
      </div>

      {/* --- 3. BOTTOM NAVIGATION FOR MOBILE --- */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-xs border-t border-slate-200 px-2 py-2 flex justify-around items-center shadow-lg shadow-slate-900/10 shrink-0">
        {TABS.map((tab) => {
          const TabIcon = tab.icon;
          const isSelected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition cursor-pointer ${
                isSelected
                  ? 'text-indigo-600'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <TabIcon className={`w-5 h-5 shrink-0 ${isSelected ? 'stroke-[2.5px]' : ''}`} />
              <span className="text-[9px] font-bold tracking-tight font-display">
                {tab.name.split(' ')[0]} {/* shortened for compact bottom-nav */}
              </span>
            </button>
          );
        })}
      </nav>

    </div>
  );
}
