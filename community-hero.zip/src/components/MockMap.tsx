import React, { useState } from 'react';
import { MapPin, Navigation, ZoomIn, ZoomOut, Compass, Info } from 'lucide-react';
import { Issue } from '../types';

interface MockMapProps {
  issues: Issue[];
  selectedIssueId: string | null;
  onSelectIssue: (issueId: string) => void;
}

export default function MockMap({ issues, selectedIssueId, onSelectIssue }: MockMapProps) {
  const [zoom, setZoom] = useState<number>(100);
  const [hoveredIssue, setHoveredIssue] = useState<Issue | null>(null);

  // Hardcode coordinates (percentage offsets on our map grid) for mock issues
  const getCoordinates = (id: string): { x: number; y: number } => {
    switch (id) {
      case "CIV-1021": return { x: 35, y: 40 }; // Oakwood Dr & Pine St
      case "CIV-1022": return { x: 65, y: 25 }; // 142 Maple Ave
      case "CIV-1023": return { x: 20, y: 75 }; // River Park Trailhead
      case "CIV-1024": return { x: 80, y: 60 }; // Fifth St & Cascade Way
      case "CIV-1025": return { x: 50, y: 55 }; // Central Subway Tunnel
      default:
        // Hash ID to generate deterministic position for newly created issues
        let hash = 0;
        for (let i = 0; i < id.length; i++) {
          hash = id.charCodeAt(i) + ((hash << 5) - hash);
        }
        const x = 30 + (Math.abs(hash) % 50); // stay in central bounds [30, 80]
        const y = 20 + (Math.abs((hash >> 2)) % 60); // [20, 80]
        return { x, y };
    }
  };

  const getUrgencyColor = (urgency: 'Low' | 'Medium' | 'High', isSelected: boolean) => {
    if (isSelected) return 'bg-rose-600 border-white text-white ring-4 ring-rose-300 scale-125 z-30';
    switch (urgency) {
      case 'High': return 'bg-rose-500 border-rose-100 text-white hover:bg-rose-600 z-10';
      case 'Medium': return 'bg-amber-500 border-amber-100 text-white hover:bg-amber-600 z-10';
      case 'Low': return 'bg-blue-500 border-blue-100 text-white hover:bg-blue-600 z-10';
    }
  };

  return (
    <div id="mock-map-container" className="relative w-full h-[380px] bg-slate-50 border border-slate-200 rounded-[24px] overflow-hidden shadow-xs flex flex-col">
      {/* Map Header Controls */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-20 pointer-events-none">
        <div className="flex items-center gap-2 bg-white/95 backdrop-blur-xs px-3 py-1.5 rounded-lg shadow-sm border border-slate-200 pointer-events-auto">
          <Compass className="h-4 w-4 text-indigo-600 animate-spin-slow" />
          <span className="text-xs font-semibold text-slate-800">Greenfield Hyperlocal Grid</span>
        </div>
        
        <div className="flex gap-1.5 pointer-events-auto">
          <button 
            onClick={() => setZoom(prev => Math.min(prev + 10, 150))}
            className="p-1.5 bg-white border border-slate-200 rounded-md shadow-xs hover:bg-slate-50 text-slate-600 transition"
            title="Zoom In"
          >
            <ZoomIn className="h-3.5 w-3.5" />
          </button>
          <button 
            onClick={() => setZoom(prev => Math.max(prev - 10, 80))}
            className="p-1.5 bg-white border border-slate-200 rounded-md shadow-xs hover:bg-slate-50 text-slate-600 transition"
            title="Zoom Out"
          >
            <ZoomOut className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* SVG Grid Map Layout */}
      <div 
        className="relative w-full flex-1 overflow-hidden select-none bg-slate-100"
        style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'center center', transition: 'transform 0.2s ease-out' }}
      >
        {/* Abstract Street Grid Layout */}
        <svg className="absolute inset-0 w-full h-full text-slate-200" xmlns="http://www.w3.org/2000/svg">
          {/* Main Boulevards */}
          <line x1="0" y1="120" x2="100%" y2="120" stroke="currentColor" strokeWidth="10" />
          <line x1="0" y1="260" x2="100%" y2="260" stroke="currentColor" strokeWidth="12" strokeDasharray="5,5" />
          <line x1="300" y1="0" x2="300" y2="100%" stroke="currentColor" strokeWidth="8" />
          <line x1="600" y1="0" x2="600" y2="100%" stroke="currentColor" strokeWidth="8" />
          
          {/* Local Streets */}
          <line x1="0" y1="60" x2="100%" y2="60" stroke="#e2e8f0" strokeWidth="4" />
          <line x1="0" y1="190" x2="100%" y2="190" stroke="#e2e8f0" strokeWidth="4" />
          <line x1="0" y1="320" x2="100%" y2="320" stroke="#e2e8f0" strokeWidth="4" />
          
          <line x1="150" y1="0" x2="150" y2="100%" stroke="#e2e8f0" strokeWidth="4" />
          <line x1="450" y1="0" x2="450" y2="100%" stroke="#e2e8f0" strokeWidth="4" />
          <line x1="750" y1="0" x2="750" y2="100%" stroke="#e2e8f0" strokeWidth="4" />

          {/* River Park representation */}
          <path d="M 0,350 Q 120,310 240,360 T 480,330 T 720,380 L 1000,340" fill="none" stroke="#bae6fd" strokeWidth="32" strokeLinecap="round" opacity="0.6" />
          <text x="80" y="375" fill="#0369a1" className="text-[10px] font-bold tracking-wider font-display opacity-80" rotate="-5">GREENFIELD RIVER</text>

          {/* District Labels */}
          <text x="80" y="45" fill="#94a3b8" className="text-[9px] font-semibold tracking-widest font-display">NORTH SECTOR</text>
          <text x="450" y="45" fill="#94a3b8" className="text-[9px] font-semibold tracking-widest font-display">HEIGHTS DISTRICT</text>
          <text x="350" y="245" fill="#94a3b8" className="text-[9px] font-semibold tracking-widest font-display">EAST GATE AREA</text>
          <text x="60" y="245" fill="#94a3b8" className="text-[9px] font-semibold tracking-widest font-display">GREENFIELD CORES</text>
        </svg>

        {/* Overlaying GPS Location Anchor (Simulating User Location) */}
        <div className="absolute left-[45%] top-[65%] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-15 pointer-events-none">
          <div className="h-4 w-4 bg-indigo-500 rounded-full border-2 border-white shadow-md animate-ping absolute" />
          <div className="h-4 w-4 bg-indigo-600 rounded-full border-2 border-white shadow-md relative" />
          <span className="mt-1 bg-indigo-950 text-white text-[8px] font-medium px-1 rounded-sm shadow-xs">My Location</span>
        </div>

        {/* Dynamic Interactive Pins from active Issues */}
        {issues.map(issue => {
          const coords = getCoordinates(issue.id);
          const isSelected = selectedIssueId === issue.id;
          
          return (
            <button
              key={issue.id}
              onClick={() => onSelectIssue(issue.id)}
              onMouseEnter={() => setHoveredIssue(issue)}
              onMouseLeave={() => setHoveredIssue(null)}
              className={`absolute -translate-x-1/2 -translate-y-1/2 p-1.5 rounded-full border-2 shadow-md cursor-pointer transition-all duration-200 flex items-center justify-center ${getUrgencyColor(issue.urgency, isSelected)}`}
              style={{ left: `${coords.x}%`, top: `${coords.y}%` }}
            >
              <MapPin className={`h-4 w-4 ${isSelected ? 'animate-bounce' : ''}`} />
            </button>
          );
        })}

        {/* Custom Hover Tooltip */}
        {hoveredIssue && (
          <div 
            className="absolute z-40 bg-slate-900 text-white p-2.5 rounded-lg shadow-xl border border-slate-800 max-w-xs transition-opacity duration-200 pointer-events-none text-xs flex flex-col gap-1 -translate-x-1/2"
            style={{ 
              left: `${getCoordinates(hoveredIssue.id).x}%`, 
              top: `${getCoordinates(hoveredIssue.id).y - 12}%` 
            }}
          >
            <div className="flex items-center justify-between gap-2 border-b border-slate-700 pb-1 mb-1">
              <span className="font-bold text-indigo-400 font-mono">{hoveredIssue.id}</span>
              <span className={`px-1.5 py-0.5 rounded-xs text-[9px] font-bold ${
                hoveredIssue.urgency === 'High' ? 'bg-rose-900/80 text-rose-300' :
                hoveredIssue.urgency === 'Medium' ? 'bg-amber-900/80 text-amber-300' :
                'bg-blue-900/80 text-blue-300'
              }`}>{hoveredIssue.urgency} Priority</span>
            </div>
            <p className="font-semibold text-slate-200 line-clamp-1">{hoveredIssue.title}</p>
            <p className="text-[10px] text-slate-400 font-mono line-clamp-1">📍 {hoveredIssue.location}</p>
          </div>
        )}
      </div>

      {/* Map Legend Footer */}
      <div className="bg-white border-t border-slate-200 px-4 py-2 flex items-center justify-between text-[10px] text-slate-500 z-10">
        <div className="flex items-center gap-1">
          <Info className="h-3 w-3 text-slate-400" />
          <span>Click any pin to view details in the issues feed.</span>
        </div>
        <div className="flex gap-3">
          <span className="flex items-center gap-1 font-semibold"><span className="h-2 w-2 rounded-full bg-rose-500" /> High</span>
          <span className="flex items-center gap-1 font-semibold"><span className="h-2 w-2 rounded-full bg-amber-500" /> Medium</span>
          <span className="flex items-center gap-1 font-semibold"><span className="h-2 w-2 rounded-full bg-blue-500" /> Low</span>
        </div>
      </div>
    </div>
  );
}
