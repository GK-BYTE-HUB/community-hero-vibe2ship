import React, { useState, useRef, useEffect } from 'react';
import { 
  Users, 
  ChevronDown,
  CheckCircle2
} from 'lucide-react';
import IssueCard from './IssueCard';

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'info' | 'warning';
}

interface CommunityHubProps {
  globalTickets: any[];
  setGlobalTickets: React.Dispatch<React.SetStateAction<any[]>>;
}

export default function CommunityHub({ globalTickets, setGlobalTickets }: CommunityHubProps) {
  // Local active switch state: 'tracked' or 'hub'
  const [activeView, setActiveView] = useState<'tracked' | 'hub'>('tracked');
  // Selected locality filter
  const [selectedLocality, setSelectedLocality] = useState<string>('All');
  // Local toasts
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toastIdCounter = useRef(0);
  const activeMessages = useRef<Set<string>>(new Set());
  const activeTimeouts = useRef<NodeJS.Timeout[]>([]);

  useEffect(() => {
    return () => {
      activeTimeouts.current.forEach(clearTimeout);
    };
  }, []);

  // Toast dispatch
  const triggerToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    if (activeMessages.current.has(message)) {
      return;
    }
    activeMessages.current.add(message);

    const id = ++toastIdCounter.current;
    setToasts(prev => [...prev, { id, message, type }]);

    const timer = setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
      activeMessages.current.delete(message);
      activeTimeouts.current = activeTimeouts.current.filter(t => t !== timer);
    }, 4000);
    activeTimeouts.current.push(timer);
  };

  // Filter list based on view and locality dropdown
  const filteredDiscussions = globalTickets.filter(disc => {
    // 1. Filter by view (My Tracked vs All)
    if (activeView === 'tracked' && !disc.tracked) {
      return false;
    }
    // 2. Filter by locality dropdown
    if (selectedLocality !== 'All' && disc.locality !== selectedLocality) {
      return false;
    }
    return true;
  });

  return (
    <div id="community-hub-tab" className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-6">
      
      {/* Toast Overlay notifications */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-sm">
        {toasts.map(t => (
          <div key={t.id} className="bg-slate-900 text-white rounded-xl py-3 px-4 shadow-xl border border-slate-800 text-xs font-bold flex items-center gap-2 animate-slide-in">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
            <span>{t.message}</span>
          </div>
        ))}
      </div>

      {/* 1. THE HEADER & FILTERS */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <Users className="w-5 h-5" />
            </div>
            <h1 className="text-lg font-extrabold text-slate-900 font-display">
              Community Discussions
            </h1>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Active neighborhood threads, real-time ground updates, and incident coordination
          </p>
        </div>

        {/* Locality dropdown selector */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <label htmlFor="hub-locality-select" className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono shrink-0">
            Locality:
          </label>
          <div className="relative">
            <select
              id="hub-locality-select"
              value={selectedLocality}
              onChange={(e) => {
                setSelectedLocality(e.target.value);
                triggerToast(`Switched filter to ${e.target.value}`, "info");
              }}
              className="bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 cursor-pointer appearance-none pr-8"
            >
              <option value="All">All Localities</option>
              <option value="Sector 15">Sector 15</option>
              <option value="Khandeshwar">Khandeshwar</option>
              <option value="Kamothe">Kamothe</option>
              <option value="Old Panvel">Old Panvel</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Toggle Tab Switcher */}
      <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200/50 max-w-sm">
        <button
          onClick={() => setActiveView('tracked')}
          className={`flex-1 text-center py-2 px-3 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${
            activeView === 'tracked'
              ? 'bg-white text-indigo-600 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          My Tracked Issues
        </button>
        <button
          onClick={() => setActiveView('hub')}
          className={`flex-1 text-center py-2 px-3 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${
            activeView === 'hub'
              ? 'bg-white text-indigo-600 shadow-2xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Local Area Hub
        </button>
      </div>

      {/* 2. THE DISCUSSION FEED (Main Content) */}
      <div className="space-y-4">
        {/* Official Authority Notice */}
        <div id="official-authority-notice" className="bg-blue-50/50 border-2 border-blue-100 shadow-sm rounded-[22px] p-5 space-y-3 relative overflow-hidden text-left">
          {/* Top subtle highlight line */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-indigo-500" />
          
          {/* Header */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-sm shrink-0">📢</span>
              <h4 className="text-xs font-bold text-slate-800 font-display">
                OFFICIAL UPDATE: Panvel Water Supply Board
              </h4>
            </div>
            <div className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-100/60 border border-blue-200 rounded-md text-[10px] font-bold text-blue-700">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 fill-blue-50 shrink-0" />
              <span>Verified Authority</span>
            </div>
          </div>

          {/* Content */}
          <p className="text-xs text-slate-600 font-medium leading-relaxed">
            Scheduled pipeline maintenance will cause low water pressure in Sector 15 and 16 tomorrow from 10:00 AM to 2:00 PM. Please store water accordingly.
          </p>

          {/* Footer */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[10px] text-slate-500">
            <span className="font-bold font-mono">Pinned • 1 hr ago</span>
            <button
              type="button"
              onClick={() => triggerToast("Notice link copied to clipboard! Share it with your neighbors.", "success")}
              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-extrabold rounded-lg shadow-2xs transition cursor-pointer text-[10px]"
            >
              Share Notice
            </button>
          </div>
        </div>

        {filteredDiscussions.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-[24px] p-12 text-center flex flex-col items-center justify-center min-h-[250px] shadow-2xs">
            <div className="w-12 h-12 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-center text-slate-400 mb-3">
              <Users className="w-5 h-5 text-slate-400" />
            </div>
            <h3 className="text-xs font-bold text-slate-800 font-display">No Discussions Found</h3>
            <p className="text-[11px] text-slate-400 max-w-xs leading-relaxed mt-1">
              There are no reports matching this filter segment. Switch to 'Local Area Hub' or report an issue to spin up a public discussion.
            </p>
          </div>
        ) : (
          filteredDiscussions.map((disc) => (
            <IssueCard 
              key={disc.id} 
              ticket={disc} 
              setGlobalTickets={setGlobalTickets} 
              triggerToast={triggerToast} 
            />
          ))
        )}
      </div>

    </div>
  );
}
