import React, { useState } from 'react';
import { 
  Building2, Users, AlertTriangle, CheckCircle2, RefreshCw, 
  ChevronRight, Calendar, ArrowUpRight, Search, SlidersHorizontal, 
  MapPin, Clock, FileText, Send, X, Landmark, FileImage, ShieldAlert,
  Inbox, Megaphone, BarChart3, Plus, LogOut, Check, Sparkles, Server,
  ShieldCheck, Loader2, Trello, ArrowLeft, ArrowRight, MessageSquare,
  ThumbsUp, ChevronDown, ChevronUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Issue, TimelineUpdate } from '../types';

interface AuthorityViewProps {
  globalTickets: any[];
  setGlobalTickets: React.Dispatch<React.SetStateAction<any[]>>;
  municipality?: string;
  department?: string;
  onLogout?: () => void;
}

const STATUS_STATES: Issue['status'][] = ["Received", "Site Inspection", "Team Assigned", "In Progress", "Resolved"];

export default function AuthorityView({ 
  globalTickets, 
  setGlobalTickets,
  municipality = "Panvel Municipal Corporation",
  department = "Water Supply & Drainage",
  onLogout
}: AuthorityViewProps) {
  
  // Navigation active state
  const [activeSubTab, setActiveSubTab] = useState<'inbox' | 'operations' | 'notices' | 'analytics'>('inbox');
  
  // Drawer state for operations
  const [selectedIssueId, setSelectedIssueId] = useState<string | null>(null);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [statusComment, setStatusComment] = useState('');
  const [newStatusSelection, setNewStatusSelection] = useState<Issue['status'] | ''>('');

  // Operations filters
  const [tableSearch, setTableSearch] = useState('');
  const [tableCategory, setTableCategory] = useState<string>('All');
  const [tableStatus, setTableStatus] = useState<string>('All');

  const issues = globalTickets;
  const tickets = globalTickets;
  const setTickets = setGlobalTickets;

  // Expanded discussion/media panel
  const [expandedTicketId, setExpandedTicketId] = useState<string | null>(null);

  // State for authority reply texts
  const [replyTexts, setReplyTexts] = useState<Record<string, string>>({});

  // State for AI Summary results & loading indicators
  const [aiSummaries, setAiSummaries] = useState<Record<string, string>>({});
  const [isSummarizing, setIsSummarizing] = useState<Record<string, boolean>>({});

  // Dropdown/popover state for Active Crew selector
  const [activeCrewDropdownId, setActiveCrewDropdownId] = useState<string | null>(null);

  // Public notices state
  const [notices, setNotices] = useState([
    {
      id: 'N-100',
      type: 'Maintenance Schedule',
      targetZone: 'Sector 15',
      message: 'Scheduled pipeline maintenance will cause low water pressure in Sector 15 and 16 tomorrow from 10:00 AM to 2:00 PM. Please store water accordingly.',
      date: 'Pinned • 1 hr ago',
      department: department,
      status: 'Active'
    },
    {
      id: 'N-101',
      type: 'Emergency Alert',
      targetZone: 'All Localities',
      message: 'Urgent: High water turbidity detected near the north pumping station. Citizens are advised to boil drinking water.',
      date: 'Today, 02:00 PM',
      department: department,
      status: 'Active'
    },
    {
      id: 'N-102',
      type: 'Policy Update',
      targetZone: 'Kamothe',
      message: 'New waste segregation protocols will be strictly enforced starting next Monday. Thank you for your cooperation.',
      date: 'Yesterday',
      department: department,
      status: 'Active'
    }
  ]);

  const [noticeTargetZone, setNoticeTargetZone] = useState('All Localities');
  const [noticeType, setNoticeType] = useState('Maintenance Schedule');
  const [noticeMessage, setNoticeMessage] = useState('');
  const [noticeSuccessMessage, setNoticeSuccessMessage] = useState('');

  const moveKanbanTask = (id: string, direction: 'left' | 'right') => {
    setTickets(prev => prev.map(task => {
      if (task.id !== id) return task;
      let nextStatus = task.status;
      if (task.status === 'assigned' && direction === 'right') {
        nextStatus = 'inprogress';
      } else if (task.status === 'inprogress') {
        nextStatus = direction === 'left' ? 'assigned' : 'resolved';
      } else if (task.status === 'resolved' && direction === 'left') {
        nextStatus = 'inprogress';
      }
      return { ...task, status: nextStatus };
    }));
  };

  // Metrics Calculations (incorporating citizen reports)
  const totalIssues = issues.length;
  const pendingIssuesCount = issues.filter(i => i.status !== 'Resolved').length;
  const highSeverityCount = issues.filter(i => i.urgency === 'High' && i.status !== 'Resolved').length;
  const resolvedCount = issues.filter(i => i.status === 'Resolved').length;

  const handleStatusUpdateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIssueId || !newStatusSelection) return;

    setIsUpdatingStatus(true);
    try {
      const statusKey = newStatusSelection === 'Resolved' ? 'resolved' :
                        newStatusSelection === 'In Progress' ? 'inprogress' :
                        newStatusSelection === 'Team Assigned' ? 'assigned' : 'pending';
      setTickets(prev => prev.map(t => t.id === selectedIssueId ? { ...t, status: statusKey } : t));
      setStatusComment('');
      setNewStatusSelection('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const selectedIssue = issues.find(i => i.id === selectedIssueId);

  // Filter Table Queue
  const filteredTableIssues = issues.filter(issue => {
    const matchesSearch = issue.id.toLowerCase().includes(tableSearch.toLowerCase()) || 
                          issue.title.toLowerCase().includes(tableSearch.toLowerCase()) ||
                          issue.location.toLowerCase().includes(tableSearch.toLowerCase());
    const matchesCategory = tableCategory === 'All' || issue.category === tableCategory;
    const matchesStatus = tableStatus === 'All' || issue.status === tableStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const getUrgencyBadge = (urgency: 'Low' | 'Medium' | 'High') => {
    switch (urgency) {
      case 'High': return 'bg-rose-50 text-rose-700 border-rose-200/60 font-semibold';
      case 'Medium': return 'bg-amber-50 text-amber-700 border-amber-200/60 font-semibold';
      case 'Low': return 'bg-blue-50 text-blue-700 border-blue-200/60 font-semibold';
    }
  };

  const getStatusBadge = (status: Issue['status']) => {
    switch (status) {
      case 'Received': return 'bg-slate-50 text-slate-700 border-slate-200';
      case 'Site Inspection': return 'bg-indigo-50 text-indigo-700 border-indigo-200/60';
      case 'Team Assigned': return 'bg-purple-50 text-purple-700 border-purple-200/60';
      case 'In Progress': return 'bg-amber-50 text-amber-700 border-amber-200/60';
      case 'Resolved': return 'bg-emerald-50 text-emerald-700 border-emerald-200/60';
    }
  };

  // Actions for mock tickets
  const handleAssignCrew = (id: string, crewName: string) => {
    setTickets(prev => prev.map(t => t.id === id ? { ...t, status: 'assigned', assignedTo: crewName } : t));
  };

  const handleConfirmCrewAssignment = (id: string, crewName: string) => {
    setTickets(prev => prev.map(t => {
      if (t.id !== id) return t;
      return {
        ...t,
        status: 'assigned',
        assignedTo: crewName,
        urgency: t.severity === 'HIGH' ? 'High' : 'Medium'
      };
    }));
    setActiveCrewDropdownId(null);
  };

  const handleAISummarize = (id: string) => {
    setIsSummarizing(prev => ({ ...prev, [id]: true }));
    setTimeout(() => {
      setIsSummarizing(prev => ({ ...prev, [id]: false }));
      setAiSummaries(prev => ({
        ...prev,
        [id]: "AI Summary: Citizens report water pressure is dropping rapidly. Visual evidence confirms a severe main line fracture requiring immediate heavy machinery."
      }));
    }, 1500);
  };

  const handleSendReply = (id: string) => {
    const text = replyTexts[id]?.trim();
    if (!text) return;

    setTickets(prev => prev.map(t => {
      if (t.id !== id) return t;
      return {
        ...t,
        comments: [
          ...(t.comments || []),
          {
            author: `Official Reply (${department})`,
            text: text,
            timestamp: 'Just Now',
            isOfficial: true
          }
        ]
      };
    }));

    setReplyTexts(prev => ({ ...prev, [id]: '' }));
  };

  const handleRejectReroute = (id: string) => {
    setTickets(prev => prev.map(t => t.id === id ? { ...t, status: 'rerouted' } : t));
  };

  // Handle Notice creation
  const handleCreateNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeMessage.trim()) return;

    // Use current timestamp or "Just Now"
    const newNotice = {
      id: `N-${100 + notices.length + 1}`,
      type: noticeType,
      targetZone: noticeTargetZone,
      message: noticeMessage,
      date: 'Just Now',
      department: department,
      status: 'Active'
    };

    setNotices([newNotice, ...notices]);
    setNoticeMessage('');
    // Keep or reset dropdowns
    setNoticeSuccessMessage('Notice Published Successfully!');
    setTimeout(() => setNoticeSuccessMessage(''), 4000);
  };

  const handleRevokeNotice = (id: string) => {
    setNotices(prev => prev.filter(notice => notice.id !== id));
  };

  return (
    <div id="authority-portal-wrapper" className="min-h-screen bg-slate-900 flex flex-col font-sans select-none">
      
      {/* 1. DISTINCT ENTERPRISE TOP HEADER */}
      <header className="sticky top-0 z-40 bg-slate-950 text-white border-b border-slate-800 px-4 sm:px-6 py-4 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 bg-indigo-600 text-white rounded-xl flex items-center justify-center border border-indigo-500/50 shadow-md shadow-indigo-600/20">
            <ShieldCheck className="w-5.5 h-5.5" />
          </div>
          <div className="text-left">
            <span className="font-extrabold text-sm sm:text-base tracking-tight text-white font-display flex items-center gap-2">
              Community Hero <span className="text-[9px] bg-indigo-600 px-2 py-0.5 rounded font-mono uppercase tracking-widest text-indigo-100 font-extrabold">Authority Terminal</span>
            </span>
            <p className="text-[10px] text-indigo-300/80 font-bold tracking-wide mt-0.5 uppercase">
              🏛️ {municipality} <span className="text-slate-500 mx-1">|</span> {department} Dept
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:inline-flex items-center gap-1.5 px-3 py-1 bg-slate-900 border border-slate-800 rounded-lg text-slate-300 font-bold text-xs">
            <span className="text-emerald-500 animate-pulse">●</span>
            <span>Active Terminal Sync</span>
          </div>
          
          {onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 active:scale-95 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
            >
              <LogOut className="w-3.5 h-3.5 text-slate-400" />
              <span>Sign Out</span>
            </button>
          )}
        </div>
      </header>

      {/* 2. THREE-COLUMN ENTERPRISE SIDEBAR LAYOUT */}
      <div className="flex-1 flex flex-col md:flex-row min-h-0">
        
        {/* Left Sidebar Navigation for Authority */}
        <aside className="w-full md:w-64 bg-slate-950/40 border-r border-slate-850 py-6 px-4 shrink-0 flex flex-col justify-between border-b md:border-b-0">
          <div className="space-y-6">
            <div className="px-2 text-left">
              <span className="text-[9px] font-extrabold text-slate-500 uppercase tracking-widest font-mono">
                Control Centre
              </span>
            </div>
            
            {/* Nav Menu */}
            <nav className="flex flex-row md:flex-col overflow-x-auto md:overflow-x-visible gap-1 pb-2 md:pb-0">
              <button
                type="button"
                onClick={() => setActiveSubTab('inbox')}
                className={`flex-1 md:flex-initial flex items-center justify-center md:justify-start gap-3 px-3.5 py-3 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  activeSubTab === 'inbox'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                    : 'text-slate-400 hover:bg-slate-850 hover:text-white'
                }`}
              >
                <Inbox className="w-4.5 h-4.5 shrink-0" />
                <span> Inbox & Triage</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveSubTab('operations')}
                className={`flex-1 md:flex-initial flex items-center justify-center md:justify-start gap-3 px-3.5 py-3 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  activeSubTab === 'operations'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                    : 'text-slate-400 hover:bg-slate-850 hover:text-white'
                }`}
              >
                <Trello className="w-4.5 h-4.5 shrink-0" />
                <span> Active Operations</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveSubTab('notices')}
                className={`flex-1 md:flex-initial flex items-center justify-center md:justify-start gap-3 px-3.5 py-3 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  activeSubTab === 'notices'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                    : 'text-slate-400 hover:bg-slate-850 hover:text-white'
                }`}
              >
                <Megaphone className="w-4.5 h-4.5 shrink-0" />
                <span> Public Notices</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveSubTab('analytics')}
                className={`flex-1 md:flex-initial flex items-center justify-center md:justify-start gap-3 px-3.5 py-3 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  activeSubTab === 'analytics'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                    : 'text-slate-400 hover:bg-slate-850 hover:text-white'
                }`}
              >
                <BarChart3 className="w-4.5 h-4.5 shrink-0" />
                <span> Department Analytics</span>
              </button>
            </nav>
          </div>

          <div className="hidden md:block bg-slate-950 border border-slate-850 rounded-2xl p-4 text-center space-y-1">
            <p className="text-[9px] font-extrabold text-slate-500 uppercase tracking-wider font-mono">System Status</p>
            <p className="text-xs font-extrabold text-emerald-400 font-mono">100% Operational</p>
            <p className="text-[9px] text-slate-400 font-medium pt-1">Node: Panvel-Edge-01</p>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-slate-950 p-4 md:p-8">
            {/* TAB 1: INBOX & TRIAGE (The Command Center) */}
          {activeSubTab === 'inbox' && (
            <div id="inbox-triage-panel" className="space-y-6 max-w-6xl mx-auto">
              
              {/* Header section */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-left">
                <div>
                  <h2 className="text-xl font-bold tracking-tight text-white font-display">
                    Verified Department Tickets ({department})
                  </h2>
                  <p className="text-xs text-slate-400 font-medium">
                    Incoming hazards routed automatically by real-time citizen reporting and computer vision engines.
                  </p>
                </div>
                
                {/* Visual Status Indicator */}
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-900 border border-slate-800 rounded-full text-[10px] text-indigo-400 font-bold font-mono uppercase">
                  <Sparkles className="w-3 h-3 text-indigo-500 animate-pulse" />
                  <span>Gemini Triage Active</span>
                </div>
              </div>

              {/* Triage Count overview */}
              <div className="flex items-center justify-between p-4 bg-slate-900/60 border border-slate-800 rounded-2xl text-left">
                <div>
                  <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider font-mono">Queue Status</span>
                  <p className="text-sm font-bold text-slate-300">
                    Currently tracking <span className="text-indigo-400 font-mono font-extrabold">{tickets.filter(t => t.status === 'pending').length}</span> issues in Awaiting Triage queue
                  </p>
                </div>
              </div>

              {/* Staggered Cards List */}
              <div className="space-y-4">
                {tickets.filter(t => t.status === 'pending').map((ticket) => (
                  <div 
                    key={ticket.id} 
                    className="bg-slate-900/90 border border-slate-800 rounded-2xl relative hover:border-indigo-500/40 transition-all duration-300 shadow-xl text-left"
                  >
                    {/* Ticket Main Info Row */}
                    <div className="p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                      <div className="space-y-3 flex-1">
                        <div className="flex flex-wrap items-center gap-2.5">
                          <span className="font-mono font-extrabold text-xs text-indigo-400 bg-indigo-950/60 border border-indigo-900/80 px-2.5 py-1 rounded-md">
                            #{ticket.id}
                          </span>
                          <span className={`inline-flex items-center gap-1 text-[10px] font-extrabold px-2.5 py-0.5 rounded border ${
                            ticket.severity === 'HIGH' 
                              ? 'bg-rose-950/60 text-rose-400 border-rose-900/60' 
                              : 'bg-amber-950/60 text-amber-400 border-amber-900/60'
                          }`}>
                            <span className="h-1.5 w-1.5 rounded-full bg-current animate-pulse" />
                            {ticket.severity} SEVERITY
                          </span>
                          <span className="text-xs text-slate-500">• Reported {ticket.reportedTime}</span>
                        </div>

                        <h3 className="text-base font-bold text-white tracking-tight">{ticket.title}</h3>

                        {/* Grid of metadata */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-1">
                          <div className="flex items-center gap-2 text-xs text-slate-300">
                            <span className="text-slate-400 text-sm">📍</span>
                            <span className="font-medium truncate">{ticket.location}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-slate-300">
                            <span className="text-slate-400 text-sm">👤</span>
                            <span>Reporter: <strong className="text-white font-semibold">{ticket.reporterName}</strong></span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-slate-300">
                            <Clock className="w-4 h-4 text-slate-400" />
                            <span>Received Time: <strong className="text-white font-semibold">Today, Just Now</strong></span>
                          </div>
                        </div>

                        {/* Network upvotes and verification counts */}
                        <div className="flex flex-wrap gap-4 pt-1.5">
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-950/50 rounded-lg border border-slate-800 text-xs text-slate-400">
                            <ThumbsUp className="w-3.5 h-3.5 text-blue-400" />
                            <span>Upvotes: <strong className="text-blue-300 font-bold font-mono">{ticket.upvotes}</strong></span>
                          </div>
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-950/50 rounded-lg border border-slate-800 text-xs text-slate-400">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Verified Checkins: <strong className="text-emerald-300 font-bold font-mono">{ticket.verifiedCount} Citizens</strong></span>
                          </div>
                        </div>
                      </div>

                      {/* Buttons Section */}
                      <div className="flex flex-col sm:flex-row lg:flex-col xl:flex-row items-stretch sm:items-center gap-3 shrink-0 lg:w-auto w-full">
                        {/* View Discussion & Media Button */}
                        <button
                          type="button"
                          onClick={() => setExpandedTicketId(expandedTicketId === ticket.id ? null : ticket.id)}
                          className={`px-4 py-2.5 rounded-xl border font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer ${
                            expandedTicketId === ticket.id
                              ? 'bg-slate-800 text-white border-slate-700 shadow-md'
                              : 'bg-slate-950/40 hover:bg-slate-800/80 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <MessageSquare className="w-4 h-4 text-indigo-400" />
                          <span> View Discussion & Media</span>
                          {expandedTicketId === ticket.id ? (
                            <ChevronUp className="w-4 h-4 text-slate-400" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-400" />
                          )}
                        </button>

                        {/* Select Crew popover trigger */}
                        <div className="relative">
                          <button
                            type="button"
                            onClick={() => setActiveCrewDropdownId(activeCrewDropdownId === ticket.id ? null : ticket.id)}
                            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-xs rounded-xl transition-all shadow-lg shadow-indigo-600/10 border border-indigo-500/30 cursor-pointer flex items-center justify-center gap-1.5 w-full"
                          >
                            <span>Select Crew</span>
                            <ChevronDown className="w-4 h-4" />
                          </button>

                          {/* Dropdown Popover */}
                          {activeCrewDropdownId === ticket.id && (
                            <div className="absolute z-[999] top-full right-0 mt-2 w-72 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl p-2 animate-fade-in text-left">
                              <div className="px-3 py-2 border-b border-slate-900 mb-1">
                                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Available Teams</p>
                              </div>
                              <div className="space-y-1">
                                {[
                                  { name: 'Crew Alpha', status: 'Available', color: 'text-emerald-400 bg-emerald-950/40 border-emerald-900/60', isBusy: false },
                                  { name: 'Crew Bravo', status: 'Available', color: 'text-emerald-400 bg-emerald-950/40 border-emerald-900/60', isBusy: false },
                                  { name: 'Crew Charlie', status: 'Busy', color: 'text-rose-400 bg-rose-950/20 border-rose-950/40 opacity-50', isBusy: true }
                                ].map((crew) => (
                                  <button
                                    key={crew.name}
                                    type="button"
                                    disabled={crew.isBusy}
                                    onClick={() => handleConfirmCrewAssignment(ticket.id, crew.name)}
                                    className={`w-full flex items-center justify-between p-2.5 rounded-lg text-left text-xs transition border cursor-pointer ${
                                      crew.isBusy
                                        ? 'border-transparent text-slate-500 bg-slate-900/40 cursor-not-allowed'
                                        : 'border-slate-900 hover:bg-slate-900 hover:border-indigo-900 text-white'
                                    }`}
                                  >
                                    <div className="flex items-center gap-2">
                                      <span className={`w-2 h-2 rounded-full ${crew.isBusy ? 'bg-rose-500' : 'bg-emerald-400'}`} />
                                      <span className="font-bold">{crew.name}</span>
                                    </div>
                                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border uppercase font-mono ${crew.color}`}>
                                      {crew.status}
                                    </span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Expandable Panel */}
                    <AnimatePresence>
                      {expandedTicketId === ticket.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2, ease: 'easeInOut' }}
                          className="border-t border-slate-800 bg-slate-950/40 rounded-b-2xl"
                        >
                          <div className="p-6 space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              
                              {/* Left Column: Media & AI Summary */}
                              <div className="space-y-4">
                                <div>
                                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono mb-2 flex items-center gap-1">
                                    <FileImage className="w-3.5 h-3.5 text-indigo-400" />
                                    <span>Visual Evidence (Media Proof)</span>
                                  </h4>
                                  <div className="grid grid-cols-2 gap-3">
                                    {ticket.mockImages?.map((img, idx) => {
                                      let badgeText = '';
                                      if (ticket.id === 'CIV-302') {
                                        if (idx === 0) badgeText = "Citizen Upload: 10:42 AM";
                                        if (idx === 1) badgeText = "Verified by: Siddharth Shah";
                                      } else if (ticket.id === 'CIV-301') {
                                        if (idx === 0) badgeText = "Citizen Upload: 08:30 AM";
                                        if (idx === 1) badgeText = "Verified by: Ganesh Gorad";
                                      } else if (ticket.id === 'CIV-303') {
                                        if (idx === 0) badgeText = "Citizen Upload: 09:15 AM";
                                        if (idx === 1) badgeText = "Verified by: Neha Sharma";
                                      }
                                      return (
                                        <div key={idx} className="relative aspect-video bg-slate-900 border border-slate-800 rounded-xl overflow-hidden group">
                                          <img
                                            src={img}
                                            alt="Incident Proof"
                                            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                                            referrerPolicy="no-referrer"
                                          />
                                          <div className="absolute inset-0 bg-slate-950/20" />
                                          {badgeText && (
                                            <div className="absolute bottom-2 left-2 right-2 bg-black/70 backdrop-blur-xs text-[10px] font-bold text-slate-200 border border-slate-800/80 px-2 py-0.5 rounded text-center truncate shadow-lg">
                                              {badgeText}
                                            </div>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>

                                {/* AI Summarize Block */}
                                <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 space-y-3">
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-300 font-mono">
                                      <Sparkles className="w-4 h-4 text-indigo-400" />
                                      <span>Gemini Dispatch Copilot</span>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => handleAISummarize(ticket.id)}
                                      disabled={isSummarizing[ticket.id]}
                                      className="px-3 py-1 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/20 hover:border-indigo-500/40 font-bold text-[10px] rounded-lg transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                                    >
                                      {isSummarizing[ticket.id] ? (
                                        <>
                                          <Loader2 className="w-3 h-3 animate-spin text-indigo-400" />
                                          <span>Analyzing Thread...</span>
                                        </>
                                      ) : (
                                        <>
                                          <span>✨ AI Summarize Thread</span>
                                        </>
                                      )}
                                    </button>
                                  </div>

                                  {/* Simulated AI Summary Block */}
                                  {aiSummaries[ticket.id] ? (
                                    <motion.div
                                      initial={{ opacity: 0, y: 5 }}
                                      animate={{ opacity: 1, y: 0 }}
                                      className="bg-indigo-950/40 border border-indigo-900/40 rounded-lg p-3 text-left"
                                    >
                                      <p className="text-xs text-indigo-200 leading-relaxed font-medium">
                                        {aiSummaries[ticket.id]}
                                      </p>
                                    </motion.div>
                                  ) : (
                                    <p className="text-xs text-slate-500 italic">
                                      Click the summarize button to instantly digest citizen reports and visual logs.
                                    </p>
                                  )}
                                </div>
                              </div>

                              {/* Right Column: Discussion & Authority Reply */}
                              <div className="space-y-4 flex flex-col justify-between">
                                <div>
                                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono mb-2 flex items-center gap-1">
                                    <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                                    <span>Citizen Discussion Feed ({ticket.comments?.length || 0})</span>
                                  </h4>
                                  
                                  {/* Comments Scrollable Feed */}
                                  <div className="space-y-3 max-h-[180px] overflow-y-auto pr-1">
                                    {ticket.comments?.map((comment, idx) => (
                                      <div
                                        key={idx}
                                        className={`p-3 rounded-xl text-left border text-xs leading-relaxed space-y-1 ${
                                          comment.isOfficial
                                            ? 'bg-indigo-950/30 border-indigo-900/50'
                                            : 'bg-slate-900 border-slate-800'
                                        }`}
                                      >
                                        <div className="flex items-center justify-between">
                                          <span className={`font-bold ${comment.isOfficial ? 'text-indigo-300' : 'text-slate-200'}`}>
                                            {comment.author}
                                          </span>
                                          <span className="text-[10px] text-slate-500 font-mono">{comment.timestamp}</span>
                                        </div>
                                        <p className="text-slate-300">{comment.text}</p>
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                {/* Official Authority Reply Input */}
                                <div className="space-y-2 pt-2 border-t border-slate-900">
                                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono text-left">
                                    Post Official Update
                                  </p>
                                  <div className="flex gap-2">
                                    <input
                                      type="text"
                                      value={replyTexts[ticket.id] || ''}
                                      onChange={(e) => setReplyTexts(prev => ({ ...prev, [ticket.id]: e.target.value }))}
                                      placeholder="Broadcast clear status update to the citizen thread..."
                                      onKeyDown={(e) => {
                                        if (e.key === 'Enter') handleSendReply(ticket.id);
                                      }}
                                      className="flex-1 bg-slate-950 border border-slate-800 focus:border-indigo-500/50 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 outline-none transition"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => handleSendReply(ticket.id)}
                                      className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold rounded-xl transition flex items-center justify-center cursor-pointer shadow-md"
                                    >
                                      <Send className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>

                              </div>

                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}

                {tickets.filter(t => t.status === 'pending').length === 0 && (
                  <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
                    <CheckCircle2 className="w-10 h-10 text-slate-500 mx-auto" />
                    <p className="text-sm font-bold text-slate-300">All pending tickets have been triaged</p>
                    <p className="text-xs text-slate-500">Check the Active Operations tab to monitor teams.</p>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB 2: ACTIVE OPERATIONS (Kanban Board) */}
          {activeSubTab === 'operations' && (
            <div id="active-operations-panel" className="space-y-6 max-w-6xl mx-auto text-left">
              
              {/* Header section */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                  <h2 className="text-xl font-bold tracking-tight text-white font-display">
                    Department Operations Board
                  </h2>
                  <p className="text-xs text-slate-400 font-medium">
                    Manage active crew dispatches, track field progress, and verify municipal resolution milestones.
                  </p>
                </div>
                
                {/* Board-wide quick actions */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setTickets([
                        {
                          id: 'CIV-303',
                          title: 'Contaminated Water Supply',
                          location: 'Sector 15, Block C',
                          status: 'pending',
                          department: 'Water Supply',
                          category: 'Water Supply',
                          severity: 'medium',
                          urgency: 'Medium',
                          upvotes: 4,
                          verifiedCount: 2,
                          hasUpvoted: false,
                          verification: 'None',
                          description: 'Drinking water in Block C has a yellow-brown tint and a slight metallic smell. Multiple residents reported the same issue this morning.',
                          coordinates: { x: 20, y: 75 },
                          photoUrl: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=400&q=80',
                          reporterName: 'Neha Sharma',
                          reportedTime: '1 hour ago',
                          assignedTo: '',
                          assignedCrew: '',
                          mockImages: [
                            'https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=400&q=80',
                            'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=400&q=80'
                          ],
                          locality: 'Sector 15',
                          tags: ['Water Supply', 'Public Health'],
                          tracked: true,
                          iconType: 'water',
                          verifications: 2,
                          comments: [
                            { id: 'c5', author: 'Priya Sen', role: 'Resident', avatarColor: 'bg-emerald-500', text: 'Hardly any water flowing from the kitchen taps since this morning.', timestamp: '55 mins ago' },
                            { id: 'c6', author: 'Rohit Jha', role: 'Resident', avatarColor: 'bg-indigo-500', text: 'Same here in building F. Please look into it.', timestamp: '50 mins ago' }
                          ]
                        },
                        {
                          id: 'CIV-302',
                          title: 'Drainage Overflow on Station Road',
                          location: 'Station Road',
                          status: 'assigned',
                          department: 'Water Supply',
                          category: 'Water Supply',
                          severity: 'high',
                          urgency: 'High',
                          assignedCrew: 'Crew Alpha',
                          assignedTo: 'Crew Alpha',
                          upvotes: 9,
                          verifiedCount: 8,
                          hasUpvoted: false,
                          verification: 'Quick',
                          description: 'Raw sewage and dirty water overflowing from multiple manholes near the railway station entrance, creating a terrible smell and traffic gridlock.',
                          coordinates: { x: 65, y: 45 },
                          photoUrl: 'https://images.unsplash.com/photo-1542282088-fe8426682b8f?auto=format&fit=crop&w=400&q=80',
                          reporterName: 'Siddharth Shah',
                          reportedTime: '42 mins ago',
                          mockImages: [
                            'https://images.unsplash.com/photo-1542282088-fe8426682b8f?auto=format&fit=crop&w=400&q=80',
                            'https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?auto=format&fit=crop&w=400&q=80'
                          ],
                          locality: 'Old Panvel',
                          tags: ['Water Supply', 'Infrastructure'],
                          tracked: true,
                          iconType: 'water',
                          verifications: 8,
                          comments: [
                            { id: 'c3', author: 'Sonal Mehta', role: 'Resident', avatarColor: 'bg-emerald-500', text: 'The manhole is completely overflowing and causing terrible traffic.', timestamp: '35 mins ago' },
                            { id: 'c4', author: 'Vikram Singh', role: 'Resident', avatarColor: 'bg-indigo-500', text: 'The municipal team was notified 3 hours ago but no action yet.', timestamp: '30 mins ago' }
                          ]
                        },
                        {
                          id: 'CIV-301',
                          title: 'Major Pipe Burst in Sector 15',
                          location: 'Sector 15, Central Park',
                          status: 'in_progress',
                          department: 'Water Supply',
                          category: 'Water Supply',
                          severity: 'high',
                          urgency: 'High',
                          assignedCrew: 'Crew Bravo',
                          assignedTo: 'Crew Bravo',
                          upvotes: 18,
                          verifiedCount: 12,
                          hasUpvoted: false,
                          verification: 'None',
                          description: 'A large high-pressure water transmission pipeline has ruptured, sending a massive geyser of water into the air and flooding the roadway and nearby footpaths.',
                          coordinates: { x: 35, y: 30 },
                          photoUrl: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=400&q=80',
                          reporterName: 'Ganesh Gorad',
                          reportedTime: '15 mins ago',
                          mockImages: [
                            'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=400&q=80',
                            'https://images.unsplash.com/photo-1585338107529-13afc5f02586?auto=format&fit=crop&w=400&q=80'
                          ],
                          locality: 'Sector 15',
                          tags: ['Water Supply', 'Infrastructure'],
                          tracked: true,
                          iconType: 'water',
                          verifications: 12,
                          comments: [
                            { id: 'c1', author: 'Rajesh Kumar', role: 'Resident', avatarColor: 'bg-emerald-500', text: 'Water has flooded the entire lane near Central Park. Please send help immediately!', timestamp: '22 mins ago' },
                            { id: 'c2', author: 'Amit Patel', role: 'Resident', avatarColor: 'bg-indigo-500', text: 'Yes, water pressure has dropped completely in the nearby buildings.', timestamp: '18 mins ago' }
                          ]
                        }
                      ]);
                    }}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-750 active:scale-95 text-slate-300 font-extrabold rounded-lg text-xs transition flex items-center gap-1 border border-slate-700 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                    <span>Reset Board State</span>
                  </button>
                </div>
              </div>

              {/* Three Column Kanban Board */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch min-h-[500px]">
                
                {/* Column 1: Assigned / Waiting for deployment */}
                <div className="bg-slate-900/40 border border-slate-800/80 rounded-[20px] p-4 flex flex-col h-full shadow-inner">
                  {/* Column Header */}
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800/60">
                    <div className="flex items-center gap-2.5">
                      <span className="text-base">📋</span>
                      <div>
                        <h4 className="font-bold text-slate-200 text-xs sm:text-sm tracking-tight font-sans">
                          Assigned
                        </h4>
                        <p className="text-[10px] text-slate-500 font-medium">
                          Waiting for deployment
                        </p>
                      </div>
                    </div>
                    <span className="bg-slate-850 text-slate-300 font-bold font-mono text-[10px] px-2 py-0.5 rounded-full border border-slate-800/80">
                      {tickets.filter(t => t.status === 'assigned').length}
                    </span>
                  </div>

                  {/* Task List */}
                  <div className="flex-1 space-y-3 min-h-[400px]">
                    {tickets.filter(t => t.status === 'assigned').map(task => (
                      <div 
                        key={task.id} 
                        className="bg-slate-950/80 border border-slate-850 hover:border-slate-800 rounded-xl p-4.5 shadow-lg transition-all duration-300 flex flex-col justify-between hover:shadow-2xl hover:translate-y-[-2px]"
                      >
                        <div className="space-y-2.5">
                          {/* Top Row: Ticket ID + Urgency */}
                          <div className="flex justify-between items-center gap-2">
                            <span className="font-extrabold text-indigo-400 font-mono text-[10px] bg-indigo-950/40 border border-indigo-900/50 px-2 py-0.5 rounded">
                              #{task.id}
                            </span>
                            <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded border uppercase font-mono ${
                              task.urgency === 'High' 
                                ? 'bg-rose-950/40 text-rose-400 border-rose-900/40' 
                                : 'bg-amber-950/40 text-amber-400 border-amber-900/40'
                            }`}>
                              {task.urgency || 'Medium'} Urgency
                            </span>
                          </div>
                          
                          {/* Title */}
                          <h4 className="font-bold text-slate-200 text-xs sm:text-[13px] leading-snug tracking-tight">
                            {task.title}
                          </h4>
                          
                          {/* Location */}
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span className="truncate">{task.location}</span>
                          </div>

                          {/* Assigned Crew */}
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-300 bg-slate-900/60 px-2.5 py-1.5 rounded-lg border border-slate-850">
                            <Users className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                            <span>Crew: <strong className="text-white font-semibold">{task.assignedTo || 'Unassigned'}</strong></span>
                          </div>
                        </div>

                        {/* Controls (⚡ Start Work) */}
                        <div className="flex items-center justify-end mt-4 pt-3 border-t border-slate-900">
                          <button
                            type="button"
                            onClick={() => {
                              setTickets(prev => prev.map(t => t.id === task.id ? { ...t, status: 'inprogress' } : t));
                            }}
                            className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-[0.98] text-white font-extrabold rounded-lg text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/10 border border-indigo-500/30"
                          >
                            <span>⚡ Start Work</span>
                          </button>
                        </div>
                      </div>
                    ))}
                    {tickets.filter(t => t.status === 'assigned').length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-xl py-12 px-4 text-center">
                        <Check className="w-8 h-8 text-slate-600 mb-1" />
                        <p className="text-xs font-bold text-slate-400">No Pending Assignments</p>
                        <p className="text-[10px] text-slate-500 mt-0.5">Deployments are complete.</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Column 2: In Progress / Crew on site */}
                <div className="bg-slate-900/40 border border-slate-800/80 rounded-[20px] p-4 flex flex-col h-full shadow-inner">
                  {/* Column Header */}
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800/60">
                    <div className="flex items-center gap-2.5">
                      <span className="text-base">🚧</span>
                      <div>
                        <h4 className="font-bold text-slate-200 text-xs sm:text-sm tracking-tight font-sans">
                          In Progress
                        </h4>
                        <p className="text-[10px] text-slate-500 font-medium">
                          Crew on site
                        </p>
                      </div>
                    </div>
                    <span className="bg-slate-850 text-slate-300 font-bold font-mono text-[10px] px-2 py-0.5 rounded-full border border-slate-800/80">
                      {tickets.filter(t => t.status === 'inprogress' || t.status === 'in_progress').length}
                    </span>
                  </div>

                  {/* Task List */}
                  <div className="flex-1 space-y-3 min-h-[400px]">
                    {tickets.filter(t => t.status === 'inprogress' || t.status === 'in_progress').map(task => (
                      <div 
                        key={task.id} 
                        className="bg-slate-950/80 border border-slate-850 hover:border-slate-800 rounded-xl p-4.5 shadow-lg transition-all duration-300 flex flex-col justify-between hover:shadow-2xl hover:translate-y-[-2px]"
                      >
                        <div className="space-y-2.5">
                          {/* Top Row: Ticket ID + Urgency */}
                          <div className="flex justify-between items-center gap-2">
                            <span className="font-extrabold text-indigo-400 font-mono text-[10px] bg-indigo-950/40 border border-indigo-900/50 px-2 py-0.5 rounded">
                              #{task.id}
                            </span>
                            <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded border uppercase font-mono ${
                              task.urgency === 'High' 
                                ? 'bg-rose-950/40 text-rose-400 border-rose-900/40' 
                                : 'bg-amber-950/40 text-amber-400 border-amber-900/40'
                            }`}>
                              {task.urgency || 'High'} Urgency
                            </span>
                          </div>
                          
                          {/* Title */}
                          <h4 className="font-bold text-slate-200 text-xs sm:text-[13px] leading-snug tracking-tight">
                            {task.title}
                          </h4>
                          
                          {/* Location */}
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span className="truncate">{task.location}</span>
                          </div>

                          {/* Assigned Crew */}
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-300 bg-slate-900/60 px-2.5 py-1.5 rounded-lg border border-slate-850">
                            <Users className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                            <span>Crew: <strong className="text-white font-semibold">{task.assignedTo || 'Unassigned'}</strong></span>
                          </div>
                        </div>

                        {/* Controls (✅ Mark Resolved + ⏪ Undo) */}
                        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-900">
                          <button
                            type="button"
                            onClick={() => {
                              setTickets(prev => prev.map(t => t.id === task.id ? { ...t, status: 'assigned' } : t));
                            }}
                            className="px-3 py-2 bg-slate-900 hover:bg-slate-850 active:scale-[0.98] text-slate-400 hover:text-slate-200 font-extrabold rounded-lg text-xs transition-all flex items-center justify-center gap-1 cursor-pointer border border-slate-800"
                            title="Undo back to Assigned"
                          >
                            <span>⏪ Undo</span>
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => {
                              setTickets(prev => prev.map(t => t.id === task.id ? { ...t, status: 'resolved' } : t));
                            }}
                            className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-extrabold rounded-lg text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-600/10 border border-emerald-500/30"
                          >
                            <span>✅ Mark Resolved</span>
                          </button>
                        </div>
                      </div>
                    ))}
                    {tickets.filter(t => t.status === 'inprogress' || t.status === 'in_progress').length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-xl py-12 px-4 text-center">
                        <Clock className="w-8 h-8 text-slate-600 mb-1" />
                        <p className="text-xs font-bold text-slate-400">No Active Operations</p>
                        <p className="text-[10px] text-slate-500 mt-0.5">Move cards from Assigned here when dispatched.</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Column 3: Resolved / Work completed */}
                <div className="bg-slate-900/40 border border-slate-800/80 rounded-[20px] p-4 flex flex-col h-full shadow-inner">
                  {/* Column Header */}
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800/60">
                    <div className="flex items-center gap-2.5">
                      <span className="text-base">✅</span>
                      <div>
                        <h4 className="font-bold text-slate-200 text-xs sm:text-sm tracking-tight font-sans">
                          Resolved
                        </h4>
                        <p className="text-[10px] text-slate-500 font-medium">
                          Work completed
                        </p>
                      </div>
                    </div>
                    <span className="bg-slate-850 text-slate-300 font-bold font-mono text-[10px] px-2 py-0.5 rounded-full border border-slate-800/80">
                      {tickets.filter(t => t.status === 'resolved').length}
                    </span>
                  </div>

                  {/* Task List */}
                  <div className="flex-1 space-y-3 min-h-[400px]">
                    {tickets.filter(t => t.status === 'resolved').map(task => (
                      <div 
                        key={task.id} 
                        className="bg-slate-950/80 border border-slate-850 hover:border-slate-800 rounded-xl p-4.5 shadow-lg transition-all duration-300 flex flex-col justify-between hover:shadow-2xl hover:translate-y-[-2px]"
                      >
                        <div className="space-y-2.5">
                          {/* Top Row: Ticket ID + Urgency */}
                          <div className="flex justify-between items-center gap-2">
                            <span className="font-bold text-emerald-400 font-mono text-[10px] bg-emerald-950/40 border border-emerald-900/50 px-2 py-0.5 rounded">
                              #{task.id}
                            </span>
                            <span className="bg-emerald-950/40 text-emerald-400 border border-emerald-900/40 text-[9px] font-extrabold px-1.5 py-0.5 rounded uppercase font-mono">
                              Resolved
                            </span>
                          </div>
                          
                          {/* Title */}
                          <h4 className="font-bold text-slate-200 text-xs sm:text-[13px] leading-snug tracking-tight">
                            {task.title}
                          </h4>
                          
                          {/* Location */}
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span className="truncate">{task.location}</span>
                          </div>

                          {/* Assigned Crew */}
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-300 bg-slate-900/60 px-2.5 py-1.5 rounded-lg border border-slate-850">
                            <Users className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                            <span>Crew: <strong className="text-white font-semibold">{task.assignedTo || 'Unassigned'}</strong></span>
                          </div>
                        </div>

                        {/* Controls (⏪ Revert to In Progress) */}
                        <div className="flex items-center justify-center mt-4 pt-3 border-t border-slate-900">
                          <button
                            type="button"
                            onClick={() => {
                              setTickets(prev => prev.map(t => t.id === task.id ? { ...t, status: 'inprogress' } : t));
                            }}
                            className="w-full py-2 bg-slate-900 hover:bg-slate-850 active:scale-[0.98] text-slate-400 hover:text-slate-200 font-mono font-extrabold rounded-lg text-[10px] uppercase tracking-wider text-center border border-slate-800 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                          >
                            <span>⏪ Revert to In Progress</span>
                          </button>
                        </div>
                      </div>
                    ))}
                    {tickets.filter(t => t.status === 'resolved').length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-xl py-12 px-4 text-center">
                        <CheckCircle2 className="w-8 h-8 text-slate-600 mb-1" />
                        <p className="text-xs font-bold text-slate-400">No Resolved Tickets yet</p>
                        <p className="text-[10px] text-slate-500 mt-0.5">Audit history of completed works.</p>
                      </div>
                    )}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB 3: PUBLIC NOTICES (Broadcast Wizard) */}
          {activeSubTab === 'notices' && (
            <div id="public-notices-panel" className="space-y-6 max-w-5xl mx-auto">
              
              {/* Header section */}
              <div className="text-left">
                <h2 className="text-xl font-bold tracking-tight text-white font-display">
                  Public Notices & Emergency Broadcasts
                </h2>
                <p className="text-xs text-slate-400 font-medium">
                  Draft and dispatch notifications directly to residents' Community Hero citizen apps.
                </p>
              </div>

              {/* Notice creator grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                
                {/* Form layout */}
                <form onSubmit={handleCreateNotice} className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-[24px] p-5 space-y-4 text-left flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-widest font-mono">Create Official Notice</h4>
                      <p className="text-[11px] text-slate-400 leading-normal">
                        Draft urgent messages or advisories for the public board.
                      </p>
                    </div>

                    {/* Success notification */}
                    {noticeSuccessMessage && (
                      <div className="p-3 bg-emerald-950/80 border border-emerald-900 text-emerald-400 rounded-xl text-xs font-semibold font-sans animate-bounce flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{noticeSuccessMessage}</span>
                      </div>
                    )}

                    {/* Field: Target Zone */}
                    <div className="space-y-1.5">
                      <label htmlFor="notice-target-zone" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                        Target Zone
                      </label>
                      <select
                        id="notice-target-zone"
                        value={noticeTargetZone}
                        onChange={(e) => setNoticeTargetZone(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-semibold cursor-pointer"
                      >
                        <option value="All Localities">All Localities</option>
                        <option value="Sector 15">Sector 15</option>
                        <option value="Khandeshwar">Khandeshwar</option>
                        <option value="Kamothe">Kamothe</option>
                      </select>
                    </div>

                    {/* Field: Notice Type */}
                    <div className="space-y-1.5">
                      <label htmlFor="notice-type" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                        Notice Type
                      </label>
                      <select
                        id="notice-type"
                        value={noticeType}
                        onChange={(e) => setNoticeType(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-semibold cursor-pointer"
                      >
                        <option value="Maintenance Schedule">Maintenance Schedule</option>
                        <option value="Emergency Alert">Emergency Alert</option>
                        <option value="Policy Update">Policy Update</option>
                      </select>
                    </div>

                    {/* Field: Message Content */}
                    <div className="space-y-1.5">
                      <label htmlFor="notice-message" className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                        Message Content
                      </label>
                      <textarea
                        id="notice-message"
                        required
                        rows={4}
                        placeholder="Type the message contents to broadcast to residents..."
                        value={noticeMessage}
                        onChange={(e) => setNoticeMessage(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-medium placeholder-slate-600 resize-none leading-relaxed"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-4 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/10"
                  >
                    <Megaphone className="w-4 h-4" />
                    <span> Publish to Community Hub</span>
                  </button>
                </form>

                {/* Broadcast logs */}
                <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-[24px] overflow-hidden text-left flex flex-col h-full justify-between">
                  <div>
                    <div className="p-4 bg-slate-900/40 border-b border-slate-800/80">
                      <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                        Live Citizen Broadcasts
                      </h3>
                    </div>

                    <div className="divide-y divide-slate-850 p-4 space-y-4 max-h-[460px] overflow-y-auto">
                      {notices.length > 0 ? (
                        notices.map((notice) => (
                          <div key={notice.id} className="pt-4 first:pt-0 flex flex-col sm:flex-row items-start justify-between gap-4">
                            <div className="space-y-2 flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-[9px] font-bold font-mono px-2 py-0.5 bg-indigo-950 text-indigo-300 border border-indigo-900 rounded-md">
                                  {notice.id}
                                </span>
                                <span className="text-[10px] text-slate-400 font-semibold font-mono">
                                  📍 {notice.targetZone}
                                </span>
                                <span className={`inline-flex items-center gap-1 text-[9px] font-bold px-2 py-0.5 rounded-full ${
                                  notice.type === 'Emergency Alert'
                                    ? 'bg-rose-950/50 text-rose-400 border border-rose-900/50'
                                    : notice.type === 'Policy Update'
                                    ? 'bg-amber-950/50 text-amber-400 border border-amber-900/50'
                                    : 'bg-blue-950/50 text-blue-400 border border-blue-900/50'
                                }`}>
                                  {notice.type}
                                </span>
                              </div>
                              
                              <p className="text-xs font-medium text-slate-100 leading-relaxed">
                                {notice.message}
                              </p>
                              
                              <p className="text-[10px] text-slate-400">
                                Dept: <span className="text-slate-300 font-semibold">{notice.department}</span> • <span className="font-semibold text-slate-400">{notice.date}</span>
                              </p>
                            </div>

                            <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-start w-full sm:w-auto gap-2 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800">
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-900/60 px-2 py-0.5 rounded-md">
                                ● Active
                              </span>
                              <button
                                type="button"
                                onClick={() => handleRevokeNotice(notice.id)}
                                className="text-[10px] font-extrabold text-rose-400 hover:text-rose-300 hover:bg-rose-950/20 px-2.5 py-1.5 rounded-lg border border-rose-900/40 hover:border-rose-800 transition cursor-pointer shrink-0"
                              >
                                [ Revoke Notice ]
                              </button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="py-16 text-center flex flex-col items-center justify-center">
                          <Megaphone className="w-8 h-8 text-slate-600 mb-2 animate-pulse" />
                          <p className="text-xs font-bold text-slate-400">No Active Broadcasts</p>
                          <p className="text-[11px] text-slate-500 mt-1 max-w-xs text-center">
                            Create and publish notices on the left to broadcast crucial updates to citizen feeds.
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB 4: DEPARTMENT ANALYTICS */}
          {activeSubTab === 'analytics' && (
            <div id="department-analytics-panel" className="space-y-6 max-w-5xl mx-auto">
              
              {/* Header section */}
              <div className="text-left">
                <h2 className="text-xl font-bold tracking-tight text-white font-display">
                  Department Intelligence Dashboard
                </h2>
                <p className="text-xs text-slate-400 font-medium">
                  Real-time metrics measuring municipal response efficiency, citizen reports, and resolution velocities.
                </p>
              </div>

              {/* Metric grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-[20px] space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">Total Issues Resolved</span>
                  <div className="flex items-baseline gap-2 pt-1">
                    <span className="text-2xl font-black text-white font-display">142</span>
                    <span className="text-[10px] font-extrabold text-emerald-400 font-mono">+12% from last month</span>
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-5 rounded-[20px] space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">Avg. Resolution Time</span>
                  <div className="flex items-baseline gap-2 pt-1">
                    <span className="text-2xl font-black text-white font-display">4.2 Hours</span>
                    <span className="text-[10px] font-extrabold text-emerald-400 font-mono">Target: under 6 hours | 🟢 Optimal</span>
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-5 rounded-[20px] space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">Citizen Satisfaction</span>
                  <div className="flex items-baseline gap-2 pt-1">
                    <span className="text-2xl font-black text-white font-display">4.7 / 5.0</span>
                    <span className="text-[10px] font-extrabold text-indigo-400 font-mono">Based on 98 resolution upvotes</span>
                  </div>
                </div>
              </div>

              {/* Chart widgets using beautiful native visualizations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch text-left">
                
                {/* Block 1: Weekly Ticket Volume */}
                <div className="bg-slate-900 border border-slate-800 rounded-[24px] p-6 space-y-4">
                  <div>
                    <h4 className="text-sm font-bold text-white font-display">Weekly Ticket Volume</h4>
                    <p className="text-[11px] text-slate-400">Total citizen issues received over the last 4 weeks</p>
                  </div>
                  <div className="h-48 flex items-end justify-around gap-2 pt-4 relative">
                    {/* Background Grid Lines */}
                    <div className="absolute inset-x-0 top-0 bottom-6 flex flex-col justify-between opacity-10 pointer-events-none">
                      <div className="border-b border-slate-400 w-full" />
                      <div className="border-b border-slate-400 w-full" />
                      <div className="border-b border-slate-400 w-full" />
                      <div className="border-b border-slate-400 w-full" />
                    </div>

                    {[
                      { label: 'Week 1', value: 45, color: 'bg-indigo-500 hover:bg-indigo-400' },
                      { label: 'Week 2', value: 38, color: 'bg-indigo-500 hover:bg-indigo-400' },
                      { label: 'Week 3', value: 52, color: 'bg-indigo-600 hover:bg-indigo-500' },
                      { label: 'Week 4', value: 28, color: 'bg-indigo-500 hover:bg-indigo-400' }
                    ].map((item, index) => {
                      const maxVal = 60;
                      const heightPct = (item.value / maxVal) * 100;
                      return (
                        <div key={index} className="flex flex-col items-center gap-2 h-full justify-end relative z-10 w-12 group">
                          <span className="text-[11px] font-bold text-slate-200 font-mono group-hover:text-white transition-colors">
                            {item.value}
                          </span>
                          <div className="w-8 bg-slate-800 rounded-t-lg h-full overflow-hidden flex items-end">
                            <div 
                              className={`${item.color} w-full rounded-t-lg transition-all duration-1000`}
                              style={{ height: `${heightPct}%` }}
                            />
                          </div>
                          <span className="text-[10px] font-bold text-slate-400 font-mono">{item.label}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Block 2: Resolution Breakdown by Locality */}
                <div className="bg-slate-900 border border-slate-800 rounded-[24px] p-6 space-y-4">
                  <div>
                    <h4 className="text-sm font-bold text-white font-display">Resolution Breakdown by Locality</h4>
                    <p className="text-[11px] text-slate-400">Issue completion and resolution rate across key sectors</p>
                  </div>
                  <div className="h-48 flex flex-col justify-between pt-2">
                    {[
                      { name: 'Sector 15', rate: 92, color: 'bg-emerald-500' },
                      { name: 'Old Panvel', rate: 89, color: 'bg-indigo-500' },
                      { name: 'Kamothe', rate: 84, color: 'bg-blue-500' },
                      { name: 'Khandeshwar', rate: 78, color: 'bg-amber-500' }
                    ].map((locality, index) => {
                      return (
                        <div key={index} className="space-y-1.5">
                          <div className="flex justify-between items-center text-xs font-semibold">
                            <span className="text-slate-300 font-medium">{locality.name}</span>
                            <span className="font-mono text-white font-bold">{locality.rate}% Resolved</span>
                          </div>
                          <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden flex">
                            <div 
                              className={`${locality.color} h-full rounded-full transition-all duration-1000`} 
                              style={{ width: `${locality.rate}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>

              {/* Recent Automated Operations Log */}
              <div className="bg-slate-900 border border-slate-800 rounded-[24px] overflow-hidden text-left">
                <div className="p-4 bg-slate-900/40 border-b border-slate-800/80 flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                    <span>⚡</span> Recent Automated Operations Log
                  </h3>
                  <span className="text-[10px] font-semibold text-indigo-400 font-mono bg-indigo-950/50 px-2 py-0.5 rounded-full border border-indigo-900/50">
                    System Logs • Live
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-850 bg-slate-950/20 text-slate-400 font-mono text-[10px] uppercase tracking-wider">
                        <th className="py-3 px-4 font-bold">Log ID</th>
                        <th className="py-3 px-4 font-bold">Operation Description</th>
                        <th className="py-3 px-4 font-bold">Status</th>
                        <th className="py-3 px-4 font-bold">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850 font-medium text-slate-200">
                      <tr className="hover:bg-slate-850/20 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-slate-400">1042</td>
                        <td className="py-3 px-4 text-slate-300">
                          Gemini Vision auto-routed Ticket <span className="text-indigo-400 font-bold font-mono">#CIV-302</span> to <span className="text-slate-100 font-semibold">Water Supply Dept</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-900/50">
                            Success
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-400 text-[11px] font-mono">2 hrs ago</td>
                      </tr>
                      <tr className="hover:bg-slate-850/20 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-slate-400">1041</td>
                        <td className="py-3 px-4 text-slate-300">
                          Status change on Ticket <span className="text-indigo-400 font-bold font-mono">#CIV-301</span> broadcasted to <span className="text-slate-100 font-semibold">Citizen Hub</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-950/80 text-blue-400 border border-blue-900/50">
                            Synced
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-400 text-[11px] font-mono">4 hrs ago</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

        </main>
      </div>

      {/* 3. TICKET AUDIT DETAIL DRAWER / OVERLAY FOR OPERATIONS */}
      <AnimatePresence>
        {selectedIssueId && selectedIssue && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-end z-50 p-4">
            <motion.div
              initial={{ x: '100%', opacity: 0.9 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0.9 }}
              transition={{ type: 'tween', duration: 0.25 }}
              className="bg-slate-900 w-full max-w-xl h-full shadow-2xl border-l border-slate-800 rounded-l-[24px] overflow-hidden flex flex-col"
            >
              
              {/* Drawer Header */}
              <div className="px-6 py-5 bg-slate-950 border-b border-slate-850 text-white flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 bg-indigo-950 border border-indigo-900 text-indigo-400 rounded-xl flex items-center justify-center">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-bold text-sm tracking-tight font-display text-white">Audit Docket {selectedIssue.id}</h4>
                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-sm border ${getUrgencyBadge(selectedIssue.urgency)}`}>
                        {selectedIssue.urgency} Priority
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono">Reported on {selectedIssue.date}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedIssueId(null);
                    setNewStatusSelection('');
                    setStatusComment('');
                  }}
                  className="text-slate-400 hover:text-white p-1 hover:bg-slate-800 rounded-md transition cursor-pointer"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Drawer Scroll Area */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6 text-left">
                
                {/* Photo & Basic stats */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-start">
                  <div className="sm:col-span-5 relative group">
                    <img
                      src={selectedIssue.imageUrl || "https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=500&q=80"}
                      alt={selectedIssue.title}
                      className="w-full h-32 rounded-xl object-cover border border-slate-800 shadow-xs"
                    />
                    <div className="absolute top-2 left-2 bg-slate-950/80 backdrop-blur-xs text-white text-[9px] font-bold font-mono px-2 py-0.5 rounded-md flex items-center gap-1">
                      <FileImage className="h-3 w-3" /> Photo Attached
                    </div>
                  </div>
                  
                  <div className="sm:col-span-7 space-y-2">
                    <h3 className="font-bold text-white text-sm tracking-tight leading-snug">{selectedIssue.title}</h3>
                    <p className="text-xs text-slate-400 font-medium">📍 {selectedIssue.location}</p>
                    <div className="flex items-center gap-4 text-xs font-semibold text-slate-400 font-mono pt-1">
                      <div>
                        Reporter: <span className="text-slate-200 font-bold">{selectedIssue.isAnonymous ? "Anonymous Citizen" : selectedIssue.reporterName}</span>
                      </div>
                      <div>
                        Upvotes: <span className="text-indigo-400 font-bold">👍 {selectedIssue.upvotes}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div className="bg-slate-950 rounded-[20px] p-4 border border-slate-850">
                  <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono mb-1.5">Citizen Incident Description</h5>
                  <p className="text-xs text-slate-300 leading-relaxed font-medium">{selectedIssue.description}</p>
                </div>

                {/* HISTORICAL RESOLUTION TIMELINE */}
                <div>
                  <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono mb-4">Historical Audit Timeline</h5>
                  <div className="relative pl-6 space-y-5 border-l border-slate-800">
                    {selectedIssue.timelineUpdates.map((update, idx) => (
                      <div key={idx} className="relative">
                        {/* Timeline node dot */}
                        <span className={`absolute -left-[31px] top-0.5 h-4.5 w-4.5 rounded-full border-2 border-slate-900 shadow-sm flex items-center justify-center text-[10px] text-white ${
                          update.status === 'Resolved' ? 'bg-indigo-600' :
                          update.status === 'In Progress' ? 'bg-amber-500' :
                          'bg-slate-500'
                        }`}>
                          ✓
                        </span>
                        
                        <div className="space-y-0.5">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-bold text-white">{update.status}</span>
                            <span className="text-[9px] text-slate-400 font-mono flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {update.date}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 leading-relaxed font-medium">{update.comment}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* INTERACTIVE PROGRESS MODIFIER FORM */}
                <form onSubmit={handleStatusUpdateSubmit} className="bg-slate-950 border border-slate-850 rounded-[20px] p-5 space-y-4">
                  <div>
                    <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 mb-2">
                      <Building2 className="h-3.5 w-3.5 text-indigo-400" />
                      Dispatch Center Status Modifier
                    </h5>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Update the repair stage of this ticket. Updates will immediately propagate back to resident maps and personal dashboards.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="new-status" className="text-[10px] font-bold text-slate-400 block mb-1">Target Resolution State</label>
                      <select
                        id="new-status"
                        value={newStatusSelection}
                        onChange={(e) => setNewStatusSelection(e.target.value as Issue['status'])}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-semibold text-slate-200 cursor-pointer"
                        required
                      >
                        <option value="">-- Choose New State --</option>
                        {STATUS_STATES.map((state) => (
                          <option 
                            key={state} 
                            value={state}
                            disabled={state === selectedIssue.status}
                          >
                            {state === selectedIssue.status ? `${state} (Current)` : state}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label htmlFor="action-comment" className="text-[10px] font-bold text-slate-400 block mb-1">Administrative Action Comment</label>
                      <input
                        id="action-comment"
                        type="text"
                        value={statusComment}
                        onChange={(e) => setStatusComment(e.target.value)}
                        placeholder="e.g. Inspector dispatched to verify..."
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-2 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-medium text-slate-200 placeholder-slate-600"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-md shadow-indigo-600/10"
                    disabled={isUpdatingStatus || !newStatusSelection || !statusComment.trim()}
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>Dispatch Audit Update</span>
                  </button>
                </form>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
